/*! © 2026 عمار العيد — جميع الحقوق محفوظة. مُثبِّت القرآن. انظر ملف LICENSE */
/* ===== إعدادات Firebase: الصق هنا بيانات مشروعك ===== */
const FB={apiKey:"AIzaSyDU-xm0U4NFXFa57Auv10967REt8n5PB3Y",authDomain:"quran-app-a042f.firebaseapp.com",projectId:"quran-app-a042f",storageBucket:"quran-app-a042f.firebasestorage.app",messagingSenderId:"353485701859",appId:"1:353485701859:web:f5096b38b998de6adefbd6"};
const L=[1,3,7,30],D=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
const SUR='الفاتحة البقرة آل_عمران النساء المائدة الأنعام الأعراف الأنفال التوبة يونس هود يوسف الرعد إبراهيم الحجر النحل الإسراء الكهف مريم طه الأنبياء الحج المؤمنون النور الفرقان الشعراء النمل القصص العنكبوت الروم لقمان السجدة الأحزاب سبأ فاطر يس الصافات ص الزمر غافر فصلت الشورى الزخرف الدخان الجاثية الأحقاف محمد الفتح الحجرات ق الذاريات الطور النجم القمر الرحمن الواقعة الحديد المجادلة الحشر الممتحنة الصف الجمعة المنافقون التغابن الطلاق التحريم الملك القلم الحاقة المعارج نوح الجن المزمل المدثر القيامة الإنسان المرسلات النبأ النازعات عبس التكوير الانفطار المطففين الانشقاق البروج الطارق الأعلى الغاشية الفجر البلد الشمس الليل الضحى الشرح التين العلق القدر البينة الزلزلة العاديات القارعة التكاثر العصر الهمزة الفيل قريش الماعون الكوثر الكافرون النصر المسد الإخلاص الفلق الناس'.split(' ').map(x=>x.replace('_',' '));
const MSG=['حبيب القرآن، موعدك الآن مع وردك 🌿','خيركم من تعلّم القرآن وعلّمه 📖','دقائق قليلة تثبّت حفظك لأيام طويلة ✨','ورتّل القرآن ترتيلاً.. جلستك بانتظارك'];
let S={tasks:[],logs:[],alarms:[],mist:[],skipFri:true,id:1};
try{Object.assign(S,JSON.parse(localStorage.getItem('qmrm')||'{}'))}catch(e){dbg(e)}
try{const _l=localStorage.getItem('qmrm_lang');if(_l)S.lang=_l}catch(e){dbg(e)}
const BOOT_LANG=S.lang=='en'?'en':'ar';S.lang=BOOT_LANG;
/* نسخة ثانية في IndexedDB: مساحتها كبيرة ولا تمتلئ مثل localStorage (حدّه ~5MB) فلا تضيع الدفاتر ذات الصور */
const idb=(()=>{let p=null;const open=()=>p||(p=new Promise((ok,no)=>{try{const r=indexedDB.open('qmrm_db',1);r.onupgradeneeded=()=>r.result.createObjectStore('k');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)}catch(e){no(e)}}));
 const tx=async(m,f)=>{const d=await open();return new Promise((ok,no)=>{const t=d.transaction('k',m),q=f(t.objectStore('k'));t.oncomplete=()=>ok(q&&q.result);t.onerror=()=>no(t.error);t.onabort=()=>no(t.error)})};
 return{get:k=>tx('readonly',s=>s.get(k)),set:(k,v)=>tx('readwrite',s=>s.put(v,k)),del:k=>tx('readwrite',s=>s.delete(k))}})();
let idbT=null,lsFail=0;
const save=()=>{S._u=Date.now();lsFail=0;const sj=JSON.stringify(S);try{localStorage.setItem('qmrm',sj)}catch(e){lsFail=1}
 clearTimeout(idbT);idbT=setTimeout(()=>{idb.set('S',sj).catch(()=>{if(lsFail)try{synBar('تعذّر الحفظ على هذا الجهاز (المساحة ممتلئة). قلّل عدد الصور أو تأكد أن المزامنة السحابية تعمل.',1)}catch(x){dbg(x)}})},400);
 push()};
const $=s=>document.querySelector(s),ymd=d=>d.toLocaleDateString('en-CA'),hm=d=>d.toTimeString().slice(0,5);
const hij=d=>d.toLocaleDateString(S.lang=='en'?'en-u-ca-islamic-umalqura':'ar-SA-u-ca-islamic-umalqura',{day:'numeric',month:'long',year:'numeric'});
const esc=s=>String(s).replace(/[&<>"'`]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;','`':'&#96;'}[c]));
let tab='home',qz=null,rev=false,qn=0,qok=0,addDays=[0,1,2,3,4,6];
const tabs=(I=>[['home',I('<path d="M12 6.5C10.3 5.2 7.8 4.6 4 4.8v13c3.8-.2 6.3.4 8 1.7 1.7-1.3 4.2-1.9 8-1.7v-13c-3.8-.2-6.3.4-8 1.7zM12 6.5v13"/>'),'اليوم'],['pr',I('<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>'),'الصلاة'],['td',I('<rect x="4" y="4" width="16" height="16" rx="4"/><path d="m8.5 12.3 2.5 2.5 4.5-5"/>'),'المهمات'],['tc',I('<circle cx="9" cy="8.5" r="3.2"/><path d="M3.5 19c.4-3.2 2.7-5 5.5-5s5.1 1.8 5.5 5"/><circle cx="17" cy="9.5" r="2.4"/><path d="M16.5 14.2c2.4-.2 4 1.3 4.3 3.8"/>'),'طالب ومعلم'],['ar',I('<rect x="3.5" y="4.5" width="17" height="4.5" rx="1.5"/><path d="M5 9v9a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 18V9M10 13h4"/>'),'الأرشيف']])(p=>'<span class="ic"><svg viewBox="0 0 24 24">'+p+'</svg></span>');
function go(t){if(t!='tc'&&typeof tcChClose=='function')tcChClose();if(typeof exStop=='function'&&t!='ex')exStop();if(t=='se'&&fbOK&&!fu){tab='home';draw();awMode='in';awShow();return}if(tab=='pv'&&t!='pv')pvOk=false;if(tab=='ar'&&t!='ar'){pvOk=false;arPvOpen=false}if(t=='gl'&&tab!='gl'){glOpen=0;glDr=null;glOrd=false}tab=t;draw()}
let drawnTab=null;
function draw(){
 $('#nav').innerHTML=tabs.map(([k,i,n])=>`<button type="button" class="${k==tab||(k=='td'&&tab=='gl')?'on':''}" onclick="go('${k}')">${i}<br>${n}</button>`).join('');
 const vm=$('#v'),chg=tab!==drawnTab,y0=window.scrollY;drawnTab=tab;vm.classList.toggle('na',!chg);
 vm.innerHTML={home:home,jz:jz,al:alarms,st:stats,ar:archive,nb:notebook,se:settings,ap:appearance,re:reminders,ct:conts,bk:backup,pr:prayer,td:todos,pv:privPage,gl:goalsPage,ex:examPage,rv:revPage,wr:wrdPage,jm:jmPage,hp:hpPage,kh:khPage,tc:tcPage}[tab]();
 if(!chg&&Math.abs(window.scrollY-y0)>1){try{window.scrollTo({top:y0,behavior:'instant'})}catch(e){window.scrollTo(0,y0)}}
}
/* ---------- المهام ---------- */
function due(){const e=new Date();e.setHours(23,59,59);return S.tasks.filter(t=>!t.arch&&new Date(t.next)<=e)}
let qAdd=false,qTim=false;
const qIC={timer:'<circle cx="12" cy="13" r="7.5"/><path d="M12 9.5V13l2.3 1.6M9.5 3h5"/>',play:'<path d="M8 5.5v13l10.5-6.5z"/>',undo:'<path d="M4 12a8 8 0 1 0 2.6-5.9M4 4v4.5h4.5"/>',check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>',box:'<rect x="3.5" y="4.5" width="17" height="4.5" rx="1.5"/><path d="M5 9v9.2c0 .7.6 1.3 1.3 1.3h11.4c.7 0 1.3-.6 1.3-1.3V9M10 13h4"/>',trash:'<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l.8 12.2c0 .7.6 1.3 1.3 1.3h6.8c.7 0 1.3-.6 1.3-1.3L17.5 7M10 11v6M14 11v6"/>',plus:'<path d="M12 5v14M5 12h14"/>',cal:'<rect x="4" y="5.5" width="16" height="14.5" rx="3"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',pen:'<path d="M4 20l1-4.2L16.3 4.5a2 2 0 0 1 2.8 0l.4.4a2 2 0 0 1 0 2.8L8.2 19z"/>',grid:'<rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/>',moon:'<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',flame:'<path d="M12 3c1 3.2 4.5 5.2 4.5 9.5A4.5 4.5 0 0 1 12 17a4.5 4.5 0 0 1-4.5-4.5c0-2 1-3.2 2-4.2.2 1.2.8 2 1.6 2.4C11 8.5 11.3 5.5 12 3zM9.5 20.5h5"/>',doc:'<path d="M7 3.5h7l4 4V20a.5.5 0 0 1-.5.5h-10.5A.5.5 0 0 1 6.5 20V4a.5.5 0 0 1 .5-.5zM14 3.5v4h4M9 13h6M9 16.5h6"/>'};
const qic=n=>`<span class="ic"><svg viewBox="0 0 24 24">${qIC[n]}</svg></span>`;
function homeHero(){const n=new Date(),d=due(),td=S.logs.filter(l=>l.date==ymd(n)).length,tot=td+d.length,pct=tot?Math.round(td/tot*100):0,st=streak(),h=n.getHours(),
 gr=h<5?'ليلة مباركة':h<12?'صباح الخير':h<17?'نهارك سعيد':h<20?'مساء الخير':'مساء النور',nm=((prof().name||'').trim().split(' ')[0])||'';
 const dk=ymd(n);if(!homeHero.c||homeHero.c.k!=dk){let hj='',gd='';try{hj=n.toLocaleDateString('ar-SA-u-ca-islamic-umalqura-nu-latn',{day:'numeric',month:'long',year:'numeric'});gd=n.toLocaleDateString('ar-SY-u-nu-latn',{weekday:'long',day:'numeric',month:'long'})}catch(e){}homeHero.c={k:dk,hj,gd}}const{hj,gd}=homeHero.c;
 return `<section class="bento"><div class="bt hi"><div class="hr-g">${gr}${nm?'، '+esc(nm):''}</div><div class="hr-d">${hj}</div><div class="hr-m">${gd}</div></div><div class="bt rg"><div class="ring"><svg viewBox="0 0 80 80"><circle class="rb" cx="40" cy="40" r="34"/><circle class="rf" cx="40" cy="40" r="34" stroke-dasharray="${(213.6*pct/100).toFixed(1)} 213.6"/></svg><b>${pct}%</b></div><span>إنجاز اليوم</span></div><div class="bt s1"><b>${d.length}</b><span>مهام متبقية</span></div><div class="bt s2"><b>${st}</b><span>يوم متواصل</span></div></section>`}
function homeQA(){const A=[['qAdd=!qAdd;draw()','plus','مهمة جديدة',qAdd],["go('rv')",'cal','المراجعة'],["go('ex')",'pen','اختبار'],["go('jm')",'grid','الأجزاء'],['qTim=!qTim;draw()','timer','المؤقت',qTim]];
 return `<div class="qa">${A.map(a=>`<button type="button" class="${a[3]?'on':''}" onclick="${a[0]}">${qic(a[1])}<span>${a[2]}</span></button>`).join('')}</div>`}
function home(){
 const d=due();
 return `${remBox()}${homeHero()}${homeQA()}<div class="c${qTim?'':' hid'}" id="tbox">${tbox()}</div>
 ${qAdd?`<div class="c frm"><b>مهمة جديدة</b>
 <div class="row" style="flex-wrap:nowrap;gap:6px"><input id="ts" value="${esc(pkTgt?'':pkSum())}" placeholder="اكتب المهمة أو اختر: سور / أجزاء / صفحات" autocomplete="off" oninput="selClear()" style="flex:1;margin:0;min-width:0"><button type="button" onclick="pkOpen()" style="padding:10px 14px">${svg('plus')} اختيار</button></div><input id="tn" placeholder="اسم المهمة (اختياري)" autocomplete="off">
 <div class="row"><input id="ta" type="number" placeholder="من آية" style="flex:1"><input id="tb" type="number" placeholder="إلى آية" style="flex:1"></div>
 <select id="tt"><option>حفظ</option><option>مراجعة</option></select>
 <input id="tc" type="text" autocomplete="off" placeholder="مدة التايمر (اكتبها أنت، مثال 25 أو 1:30)">
 
 <button type="button" onclick="addTask()">إضافة</button>
 <label class="m"><input type="checkbox" style="width:auto" ${S.skipFri?'checked':''} onchange="S.skipFri=this.checked;save()"> استثناء يوم الجمعة من الجدولة</label></div>`:''}
 <div class="sec">مهام اليوم<span class="tkc">${d.length}</span></div>`+
 (d.map(t=>{const sub=jl(t),g=isG(t),op=tkOpen[t.id],m=t.tm;return `<div class="c tkcard"><div class="row" style="flex-wrap:nowrap;gap:10px;align-items:flex-start"><div style="flex:1;min-width:0"><b style="${t.mk==1?'text-decoration:line-through;color:var(--mut)':t.mk==2?'color:var(--bad)':''}">${g?esc(t.s):'سورة '+esc(t.s)}</b><div class="m">${t.type}${g?(sub&&sub!==t.s?' • '+esc(sub):''):' • '+t.a+'–'+t.b}</div></div><button type="button" class="g" style="padding:4px 10px" onclick="tkEdit(${t.id})">${svg('edit')}</button><button type="button" class="g" style="padding:4px 10px" onclick="tkUnits(${t.id})">تعديل الأجزاء</button></div>
  ${m?tmHtml(t):''}
  <div class="row" style="margin-top:8px">${m?'':`<button type="button" class="g" onclick="tmNew(${t.id})">${qic('timer')} تايمر</button>`}<button type="button" class="g" onclick="startT(${t.id})">${t.st?qic('timer')+' بدأت '+hm(new Date(t.st)):qic('play')+' ابدأ'}</button>${t.st?`<button type="button" class="g" onclick="tkRs(${t.id})">${qic('undo')} البداية</button>`:''}<button type="button" onclick="rate(${t.id})">${qic('check')} تم</button><button type="button" class="g" onclick="archT(${t.id},true)">${qic('box')}</button><button type="button" class="g" onclick="ask('هل تريد حذف المهمة؟',()=>delT(${t.id}),'نعم، احذف')">${qic('trash')}</button></div>
  <div class="m" style="margin-top:8px;cursor:pointer" onclick="tkOpen[${t.id}]=!tkOpen[${t.id}];draw()">${op?'▴':'▾'} تفاصيل المهمة</div>${op?`<div class="m" style="line-height:1.9">بدأت: ${t.st?dt(t.st):'لم تبدأ بعد'}<br>انتهت: لم تنتهِ بعد${m?`<br>الوقت الأصلي: ${hms(mOrig(m))} • المستغرق: ${hms(mUsed(m))}${mOver(m)?' • الزائد: '+hms(mOver(m)):''}`:''}</div>`:''}</div>`}).join('')||'<div class="c m">لا مهام اليوم، بارك الله فيك 🌿</div>');
}


/* ---------- جدول المراجعة: خطة شهرية بأجزائك المحفوظة (من خريطة الأجزاء) ---------- */
const rvDay=d=>{const x=new Date(d);x.setHours(0,0,0,0);return x};
const rvMem=()=>[...Array(30)].map((_,i)=>i+1).filter(j=>jmM(j)==2);
const rvN=()=>Math.max(1,Math.min(10,Math.floor(+S.rvn)||1));
const rvLast=j=>{const J=(S.juz||{})[j]||{};return J.last?rvDay(new Date(J.last)):null};
const rvOrd=(mem,L)=>mem.slice().sort((a,b)=>(L[a]?L[a].getTime():-1)-(L[b]?L[b].getTime():-1)||a-b);
function rvPlan(n){const mem=rvMem(),N=Math.min(rvN(),mem.length||1),t=rvDay(new Date()),tk=t.getTime(),L={};mem.forEach(j=>L[j]=rvLast(j));
 const isT=j=>L[j]&&L[j].getTime()==tk,dn=mem.filter(isT),td=[...dn,...rvOrd(mem.filter(j=>!isT(j)),L).slice(0,Math.max(0,N-dn.length))],pend=td.filter(j=>!isT(j));
 const days=[{d:t,juz:td,pend,done:dn,off:false}];td.forEach(j=>L[j]=t);
 for(let k=1;k<n;k++){const d=new Date(t);d.setDate(t.getDate()+k);
  if(S.skipFri&&d.getDay()==5){days.push({d,juz:[],off:true});continue}
  const pk=rvOrd(mem,L).slice(0,N);pk.forEach(j=>L[j]=d);days.push({d,juz:pk.slice().sort((a,b)=>a-b),off:false})}
 return days}
const rvDue=()=>rvPlan(1)[0].pend;
const rvGap=()=>{const M=rvMem().length;return M?Math.ceil(M/Math.min(rvN(),M)):0};
const rvDT=n=>n==1?'يوم':n==2?'يومان':n<=10?n+' أيام':n+' يوماً';
const rvCard=()=>{const n=rvDue().length;return n?`<div class="c" onclick="go('rv')" style="cursor:pointer;border-color:var(--pri)"><div class="row sp"><b>🗓 جدول المراجعة</b><span class="ch">${svg('chev')}</span></div><div class="m">${n==1?'جزء واحد':n==2?'جزءان':n<=10?n+' أجزاء':n+' جزءاً'} للمراجعة اليوم</div></div>`:''};
function rvRev(j){jAdd(j,1);toast('سُجّلت مراجعة الجزء '+j);draw()}
function rvTask(j){if((S.tasks||[]).some(t=>!t.arch&&t.type=='مراجعة'&&t.j==j&&!t.pg&&!t.js&&!t.sur)){toast('المراجعة موجودة في مهامك');return}
 S.tasks.push({id:S.id++,s:'الجزء '+j,j:j,tm:null,a:1,b:1,type:'مراجعة',stage:0,next:new Date().toISOString(),g:1});save();toast('أُضيف الجزء '+j+' إلى مهام اليوم');draw()}
function rvUndo(j){jSub(j);toast('أُلغيت مراجعة الجزء '+j)}
function rvSetN(v){S.rvn=Math.max(1,Math.min(10,+v||1));save();draw()}
function revPage(){
 const mem=rvMem(),M=mem.length,head=`<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">جدول المراجعة</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>`;
 if(!M)return head+`<div class="c m">لا أجزاء محفوظة بعد. افتح خريطة الأجزاء وحدّد الأجزاء التي حفظتها، فأضع لك خطة شهرية لمراجعتها بحيث لا يُنسى جزء.<button type="button" style="width:100%;margin-top:8px" onclick="go('jm')">فتح خريطة الأجزاء</button></div>`;
 const N=Math.min(rvN(),M),P=rvPlan(30),T=P[0],cyc=Math.ceil(M/N),nm=a=>a.length==1?'الجزء '+a[0]:'الأجزاء '+a.join('، '),
  opts=[...Array(Math.min(10,M))].map((_,i)=>`<option value="${i+1}" ${i+1==N?'selected':''}>${i+1}</option>`).join('');
 return head+`<div class="c"><b>حفظت ${M==1?'جزءاً واحداً':M==2?'جزأين':M<=10?M+' أجزاء':M+' جزءاً'}</b>
 <div class="row" style="flex-wrap:nowrap;gap:8px;align-items:center;margin:8px 0"><span class="m" style="white-space:nowrap">كم جزءاً تراجع في اليوم؟</span><select onchange="rvSetN(this.value)" style="margin:0">${opts}</select></div>
 <div class="m">بهذه الخطة يعود إليك كل جزء كل ${rvDT(cyc)} تقريباً. تُراجَع الأجزاء كلها بالترتيب، الأقدم مراجعةً أولاً، فلا يُنسى جزء.</div></div>
 <div class="c"><b>مراجعة اليوم</b><div class="m">${T.pend.length?'تبقّى '+T.pend.length+' من '+T.juz.length:'أتممت مراجعة اليوم، بارك الله فيك 🌿'}</div>${T.juz.map(j=>{const dn=T.done.includes(j),ag=jmAge(j);
  return `<div class="row" style="flex-wrap:nowrap;gap:8px;padding:8px 0;border-top:1px solid var(--bd)"><div style="flex:1"><b>الجزء ${j}</b><div class="m">${exPages(j)} صفحة • ${ag===null?'لم يُراجع بعد':'آخر مراجعة '+(ag==0?'اليوم':'قبل '+ag+' يوم')}</div></div>${dn?'<span class="row" style="gap:8px;flex-wrap:nowrap"><span class="m" style="color:var(--pri);font-weight:700">✅ تمت</span><button type="button" class="g" style="padding:6px 12px" onclick="rvUndo('+j+')">↩ تراجع</button></span>':`<span class="row" style="gap:6px;flex-wrap:nowrap"><button type="button" class="g" style="padding:6px 12px" onclick="rvTask(${j})">➕ إضافة إلى المهام</button><button type="button" style="padding:6px 12px" onclick="rvRev(${j})">✅ راجعته</button></span>`}</div>`}).join('')}</div>
 <div class="c"><b>الخطة الشهرية</b><div class="m" style="margin-bottom:4px">الأيام الثلاثون القادمة، وتتحدّث تلقائياً كلما سجّلت مراجعة.</div>${P.map((r,i)=>`<div class="row" style="flex-wrap:nowrap;gap:8px;padding:7px 6px;border-top:1px solid var(--bd);${i==0?'background:color-mix(in srgb,var(--pri) 10%,transparent);border-radius:8px':''}"><span class="m" style="width:86px;flex:none">${i==0?'اليوم':D[r.d.getDay()]+' '+ymd(r.d).slice(5)}</span><b style="flex:1;font-size:14px">${r.off?'<span class="m">إجازة</span>':nm(r.juz)}</b></div>`).join('')}</div>`}

/* ---------- الورد اليومي المقترح: يحسب كمية الحفظ اليومية لتنهي هدفك في موعد تحدده ---------- */
const WRL=15;let wrdEdit=0;
const wrdG=()=>S.wrd&&S.wrd.due?S.wrd:null;
const wrdUn=()=>'<option value="p">صفحة</option><option value="j">جزء</option><option value="h">حزب</option>';
const wrdPgOf=(v,u,snap)=>{v=Math.max(0,+v||0);const p=u=='j'?(snap&&v>=30?604:v*20):u=='h'?(snap&&v>=60?604:v*10):v;return Math.min(604,p)};
const wrdLn=v=>Math.max(0,Math.round((+v||0)*WRL));
const wrdPg=l=>{const v=Math.round(l/WRL*10)/10;return String(v).replace(/\.0$/,'')};
function wrdTxt(l){l=Math.max(0,Math.round(l));if(!l)return 'لا شيء';const p=Math.floor(l/WRL),r=l%WRL,
 ps=p==0?'':p==1?'صفحة':p==2?'صفحتان':p<=10?p+' صفحات':p+' صفحة',
 rs=r==0?'':r==1?'سطر':r==2?'سطران':r<=10?r+' أسطر':r+' سطراً';
 return [ps,rs].filter(Boolean).join(' و')}
function wrdQtr(l){const n=Math.round(l/WRL*4),w=Math.floor(n/4),r=n%4;if(n<=0)return 'أقل من ربع صفحة';
 const q=['','ربع','نصف','ثلاثة أرباع'][r];if(!w)return q+' صفحة';
 const ps=w==1?'صفحة':w==2?'صفحتان':w<=10?w+' صفحات':w+' صفحة';return r?ps+' و'+q:ps}
const WRX=[[0,'حسب موعدي (تلقائي)'],[4,'ربع صفحة'],[8,'نصف صفحة'],[15,'صفحة'],[30,'صفحتان'],[75,'5 صفحات'],[150,'حزب (10 صفحات)'],[300,'جزء (20 صفحة)']];
function wrdFix(v){const W=wrdG();if(!W)return;W.fix=+v||0;save();draw()}
const wrdDate=t=>{const a=String(t).split('-');return new Date(+a[0],a[1]-1,+a[2])};
const wrdPz=(d,W)=>{const t=ymd(d);return (W.pz||[]).some(p=>t>=p.a&&t<=p.b)};
function wrdDays(a,b,fr,W){let n=0;const d=new Date(a),e=new Date(b);d.setHours(0,0,0,0);e.setHours(0,0,0,0);for(let i=0;d<=e&&i<6000;i++){if(!(fr&&d.getDay()==5)&&!(W&&wrdPz(d,W)))n++;d.setDate(d.getDate()+1)}return n}
function wrdCalc(){const W=wrdG();if(!W)return null;const today=new Date();today.setHours(0,0,0,0);const td=ymd(today),
 done=W.base+W.log.reduce((a,x)=>a+x.l,0),dToday=W.log.filter(x=>x.d==td).reduce((a,x)=>a+x.l,0),before=done-dToday,rem=Math.max(0,W.total-done),
 days=wrdDays(today,wrdDate(W.due),W.fr,W),auto=days>0?Math.ceil(Math.max(0,W.total-before)/days):0,fix=W.fix||0,daily=fix||auto;
 let eta=null,etaD=0;if(fix&&rem>0){const need=Math.ceil(Math.max(0,W.total-before)/fix),d=new Date(today);let n=0;for(let i=0;i<20000;i++){if(!(W.fr&&d.getDay()==5)&&!wrdPz(d,W)){n++;if(n>=need)break}d.setDate(d.getDate()+1)}eta=d;etaD=Math.round((wrdDate(W.due)-d)/864e5)}
 return{W,tot:W.total,done,dToday,rem,days,daily,auto,fix,eta,etaD,paused:wrdPz(today,W),pct:Math.min(100,Math.round(done/W.total*100)),late:wrdDate(W.due)<today,fin:rem<=0}}
const wrdCard=()=>{const c=wrdCalc();if(!c||c.fin||c.paused||((c.late||c.days<=0)&&!c.fix)||c.dToday>=c.daily)return '';return `<div class="c" onclick="go('wr')" style="cursor:pointer;border-color:var(--pri)"><div class="row sp"><b>📖 وردك اليوم</b><span class="ch">${svg('chev')}</span></div><div class="m">${wrdTxt(c.daily-c.dToday)}${c.dToday?' (متبقٍ من وردك)':''}</div></div>`};
function wrdQ(m){const d=new Date();d.setMonth(d.getMonth()+m);const i=$('#wrdd');if(i)i.value=ymd(d)}
function wrdSave(){const tot=Math.min(604,Math.max(1,wrdPgOf($('#wrdt').value,$('#wrdtu').value,1))),base=Math.min(tot,wrdPgOf($('#wrdb').value,$('#wrdbu').value,1)),due=$('#wrdd').value;
 if(!due||wrdDate(due)<new Date(new Date().setHours(0,0,0,0))){toast('اختر موعد إنهاء قادماً');return}
 const old=S.wrd||{};S.wrd={total:wrdLn(tot),base:wrdLn(base),due,fr:$('#wrdf').checked,start:old.start||ymd(new Date()),log:old.log||[],fix:old.fix||0,pz:old.pz||[],rr:old.rr||0};
 wrdEdit=0;save();toast('تم حفظ الخطة');draw()}
function wrdAdd(l){const c=wrdCalc();if(!c||l<=0)return;S.wrd.log.push({id:S.id++,d:ymd(new Date()),l:Math.min(l,c.rem)});save();draw()}
function wrdAddT(){const c=wrdCalc();if(c)wrdAdd(Math.max(0,c.daily-c.dToday))}
function wrdCustom(){const l=wrdLn(wrdPgOf($('#wrdc').value,$('#wrdcu').value));if(!l){toast('اكتب الكمية');return}wrdAdd(l)}
function wrdUndo(){const W=wrdG();if(!W||!W.log.length)return;W.log.pop();save();draw()}
function wrdReset(){ask('حذف خطة الورد اليومي وسجلها؟',()=>{S.wrd=null;wrdEdit=0;save();draw()},'نعم، احذف')}
let wrdS={t:new Set(),b:new Set()};
const wrdGrid=k=>`<div class="exg">${[...Array(30)].map((_,i)=>{const j=i+1;return `<div class="exj${wrdS[k].has(j)?' on':''}" style="cursor:pointer;min-height:36px;padding:8px 0" onclick="wrdTg('${k}',${j})">${j}</div>`}).join('')}</div>`;
function wrdTg(k,j){const st=wrdS[k];st.has(j)?st.delete(j):st.add(j);const pg=[...st].reduce((a,x)=>a+exPages(x),0),inp=$(k=='t'?'#wrdt':'#wrdb'),un=$(k=='t'?'#wrdtu':'#wrdbu');
 $('#wrdg'+k).innerHTML=wrdGrid(k);inp.value=st.size?pg:'';un.value='p';$('#wrdi'+k).textContent=st.size?st.size+' '+(st.size==1?'جزء':'أجزاء')+' = '+pg+' صفحة (حسب صفحات المصحف الفعلية)':''}
function wrdOpen(k){const g=$('#wrdg'+k);if(!g)return;g.style.display=g.style.display=='none'?'block':'none';if(g.style.display=='block')g.innerHTML=wrdGrid(k)}
function wrdForm(){wrdS={t:new Set(),b:new Set()};const W=S.wrd,c=W?wrdCalc():null;
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">الورد اليومي</b><button type="button" class="g" onclick="${W?'wrdEdit=0;draw()':"go('home')"}">رجوع</button></div>
 <div class="c"><div class="m">كم صفحة تريد حفظها بالمجموع؟</div><div class="row" style="flex-wrap:nowrap;gap:6px"><input id="wrdt" type="number" inputmode="decimal" min="1" step="0.5" value="${W?wrdPg(W.total):604}" style="flex:1;margin:0;min-width:0"><select id="wrdtu" style="width:auto;margin:0">${wrdUn()}</select></div><div class="m" style="color:var(--pri);cursor:pointer;margin-top:4px" onclick="wrdOpen('t')">▾ أو اختر أجزاء محددة</div><div id="wrdgt" style="display:none;margin:6px 0"></div><div class="m" id="wrdit"></div>
 <div class="m">كم صفحة حفظت حتى الآن؟</div><div class="row" style="flex-wrap:nowrap;gap:6px"><input id="wrdb" type="number" inputmode="decimal" min="0" step="0.5" value="${W?wrdPg(W.base):0}" placeholder="مثال: 5" style="flex:1;margin:0;min-width:0"><select id="wrdbu" style="width:auto;margin:0">${wrdUn()}</select></div><div class="m" style="color:var(--pri);cursor:pointer;margin-top:4px" onclick="wrdOpen('b')">▾ أو اختر الأجزاء التي حفظتها</div><div id="wrdgb" style="display:none;margin:6px 0"></div><div class="m" id="wrdib"></div>
 <div class="m" style="margin-top:6px">الجزء = 20 صفحة تقريباً، والحزب = 10 صفحات (و30 جزءاً = المصحف كاملاً 604 صفحة)</div><div class="m">موعد إنهاء الحفظ</div><input id="wrdd" type="date" value="${W?W.due:''}">
 <div style="margin:6px 0">${[['6 أشهر',6],['سنة',12],['سنتان',24],['3 سنوات',36]].map(([t,m])=>`<span class="chip" onclick="wrdQ(${m})">${t}</span>`).join('')}</div>
 <label class="m"><input id="wrdf" type="checkbox" style="width:auto" ${!W||W.fr?'checked':''}> استثناء يوم الجمعة من أيام الحفظ</label>
 <button type="button" onclick="wrdSave()" style="width:100%;margin-top:10px">${W?'حفظ التعديل':'احسب وردي وابدأ'}</button></div>`}
function wrdPage(){const c=wrdCalc();if(!c||wrdEdit)return wrdForm();
 const rem=c.fin?'':`<div class="m" style="margin-top:6px">المتبقي ${wrdTxt(c.rem)} • ${c.days} يوم حفظ حتى ${c.W.due}</div>${c.fix&&c.eta?`<div class="m" style="margin-top:4px">بهذا الورد تنهي في ${ymd(c.eta)} ${c.etaD>0?'(قبل موعدك بـ '+c.etaD+' يوماً)':c.etaD<0?'(بعد موعدك بـ '+(-c.etaD)+' يوماً)':'(في موعدك تماماً)'}</div>`:''}<div class="row" style="flex-wrap:nowrap;gap:8px;margin-top:10px;align-items:center"><span class="m" style="white-space:nowrap">مقدار الورد:</span><select onchange="wrdFix(this.value)" style="margin:0">${WRX.map(x=>`<option value="${x[0]}" ${x[0]==c.fix?'selected':''}>${x[1]}</option>`).join('')}</select></div>${wrdRr(c)}`,
 hist=c.W.log.slice(-5).reverse().map(x=>`<div class="m" style="padding:4px 0;border-top:1px solid var(--bd)">${x.d} • ${wrdTxt(x.l)}</div>`).join('');
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">الورد اليومي</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>
 <div class="c" style="text-align:center">${c.fin?'<b style="font-size:20px">ما شاء الله، أتممت هدفك 🎉</b>':c.paused?`<div class="m">اليوم إجازة</div><b style="font-size:24px;display:block;margin:4px 0">🌴 لا ورد عليك اليوم</b><div class="m">يعود وردك بعد الإجازة: ${wrdTxt(c.daily)} يومياً</div>`:(c.late&&!c.fix)?'<b style="font-size:17px">انتهى الموعد الذي حددته، عدّل الخطة بموعد جديد</b>':(c.days<=0&&!c.fix)?'<b style="font-size:17px">لا توجد أيام حفظ قبل الموعد، عدّل الخطة</b>':`<div class="m">وردك اليوم</div><b style="font-size:26px;display:block;margin:4px 0">${c.fix?(WRX.find(x=>x[0]==c.fix)||[0,wrdTxt(c.daily)])[1]:wrdTxt(c.daily)}</b><div class="m" style="margin-bottom:4px">${c.fix?'= '+wrdTxt(c.daily)+' تقريباً':'≈ '+wrdQtr(c.daily)}</div><div class="m">${c.dToday>=c.daily?'أتممت وردك اليوم، بارك الله فيك 🌿':'أنجزت اليوم '+wrdTxt(c.dToday)}</div>`}
 <div style="background:var(--bd);border-radius:10px;height:12px;margin-top:12px;overflow:hidden"><div style="width:${c.pct}%;height:100%;background:var(--pri)"></div></div>
 <div class="m" style="margin-top:6px">حفظت ${wrdPg(c.done)} من ${wrdPg(c.tot)} صفحة (${c.pct}%)</div>${rem}</div>
 ${c.fin||((c.late||c.days<=0)&&!c.fix)?'':`<div class="c"><b>تسجيل الحفظ</b><div class="row" style="margin-top:8px;gap:6px"><button type="button" style="flex:1" onclick="wrdAddT()" ${c.dToday>=c.daily?'disabled style="flex:1;opacity:.5"':''}>✅ أنجزت وردي</button><button type="button" class="g" onclick="wrdAdd(${WRL})">+ صفحة</button><button type="button" class="g" onclick="wrdAdd(${WRL/2|0})">+ نصف صفحة</button></div>
 <div class="row" style="flex-wrap:nowrap;gap:6px;margin-top:8px"><input id="wrdc" type="number" inputmode="decimal" step="0.5" min="0" placeholder="كمية أخرى" style="flex:1;margin:0;min-width:0"><select id="wrdcu" style="width:auto;margin:0">${wrdUn()}</select><button type="button" class="g" onclick="wrdCustom()">إضافة</button></div></div>`}
 ${hist?`<div class="c"><div class="row sp"><b>آخر التسجيلات</b><button type="button" class="g" style="padding:4px 10px" onclick="wrdUndo()">↩ تراجع عن الأخير</button></div>${hist}</div>`:''}
 ${wrdPzCard(c)}<div class="row" style="padding:0 14px;gap:6px"><button type="button" class="g" style="flex:1" onclick="wrdEdit=1;draw()">تعديل الخطة</button><button type="button" class="g" style="flex:1" onclick="wrdReset()">حذف الخطة</button></div>`}

/* ---------- نسبة المراجعة مع الورد + إجازة الورد ---------- */
const WRR=[[0,'بدون'],[1,'1 : 1 (راجع بمقدار ما تحفظ)'],[2,'2 : 1 (ضعف الحفظ)'],[3,'3 : 1 (ثلاثة أضعاف)']];
function wrdSetRr(v){const W=wrdG();if(!W)return;W.rr=+v||0;save();draw()}
function wrdRr(c){const W=c.W,k=W.rr||0,sh={1:'نصف',2:'ثلثا',3:'ثلاثة أرباع'}[k];
 return `<div class="row" style="flex-wrap:nowrap;gap:8px;margin-top:8px;align-items:center"><span class="m" style="white-space:nowrap">المراجعة مع الورد:</span><select onchange="wrdSetRr(this.value)" style="margin:0">${WRR.map(x=>`<option value="${x[0]}" ${x[0]==k?'selected':''}>${x[1]}</option>`).join('')}</select></div>${k&&!c.fin&&!c.paused&&c.daily?`<div class="c" style="margin:10px 0 0;background:transparent;border-style:dashed"><div class="row sp"><span>📖 حفظ جديد</span><b>${wrdTxt(c.daily)}</b></div><div class="row sp"><span>🔁 مراجعة</span><b>${wrdTxt(Math.round(c.daily*k))}</b></div><div class="row sp" style="border-top:1px solid var(--bd);margin-top:4px;padding-top:4px"><span>المجموع</span><b>${wrdTxt(Math.round(c.daily*(1+k)))}</b></div><div class="m" style="margin-top:4px">${sh} الجلسة مراجعة. افتح جدول المراجعة لتعرف ما تراجعه.</div><button type="button" class="g" style="width:100%;margin-top:6px" onclick="go('rv')">🗓 جدول المراجعة</button></div>`:''}`}
function wrdPzCard(c){const W=c&&c.W;if(!W)return '';const t=ymd(new Date()),L=(W.pz||[]).filter(p=>p.b>=t).sort((x,y)=>x.a.localeCompare(y.a));
 return `<div class="c"><b>🌴 إجازة الورد</b><div class="m" style="margin:4px 0">للسفر أو المرض أو رمضان: تُستثنى هذه الأيام ويُعاد حساب وردك على الأيام المتبقية.</div><div class="row" style="flex-wrap:nowrap;gap:6px"><input id="wrpa" type="date" style="flex:1;margin:0;min-width:0"><input id="wrpb" type="date" style="flex:1;margin:0;min-width:0"></div><div class="m" style="margin-top:4px">من تاريخ إلى تاريخ (النهاية اختيارية ليوم واحد)</div><div class="row" style="margin-top:8px;gap:6px"><button type="button" style="flex:1" onclick="wrdPzAdd()">إضافة إجازة</button><button type="button" class="g" style="flex:1" onclick="wrdPzToday()">إجازة اليوم فقط</button></div>${L.map(p=>`<div class="row sp" style="padding:6px 0;border-top:1px solid var(--bd)"><span class="m">${p.a==p.b?p.a:p.a+' ← '+p.b}</span><button type="button" class="g" style="padding:2px 10px" onclick="wrdPzDel(${p.id})">حذف</button></div>`).join('')}</div>`}
function wrdPzPush(a,b){const W=wrdG();if(!W)return;(W.pz=W.pz||[]).push({id:S.id++,a,b});save();toast('تمت إضافة الإجازة');draw()}
function wrdPzAdd(){const a=$('#wrpa').value,b=$('#wrpb').value||a;if(!a){toast('اختر تاريخ بداية الإجازة');return}if(b<a){toast('تاريخ النهاية قبل البداية');return}wrdPzPush(a,b)}
function wrdPzToday(){const t=ymd(new Date());wrdPzPush(t,t)}
function wrdPzDel(id){const W=wrdG();if(!W)return;W.pz=(W.pz||[]).filter(p=>p.id!=id);save();draw()}

/* ---------- خريطة الأجزاء: لون لكل جزء حسب دورة مراجعتك ---------- */
const JMC={'0':['#8a948f','لم يُحفظ'],'1':['#1565c0','قيد الحفظ'],g:['#2e7d32','ضمن دورة مراجعتك'],y:['#f9a825','تأخر قليلاً عن دورتك'],r:['#c62828','تأخر كثيراً أو لم يُراجع بعد']};
const jmM=j=>{const m=(S.jm||{})[j];return m!==undefined?m:(((S.juz||{})[j]||{}).n>0?2:0)};
function jmDays(j){const J=(S.juz||{})[j]||{};return J.last?Math.floor((Date.now()-new Date(J.last))/864e5):null}
function jmBase(j){const L=rvLast(j);if(L)return L;const a=(S.jma||{})[j];return a?rvDay(new Date(a)):null}
const jmAge=j=>{const b=jmBase(j);return b?Math.round((rvDay(new Date())-b)/864e5):null};
function jmSt(j){const m=jmM(j);if(m==0)return '0';if(m==1)return '1';return 'g'}
function jmPage(){const st=[...Array(30)].map((_,i)=>jmSt(i+1)),cnt=k=>st.filter(x=>x==k).length,mem=st.filter(x=>'gyr'.includes(x)).length,PL=rvPlan(30),nxd=j=>PL.findIndex((r,i)=>r.juz.includes(j)&&(i>0||!PL[0].done.includes(j)));
 const tile=j=>{const k=st[j-1],c=JMC[k][0],x=k=='g'?nxd(j):-1,sm=k=='0'||k=='1'?JMC[k][1]:x<0?'—':x==0?'اليوم':x==1?'غداً':'بعد '+x+' ي';
  return `<div class="exj" style="border-color:${c};background:color-mix(in srgb,${c} 18%,transparent);cursor:pointer;min-height:62px;padding:8px 0" onclick="jmOpen(${j})"><b style="font-size:18px">${j}</b><small style="font-size:10px;opacity:.85">${sm}</small></div>`};
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">خريطة الأجزاء</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>
 <div class="c"><div class="row" style="gap:12px"><div style="flex:1;text-align:center">محفوظ<br><b style="font-size:22px">${mem}</b> <span class="m">من 30</span></div><div style="flex:1;text-align:center">للمراجعة اليوم<br><b style="font-size:22px">${rvDue().length}</b></div></div></div>
 <div class="c"><div class="exg">${[...Array(30)].map((_,i)=>tile(i+1)).join('')}</div>
 <div style="margin-top:10px">${['0','1','g'].map(k=>`<div class="m" style="padding:2px 0"><span style="display:inline-block;width:12px;height:12px;border-radius:4px;background:${JMC[k][0]};vertical-align:middle;margin-inline-end:6px"></span>${JMC[k][1]}</div>`).join('')}</div></div>
 <div class="m" style="margin:0 16px">اضغط على جزء لتحديد حالته. الأجزاء التي تحددها «محفوظة» تدخل خطة المراجعة الشهرية، وكل مراجعة تسجّلها تُحتسب في جدول الأجزاء.</div>`}
function jmOpen(j){const k=jmSt(j),m=jmM(j),J=(S.juz||{})[j]||{},d=jmDays(j),b=(v,t)=>`<button type="button" class="${m==v?'':'g'}" style="flex:1;padding:8px 4px" onclick="jmSet(${j},${v})">${t}</button>`;
 let nx='';if(m==2){const P=rvPlan(30),r=P.find((x,i)=>x.juz.includes(j)&&(i>0||!P[0].done.includes(j)));nx=r?' • موعده في الخطة: '+(r===P[0]?'اليوم':ymd(r.d)):''}
 $('#sh').innerHTML=shW(`<b>الجزء ${j}</b><div class="m" style="margin:6px 0">${exPages(j)} صفحة • ${JMC[k][1]}${J.n?' • '+J.n+' مراجعة':''}${d!==null?' • آخر مراجعة '+(d==0?'اليوم':'قبل '+d+' يوم'):''}${nx}</div><div class="row" style="gap:6px;flex-wrap:nowrap">${b(0,'لم يُحفظ')}${b(1,'قيد الحفظ')}${b(2,'محفوظ')}</div>${m==2?`<button type="button" onclick="jmRev(${j})" style="width:100%;margin-top:10px">✅ سجّلت مراجعته اليوم</button>`:''}<button type="button" class="g" onclick="$('#sh').innerHTML=''" style="width:100%;margin-top:6px">إغلاق</button>`)}
function jmSet(j,v){S.jm=S.jm||{};S.jm[j]=v;if(v==2&&!(S.jma||{})[j]){S.jma=S.jma||{};S.jma[j]=new Date().toISOString()}save();draw();jmOpen(j)}
function jmRev(j){jAdd(j,1);$('#sh').innerHTML='';toast('سُجّلت مراجعة الجزء '+j);draw()}

/* ---------- أيام النشاط (تُستعمل في تقرير المعلم) ---------- */
const wkAct=()=>{const a=new Set();(S.logs||[]).forEach(l=>l.date&&a.add(l.date));((S.wrd||{}).log||[]).forEach(x=>a.add(x.d));Object.values(S.juz||{}).forEach(j=>(j.h||[]).forEach(h=>a.add(new Date(h).toLocaleDateString('en-CA'))));return a};
function wkRun(){const A=wkAct();if(!A.size)return{cur:0,best:0};const t=new Date();t.setHours(0,0,0,0);const end=A.has(ymd(t))?t:new Date(t-864e5),d=new Date([...A].sort()[0]+'T00:00:00');let run=0,best=0;
 for(let i=0;d<=end&&i<9000;i++){if(A.has(ymd(d))){run++;best=Math.max(best,run)}else if(!(S.skipFri&&d.getDay()==5))run=0;d.setDate(d.getDate()+1)}return{cur:run,best}}

/* ---------- التقرير الأسبوعي للمعلم (آخر 7 أيام) ---------- */
function repWk(T,H,K){const t=new Date();t.setHours(0,0,0,0);const days=[...Array(7)].map((_,i)=>{const d=new Date(t);d.setDate(t.getDate()-6+i);return d}),ks=new Set(days.map(ymd)),A=wkAct(),act=days.filter(d=>A.has(ymd(d))).length,
 arc=(S.arc||[]).filter(a=>a.en&&ks.has(ymd(new Date(a.en)))).sort((a,b)=>String(a.en).localeCompare(String(b.en))),
 W=S.wrd,lines=W?(W.log||[]).filter(x=>ks.has(x.d)).reduce((a,x)=>a+x.l,0):0,run=wkRun(),
 mist={};(S.mist||[]).filter(m=>ks.has(m.d)).forEach(m=>mist[m.type]=(mist[m.type]||0)+1);
 const st=[...Array(30)].map((_,i)=>jmSt(i+1)),need=st.map((x,i)=>(x=='r'||x=='y')?i+1:0).filter(Boolean);
 let o=H('الفترة: '+ymd(days[0])+' إلى '+ymd(days[6]))+K([['أيام النشاط',act+' / 7'],['مهام منجزة',arc.length],['حفظ جديد',lines?wrdTxt(lines):'—'],['أيام متتالية',run.cur]]);
 if(W){const c=wrdCalc();if(c)o+=H('خطة الحفظ')+K([['النسبة المنجزة',c.pct+'%'],['المحفوظ',wrdPg(c.done)+' صفحة'],['المتبقي',wrdPg(c.rem)+' صفحة'],['موعد الإنهاء',W.due]])}
 o+=H('ما أُنجز هذا الأسبوع')+(arc.length?T(['التاريخ','المهمة','النوع','التقييم'],arc.map(a=>[ymd(new Date(a.en)),esc(a.name)+(a.sub?' • '+esc(a.sub):''),arTy(a)||'—',(BADGE[a.r]||['','—'])[1]])):'<div style="font-size:12px;color:#555">لا مهام مسجّلة هذا الأسبوع.</div>');
 o+=H('حالة الأجزاء')+K([['محفوظ',st.filter(x=>'gyr'.includes(x)).length+' / 30'],['قيد الحفظ',st.filter(x=>x=='1').length],['يحتاج مراجعة',need.length]])+(need.length?'<div style="font-size:12px;color:#555">أجزاء تحتاج مراجعة: '+need.join('، ')+'</div>':'');
 const mk=Object.keys(mist);if(mk.length)o+=H('الأخطاء المسجّلة')+T(['النوع','العدد'],mk.map(k=>[esc(k),mist[k]]));
 return o}

/* ---------- الصفحات الصعبة: تتكرر مراجعتها كل يومين ---------- */
const hpG=()=>S.hp=S.hp||{};
const jzOf=p=>EXJ.filter(x=>x<=p).length;
const hpDays=h=>h.l?Math.round((rvDay(new Date())-rvDay(new Date(h.l)))/864e5):null;
const hpDue=()=>Object.keys(hpG()).map(Number).filter(p=>{const d=hpDays(hpG()[p]);return d===null||d>=2});
const hpCard=()=>{const n=hpDue().length;return n?`<div class="c" onclick="go('hp')" style="cursor:pointer;border-color:var(--bad)"><div class="row sp"><b>📌 الصفحات الصعبة</b><span class="ch">${svg('chev')}</span></div><div class="m">${n} ${n==1?'صفحة':'صفحات'} تحتاج مراجعة اليوم</div></div>`:''};
function hpAdd(){const v=String($('#hpi').value||'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)),ps=[...new Set((v.match(/\d+/g)||[]).map(Number).filter(p=>p>=1&&p<=604))];
 if(!ps.length){toast('اكتب رقم صفحة من 1 إلى 604');return}const H=hpG();let n=0;ps.forEach(p=>{if(!H[p]){H[p]={a:new Date().toISOString(),l:null,n:0};n++}});save();toast(n?'أُضيفت '+n+(n==1?' صفحة':' صفحات'):'الصفحات موجودة في القائمة');draw()}
function hpRev(p){const h=hpG()[p];if(!h)return;h.l=new Date().toISOString();h.n=(h.n||0)+1;save();toast('سُجّلت مراجعة صفحة '+p);draw()}
function hpDel(p){delete hpG()[p];save();draw()}
function hpTask(p){if((S.tasks||[]).some(t=>!t.arch&&(t.pg||[]).includes(p)&&t.type=='مراجعة')){toast('المراجعة موجودة في مهامك');return}
 S.tasks.push({id:S.id++,s:'صفحة '+p,j:0,pg:[p],tm:null,a:1,b:1,type:'مراجعة',stage:0,next:new Date().toISOString()});save();toast('أُضيفت إلى مهام اليوم');draw()}
function hpPage(){const H=hpG(),ks=Object.keys(H).map(Number);
 const key=p=>{const d=hpDays(H[p]);return[d===null||d>=2?0:1,H[p].l?new Date(H[p].l).getTime():0,p]};
 ks.sort((a,b)=>{const x=key(a),y=key(b);return x[0]-y[0]||x[1]-y[1]||x[2]-y[2]});
 const row=p=>{const h=H[p],d=hpDays(h),due=d===null||d>=2;
  return `<div class="c" style="${due?'border-color:var(--bad)':''}"><div class="row sp" style="flex-wrap:nowrap"><div><b>صفحة ${p}</b><div class="m">${exSur(p)} • الجزء ${jzOf(p)}</div></div>${due?'<span class="m" style="color:var(--bad);font-weight:700">مستحقة اليوم</span>':'<span class="m">مراجَعة</span>'}</div><div class="m" style="margin-top:4px">${d===null?'لم تُراجع بعد':'آخر مراجعة '+(d==0?'اليوم':'قبل '+d+' يوم')} • ${h.n||0} مراجعة</div>
  <div class="row" style="margin-top:8px;gap:6px"><button type="button" style="flex:1" onclick="hpRev(${p})">✅ راجعتها</button><button type="button" class="g" onclick="hpTask(${p})">➕ مهمة</button><button type="button" class="g" onclick="ask('إزالة صفحة ${p} من الصفحات الصعبة؟',()=>hpDel(${p}),'نعم، أزل')">لم تعد صعبة</button></div></div>`};
 const n=hpDue().length;
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">الصفحات الصعبة</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>
 <div class="c"><b>أضف صفحات تجد صعوبة فيها</b><div class="row" style="flex-wrap:nowrap;gap:6px;margin-top:8px"><input id="hpi" inputmode="numeric" placeholder="رقم الصفحة، أو عدة أرقام: 52، 120، 301" autocomplete="off" style="flex:1;margin:0;min-width:0"><button type="button" onclick="hpAdd()">إضافة</button></div>
 <div class="m" style="margin-top:6px">تظهر الصفحة هنا وتتكرر مراجعتها كل يومين، أكثر من الجدول العادي. اضغط «لم تعد صعبة» عندما تتقنها.</div></div>
 ${ks.length?`<div class="m" style="margin:0 16px">${ks.length} ${ks.length==1?'صفحة':'صفحات'} • ${n?n+' مستحقة اليوم':'لا شيء مستحق اليوم، بارك الله فيك 🌿'}</div>${ks.map(row).join('')}`:'<div class="c m">لا صفحات صعبة بعد. أضف أول صفحة من الخانة أعلاه.</div>'}`}

/* ---------- خطة ختمة رمضان: ختم القرآن في عدد أيام تحدده ---------- */
const khG=()=>S.kh&&S.kh.start?S.kh:null;let khEdit=0;
function khSeg(K,i){const T=604*K.k;let a=Math.round((i-1)*T/K.days)+1,b=Math.max(a,Math.round(i*T/K.days));const seg=[];
 while(a<=b){const c=Math.floor((a-1)/604),e=Math.min(b,(c+1)*604);seg.push([a-c*604,e-c*604,c+1]);a=e+1}return seg}
const khTxt=(K,seg)=>seg.map(([x,y,c])=>(x==y?'صفحة '+x:'صفحات '+x+' - '+y)+(K.k>1?' (ختمة '+c+')':'')).join(' ثم ');
const khIdx=K=>{const t=new Date();t.setHours(0,0,0,0);return Math.floor((t-wrdDate(K.start))/864e5)+1};
const khDone=K=>Object.keys(K.chk||{}).filter(i=>K.chk[i]).length;
const khCard=()=>{const K=khG();if(!K)return '';const i=khIdx(K);if(i<1||i>K.days||(K.chk||{})[i])return '';return `<div class="c" onclick="go('kh')" style="cursor:pointer;border-color:var(--pri)"><div class="row sp"><b>🌙 ختمتك اليوم</b><span class="ch">${svg('chev')}</span></div><div class="m">${khTxt(K,khSeg(K,i))}</div></div>`};
function khQ(n){const e=$('#khd');if(e){e.value=n;khPrev()}}
function khPrev(){const d=Math.max(0,Math.floor(+$('#khd').value||0)),k=Math.max(0,Math.floor(+$('#khk').value||0)),o=$('#khp');if(!o)return;
 if(!d||!k){o.textContent='';return}const ppd=604*k/d;o.textContent='≈ '+(Math.round(ppd*10)/10)+' صفحة يومياً، أي '+wrdTxt(Math.round(ppd*WRL/5))+' بعد كل صلاة من الصلوات الخمس'}
function khSave(){const days=Math.floor(+$('#khd').value||0),k=Math.floor(+$('#khk').value||0),st=$('#khs').value;
 if(days<1||days>120){toast('عدد الأيام من 1 إلى 120');return}if(k<1||k>10){toast('عدد الختمات من 1 إلى 10');return}if(!st){toast('اختر تاريخ البدء');return}
 const o=S.kh||{},same=o.days==days&&o.k==k;S.kh={days,k,start:st,chk:same?(o.chk||{}):{}};khEdit=0;save();toast('تم حفظ الخطة');draw()}
function khTog(i){const K=khG();if(!K)return;K.chk=K.chk||{};K.chk[i]=!K.chk[i];save();draw()}
function khReset(){ask('حذف خطة الختمة وتقدمها؟',()=>{S.kh=null;khEdit=0;save();draw()},'نعم، احذف')}
function khForm(){const K=S.kh;
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">ختمة رمضان</b><button type="button" class="g" onclick="${K?'khEdit=0;draw()':"go('home')"}">رجوع</button></div>
 <div class="c"><div class="m">في كم يوماً تريد ختم القرآن؟</div><input id="khd" type="number" inputmode="numeric" min="1" max="120" value="${K?K.days:30}" oninput="khPrev()">
 <div style="margin:6px 0">${[30,20,15,10,7].map(n=>`<span class="chip" onclick="khQ(${n})">${n} ${n==30?'يوماً':'أيام'}</span>`).join('')}</div>
 <div class="m">عدد الختمات</div><input id="khk" type="number" inputmode="numeric" min="1" max="10" value="${K?K.k:1}" oninput="khPrev()">
 <div class="m">تاريخ أول يوم</div><input id="khs" type="date" value="${K?K.start:ymd(new Date())}">
 <div class="m" style="margin-top:4px">غيّر التاريخ إلى أول يوم من رمضان، أو اتركه اليوم لتبدأ الآن.</div>
 <div class="m" id="khp" style="margin-top:8px;font-weight:700"></div>
 <button type="button" onclick="khSave()" style="width:100%;margin-top:10px">${K?'حفظ التعديل':'ابدأ الخطة'}</button>${K?'<div class="m" style="margin-top:6px">تعديل عدد الأيام أو الختمات يمسح علامات الأيام السابقة.</div>':''}</div>`}
function khPage(){const K=khG();if(!K||khEdit){setTimeout(khPrev,0);return khForm()}
 const i=khIdx(K),dn=khDone(K),pct=Math.round(dn/K.days*100),ppd=604*K.k/K.days;
 const today=()=>{if(i<1){const n=1-i;return `<div class="m">الخطة تبدأ بعد ${n} ${n==1?'يوم':'أيام'} (${K.start})</div><b style="font-size:20px;display:block;margin:6px 0">${khTxt(K,khSeg(K,1))}</b><div class="m">ورد أول يوم</div>`}
  if(i>K.days)return `<b style="font-size:18px">انتهت أيام الخطة</b><div class="m" style="margin-top:6px">أتممت ${dn} من ${K.days} يوماً${dn>=K.days?' • ما شاء الله، ختمت 🎉':''}</div>`;
  const sg=khSeg(K,i),on=!!(K.chk||{})[i];
  return `<div class="m">اليوم ${i} من ${K.days}</div><b style="font-size:22px;display:block;margin:6px 0">${khTxt(K,sg)}</b><div class="m">يبدأ من ${exSur(sg[0][0])} • ${wrdTxt(Math.round(ppd*WRL/5))} بعد كل صلاة</div>
  <button type="button" onclick="khTog(${i})" style="width:100%;margin-top:10px;${on?'opacity:.6':''}">${on?'✅ أنهيت ورد اليوم (اضغط للتراجع)':'أنهيت ورد اليوم'}</button>`};
 const rows=[...Array(K.days)].map((_,x)=>{const n=x+1,d=wrdDate(K.start);d.setDate(d.getDate()+x);const on=!!(K.chk||{})[n],now=n==i,late=n<i&&!on;
  return `<div class="row" onclick="khTog(${n})" style="flex-wrap:nowrap;gap:8px;padding:8px 6px;border-top:1px solid var(--bd);cursor:pointer;${now?'background:color-mix(in srgb,var(--pri) 10%,transparent);border-radius:8px':''}"><span style="width:26px;height:26px;border-radius:50%;flex:none;text-align:center;line-height:26px;font-size:13px;border:1px solid ${on?'var(--pri)':late?'var(--bad)':'var(--bd)'};background:${on?'var(--pri)':'transparent'};color:${on?'#fff':'inherit'}">${on?'✓':n}</span><div style="flex:1;min-width:0"><b style="font-size:14px">${khTxt(K,khSeg(K,n))}</b><div class="m" style="font-size:11px">${D[d.getDay()]} ${ymd(d).slice(5)}${now?' • اليوم':late?' • متأخر':''}</div></div></div>`}).join('');
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">ختمة رمضان</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>
 <div class="c" style="text-align:center">${today()}<div style="background:var(--bd);border-radius:10px;height:10px;margin-top:12px;overflow:hidden"><div style="width:${pct}%;height:100%;background:var(--pri)"></div></div><div class="m" style="margin-top:6px">أتممت ${dn} من ${K.days} يوماً (${pct}%) • الخطة: ${K.k==1?'ختمة':K.k+' ختمات'} في ${K.days} يوماً، نحو ${Math.round(ppd*10)/10} صفحة يومياً</div></div>
 <div class="c"><b>جدول الأيام</b><div class="m" style="margin-bottom:4px">اضغط على أي يوم لوضع علامة الإنجاز أو إزالتها.</div>${rows}</div>
 <div class="row" style="padding:0 14px;gap:6px"><button type="button" class="g" style="flex:1" onclick="khEdit=1;draw()">تعديل الخطة</button><button type="button" class="g" style="flex:1" onclick="khReset()">حذف الخطة</button></div>`}


Object.assign(EN,{'➕ إضافة إلى المهام':'➕ Add to tasks','المراجعة موجودة في مهامك':'The review is already in your tasks'});

/* ---------- التذكيرات: تظهر عادياً، ويمكن إخفاؤها واستعادتها بالسحب ---------- */
let remOpen=0,remY=null;
function remBox(){const cs=[glRemHtml(),prRemHtml(),wrdCard(),khCard(),hpCard(),rvCard()].filter(Boolean);if(!cs.length)return '';
 if(S.remH&&!remOpen)return `<div id="remBar" onpointerdown="remDn(event)" onpointermove="remMv(event)" onpointerup="remY=null" onpointercancel="remY=null" onclick="remShow()" style="touch-action:none;cursor:pointer;display:flex;align-items:center;gap:10px;margin:0 0 10px;padding:12px 14px;border-radius:16px;background:var(--bd);user-select:none"><span style="width:30px;height:30px;border-radius:50%;background:var(--pri);color:#fff;display:flex;align-items:center;justify-content:center;flex:none">⬇</span><span style="flex:1;text-align:center;font-weight:700">اسحب لعرض التذكيرات (${cs.length})</span></div>`;
 return cs.join('')+`<button type="button" class="g" onclick="remHide()" style="width:100%;margin:0 0 10px;padding:8px">🗄 إخفاء التذكيرات حتى أسحبها</button>`}
function remDn(e){remY=e.clientY}
function remMv(e){if(remY!==null&&e.clientY-remY>30){remY=null;remShow()}}
function remShow(){remOpen=1;draw()}
function remHide(){S.remH=1;remOpen=0;save();draw()}
const tkCd={};
function tkPick(id,v){const t=tkG(id);if(!t)return;if(tkCd[id]){clearInterval(tkCd[id].iv);delete tkCd[id]}
 if(t.mk==v){t.mk=0;save();draw();return}
 t.mk=v;save();tkCd[id]={n:5,iv:setInterval(()=>{const c=tkCd[id];if(!c)return;c.n--;if(c.n<=0){clearInterval(c.iv);delete tkCd[id];if(tkG(id))archT(id,true)}else{const e=document.getElementById('tkc'+id);if(e)e.textContent=c.n}},1000)};draw()}
function tkMk(id,v){const t=tkG(id);chg(t.mk,()=>{t.mk=t.mk==v?0:v;save();draw()})}
function tkEdit(id){const t=tkG(id);$('#sh').innerHTML=shW(`<b>تعديل اسم المهمة</b><input id="tkn" value="${esc(t.s)}" autocomplete="off"><button type="button" onclick="tkSave(${id})">حفظ</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
function tkSave(id){const v=$('#tkn').value.trim();if(v){const t=tkG(id);t.s=v;t.nm=1;save()}$('#sh').innerHTML='';draw()}
function sdT(){const l=$('#sl');l.style.display=l.style.display=='none'?'block':'none'}
function sdP(v){jSel.clear();$('#ts').value=v;$('#sl').style.display='none'}
const sdI=(v,t)=>`<div onclick="sdP('${v}')" style="padding:10px 12px;border-bottom:1px solid var(--bd)">${t}</div>`;
let jSel=new Set();
function sdList(m){return m=='s'?SUR.map((n,i)=>sdI(n,(i+1)+'. '+n)).join(''):'<div class="m" style="padding:6px 12px">اضغط لاختيار أكثر من جزء ✓</div>'+[...Array(30)].map((_,i)=>`<div onclick="sdJ(${i+1})" style="padding:10px 12px;border-bottom:1px solid var(--bd);display:flex;justify-content:space-between"><span>الجزء ${i+1}</span><b style="color:var(--pri)">${jSel.has(i+1)?'✓':''}</b></div>`).join('')}
function sdJ(n){jSel.has(n)?jSel.delete(n):jSel.add(n);$('#ts').value=[...jSel].sort((a,b)=>a-b).map(x=>'الجزء '+x).join('، ');$('#sli').innerHTML=sdList('j')}
function sdM(m){$('#sli').innerHTML=sdList(m);$('#m_s').classList.toggle('on',m=='s');$('#m_j').classList.toggle('on',m=='j')}
function addTask(){if(pkTgt){selClear();pkTgt=''}const typed=$('#ts').value.trim(),nm=($('#tn')||{value:''}).value.trim(),any=pkAny(),ra=$('#ta').value.trim(),rb=$('#tb').value.trim(),rng=!typed&&!any&&(ra||rb);if(!typed&&!any&&!rng)return;
 const rl=ra&&rb?'من آية '+(+ra)+' إلى آية '+(+rb):ra?'من آية '+(+ra):'إلى آية '+(+rb);
 const js=[...pkJ].sort((a,b)=>a-b),ts=parseT($('#tc').value)||0;
 const t={id:S.id++,s:any?(nm||pkSum()):rng?(nm?nm+' — '+rl:rl):(nm?nm+' — '+typed:typed),j:0,tm:mkT(ts),a:+$('#ta').value||1,b:+$('#tb').value||1,type:$('#tt').value,stage:0,next:new Date().toISOString()};
 if(any){t.g=1;if(pkS.size)t.sur=[...pkS];if(js.length==1&&!pkS.size&&!pkP.size)t.j=js[0];else if(js.length)t.js=js;if(pkP.size)t.pg=[...pkP].sort((a,b)=>a-b)}
 if(rng)t.g=1;if(nm)t.nm=1;S.tasks.push(t);selClear();save();draw()}
const isG=t=>t.j||t.js||t.g||t.sur||t.pg;
const rngPg=a=>{a=[...a].sort((x,y)=>x-y);const o=[];for(let i=0;i<a.length;){let j=i;while(j+1<a.length&&a[j+1]==a[j]+1)j++;o.push(j>i?a[i]+'–'+a[j]:''+a[i]);i=j+1}return o.join(' و ')};
const pgFmt=a=>{a=[...a];return a.length==1?'صفحة '+a[0]:'صفحات: '+rngPg(a)};
const jl=t=>[t.sur&&t.sur.length?'سور: '+t.sur.join('، '):'',t.js?'الأجزاء '+t.js.join('، '):(t.j&&t.s!=='الجزء '+t.j?'الجزء '+t.j:''),t.pg&&t.pg.length?pgFmt(t.pg):''].filter(Boolean).join(' • ');
const pkS=new Set(),pkJ=new Set(),pkP=new Set();let pkT='s',pkQ='';
const pkSum=()=>[pkS.size?'سور: '+[...pkS].join('، '):'',pkJ.size?(pkJ.size==1&&!pkS.size&&!pkP.size?'الجزء '+[...pkJ][0]:'الأجزاء '+[...pkJ].sort((a,b)=>a-b).join('، ')):'',pkP.size?pgFmt(pkP):''].filter(Boolean).join(' • ');
const pkAny=()=>pkS.size+pkJ.size+pkP.size>0;
function selClear(){pkS.clear();pkJ.clear();pkP.clear()}
function pkItems(){const q=nrm(pkQ),num=/^\d+$/.test(q)?+q:0;
 const row=(k,v,t)=>`<div onclick="pkTg('${k}','${v}')" style="padding:10px 6px;border-bottom:1px solid var(--bd);display:flex;justify-content:space-between"><span>${t}</span><b style="color:var(--pri)">${(k=='s'?pkS:k=='j'?pkJ:pkP).has(k=='s'?v:+v)?'✓':''}</b></div>`;
 if(q){let o=SUR.map((n,i)=>[n,i+1]).filter(([n,i])=>nrm(n).includes(q)||(num&&i==num)).map(([n,i])=>row('s',n,i+'. سورة '+n)).join('');if(num>=1&&num<=30)o+=row('j',num,'الجزء '+num);if(num>=1&&num<=604)o+=row('p',num,'صفحة '+num);return o||'<div class="m" style="padding:10px">لا نتائج</div>'}
 if(pkT=='s')return SUR.map((n,i)=>row('s',n,(i+1)+'. '+n)).join('');
 if(pkT=='j')return [...Array(30)].map((_,i)=>row('j',i+1,'الجزء '+(i+1))).join('');
 return '<div style="display:flex;flex-wrap:wrap;gap:4px">'+[...Array(604)].map((_,i)=>`<span class="chip ${pkP.has(i+1)?'on':''}" style="min-width:46px;text-align:center" onclick="pkTg('p',${i+1})">${i+1}</span>`).join('')+'</div>'}
let pkTgt='';
function pkOpen(){if(pkTgt){selClear();pkTgt=''}pkQ='';pkRender()}
function pkUnits(){return[...[...pkJ].sort((a,b)=>a-b).map(n=>'ج'+n),...pkS,...[...pkP].sort((a,b)=>a-b).map(n=>'ص'+n)]}
function ctPick(id){pkTgt=id=='new'?'cn':'c'+id;const u=id=='new'?ctDraft.juz:ctG(id).juz;selClear();u.forEach(x=>x[0]=='ج'?pkJ.add(+x.slice(1)):x[0]=='ص'?pkP.add(+x.slice(1)):pkS.add(x));pkQ='';pkRender()}
function pkRender(){$('#sh').innerHTML=shW(`<b>اختيار المهمة</b><input id="pkq" placeholder="ابحث عن سورة أو جزء أو صفحة (مثال: 18 أو الكهف)" value="${esc(pkQ)}" oninput="pkQ=this.value;pkList()" autocomplete="off" style="margin-top:8px"><div>${[['s','السور'],['j','الأجزاء'],['p','الصفحات']].map(([k,t])=>`<span class="chip ${pkT==k?'on':''}" onclick="pkT='${k}';pkQ='';pkRender()">${t} ${(k=='s'?pkS:k=='j'?pkJ:pkP).size||''}</span>`).join('')}</div>
 ${pkT=='p'?`<div class="row" style="flex-wrap:nowrap;gap:6px;margin-top:6px"><input id="pka" type="number" inputmode="numeric" placeholder="من صفحة" style="flex:1;margin:0;min-width:0"><input id="pkb" type="number" inputmode="numeric" placeholder="إلى صفحة" style="flex:1;margin:0;min-width:0"></div><button type="button" class="g" onclick="pkRange()">إضافة النطاق</button>`:''}
 <div id="pkl" style="max-height:42vh;overflow-y:auto;margin-top:6px">${pkItems()}</div><button type="button" id="pkc" onclick="pkDone()" style="width:100%;margin-top:8px">تم (${pkS.size+pkJ.size+pkP.size})</button><button type="button" class="g" onclick="selClear();pkRender()" style="width:100%">مسح الاختيار</button>`)}
function pkList(){const l=$('#pkl');if(l)l.innerHTML=pkItems();const c=$('#pkc');if(c)c.textContent='تم ('+(pkS.size+pkJ.size+pkP.size)+')'}
function pkTg(k,v){const st=k=='s'?pkS:k=='j'?pkJ:pkP,key=k=='s'?v:+v;st.has(key)?st.delete(key):st.add(key);pkList()}
function pkRange(){const a=Math.max(1,+$('#pka').value||0),b=Math.min(604,+$('#pkb').value||a);if(!a)return;for(let i=Math.min(a,b);i<=Math.max(a,b);i++)pkP.add(i);pkList()}
function tkUnits(id){const t=tkG(id);if(!t)return;pkTgt='k'+id;selClear();(t.sur||[]).forEach(x=>pkS.add(x));(t.js||(t.j?[t.j]:[])).forEach(n=>pkJ.add(+n));(t.pg||[]).forEach(n=>pkP.add(+n));pkQ='';pkRender()}
function pkDone(){$('#sh').innerHTML='';
if(pkTgt&&pkTgt[0]=='k'){const t=tkG(+pkTgt.slice(1));pkTgt='';if(t&&pkAny()){const auto=isG(t)&&!t.nm,js=[...pkJ].sort((a,b)=>a-b);delete t.sur;delete t.js;delete t.pg;t.j=0;t.g=1;if(pkS.size)t.sur=[...pkS];if(js.length==1&&!pkS.size&&!pkP.size)t.j=js[0];else if(js.length)t.js=js;if(pkP.size)t.pg=[...pkP].sort((a,b)=>a-b);if(auto)t.s=pkSum();save()}selClear();draw();return}
if(pkTgt=='cn'){ctDraft.juz=pkUnits();selClear();pkTgt='';draw();return}if(pkTgt&&pkTgt[0]=='c'){const c=ctG(+pkTgt.slice(1)),u=pkUnits(),old=new Set(c.juz);c.heard=c.heard.filter(x=>u.includes(x)).concat(u.filter(x=>!old.has(x)));c.juz=u;selClear();pkTgt='';save();draw();return}const e=$('#ts');if(e)e.value=pkSum()}

function startT(id){const t=tkG(id),m=t.tm;if(!t.st)t.st=new Date().toISOString();if(m&&!m.run&&!mStart(m,parseT(($('#tmi'+id)||{}).value)))toast('اكتب مدة التايمر لتشغيل العدّاد');save();draw()}
function tkRs(id){const t=tkG(id);if(!t)return;delete t.st;save();draw()}
function delT(id){S.tasks=S.tasks.filter(x=>x.id!=id);save();draw()}
function rate(id){$('#sh').innerHTML=`<div class="sh"><div><b>كيف كان أداؤك؟</b>
 <button type="button" onclick="done(${id},'mastered')">🟢 أتقنت تماماً</button><button type="button" onclick="done(${id},'light')">🟡 بحاجة لمراجعة خفيفة</button><button type="button" class="r" onclick="done(${id},'hard')">🔴 واجهت صعوبة</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button></div></div>`}
function done(id,r){
 const t=S.tasks.find(x=>x.id==id);if(!t)return;const n=new Date(),st=t.st?new Date(t.st):n;
 S.logs.push({t:id,s:t.s,a:t.a,b:t.b,n:isG(t)?1:0,date:ymd(n),h:hij(n),day:D[n.getDay()],time:hm(n),start:hm(st),dur:Math.max(1,Math.round((n-st)/60000)),r});
 const nx=r=='mastered'?(t.type=='حفظ'?0:Math.min(t.stage+1,3)):r=='light'?t.stage:0;
 let nd=new Date(n.getTime()+(r=='hard'?1:L[nx])*864e5);if(S.skipFri&&nd.getDay()==5)nd=new Date(nd.getTime()+864e5);
 const tm=t.tm,us=tm?mUsed(tm):Math.max(1,Math.round((n-st)/1000));
 const snap=JSON.parse(JSON.stringify(t));snap.st=null;snap.mk=0;snap.next=new Date().toISOString();if(tm)snap.tm=mkT(mOrig(tm));
 (S.arc=S.arc||[]).push({id:S.id++,tid:id,ty:t.type,name:t.s,sub:isG(t)?jl(t):'',r,st:st.toISOString(),en:n.toISOString(),us,ov:tm?Math.max(mOver(tm),Math.max(0,us-mOrig(tm))):0,og:tm?mOrig(tm):0,mk:t.mk||0,tk:snap,lg:{t:id,date:ymd(n),time:hm(n)}});
 if(tm)mReset(tm);t.mk=0;
 (t.js||(t.j?[t.j]:[])).forEach(u=>jAdd(u,1));
 const fin=r=='mastered'&&t.type=='مراجعة'&&t.stage==3;
 S.tasks=S.tasks.filter(x=>x.id!=id);save();$('#sh').innerHTML='';draw()}
/* ---------- محرك المؤقتات (المهام والمسابقات) ---------- */
const mkT=v=>({dur:v,d0:v,left:v,run:false,end:0,used:0,t0:0,ov:0,ex:0,add:0});
const mLeft=m=>m.run?Math.round((m.end-Date.now())/1000):m.left;
const mUsed=m=>Math.round((m.used||0)+(m.run?(Date.now()-m.t0)/1000:0));
const mOver=m=>Math.round((m.ov||0)+(m.ex?(Date.now()-m.ex)/1000:0));
const mOrig=m=>m.os?m.d0:(m.used?(m.d0||Math.max(0,m.dur-(m.add||0))):Math.max(m.dur,m.left));
function mShow(m){const l=mLeft(m);if(m.run&&l<0)return{t:'+'+fmt(-l),red:!!m.ex&&Date.now()-m.ex>=60000};return{t:fmt(Math.max(0,l)),red:false}}
function mStart(m,v){if(v>0&&v!==m.dur){m.dur=v;m.left=v}if(m.left<=0)m.left=m.dur;if(m.left<=0)return false;if(!m.os&&!m.used){m.d0=m.left;m.os=1}m.end=Date.now()+m.left*1000;m.t0=Date.now();m.run=true;m.ex=0;return true}
function mPause(m){m.used=(m.used||0)+(Date.now()-m.t0)/1000;if(m.ex){m.ov=(m.ov||0)+(Date.now()-m.ex)/1000;m.ex=0}m.left=Math.max(0,Math.round((m.end-Date.now())/1000));m.run=false}
function mReset(m){m.run=false;m.left=m.dur;m.used=0;m.ov=0;m.ex=0;m.add=0;m.os=0}
function mSet(m,v){m.dur=v;if(!m.os)m.d0=v;if(m.run){m.left=v;m.end=Date.now()+v*1000;if(m.ex){m.ov=(m.ov||0)+(Date.now()-m.ex)/1000;m.ex=0}}else m.left=v}
function mAdj(m,d){if(m.run){m.end=Math.max(Date.now(),m.end+d*1000);if(m.ex&&m.end>Date.now()){m.ov=(m.ov||0)+(Date.now()-m.ex)/1000;m.ex=0}}else{m.left=Math.max(0,m.left+d);if(m.left>m.dur)m.dur=m.left}}
function mMore(m,sec){if(m.ex){m.ov=(m.ov||0)+(Date.now()-m.ex)/1000;m.ex=0}m.end=Date.now()+sec*1000;m.add=(m.add||0)+sec;m.run=true}
const hms=x=>{x=Math.round(x);const h=Math.floor(x/3600),m=Math.floor(x%3600/60);return(h?h+':':'')+String(m).padStart(h?2:1,'0')+':'+String(x%60).padStart(2,'0')};
const tkG=id=>S.tasks.find(x=>x.id==id),tkOpen={};
const tmL=t=>mLeft(t.tm);
function tmHtml(t){const m=t.tm,s=mShow(m);
 return `<div style="margin-top:8px;padding:8px;border:1px solid var(--bd);border-radius:12px"><div class="row sp" style="flex-wrap:nowrap"><button type="button" class="g" style="padding:6px 10px" onclick="tmAdj(${t.id},-60)">−1</button><b id="tm${t.id}" style="font-size:28px;font-variant-numeric:tabular-nums;color:${s.red?'var(--bad)':'inherit'}">${s.t}</b><button type="button" class="g" style="padding:6px 10px" onclick="tmAdj(${t.id},60)">+1</button><button type="button" onclick="tmToggle(${t.id})">${m.run?'⏸ إيقاف':'⏱ تشغيل'}</button><button type="button" class="g" onclick="tmReset(${t.id})">↺</button></div><div class="row" style="margin-top:6px;flex-wrap:nowrap;gap:6px"><input id="tmi${t.id}" type="text" autocomplete="off" placeholder="اكتب المدة: 25 أو 1:30" onkeydown="if(event.key==='Enter')tmSet(${t.id})" style="flex:1;margin:0;min-width:0"><button type="button" class="g" style="padding:8px 12px" onclick="tmSet(${t.id})">تعيين</button></div></div>`}
function tmSet(id){const t=tkG(id),v=parseT(($('#tmi'+id)||{}).value);if(!(v>0))return;mSet(t.tm,v);save();draw()}
function tmAdj(id,d){mAdj(tkG(id).tm,d);save();draw()}
function tmToggle(id){const t=tkG(id),m=t.tm;if(m.run)mPause(m);else{if(!mStart(m,parseT(($('#tmi'+id)||{}).value))){toast('اكتب مدة التايمر أولاً');return}if(!t.st)t.st=new Date().toISOString()}save();draw()}
function tmReset(id){mReset(tkG(id).tm);save();draw()}
function tmNew(id){$('#sh').innerHTML=shW(`<b>مدة تايمر المهمة</b><input id="tmv" type="text" autocomplete="off" placeholder="اكتب: 25 أو 1:30"><button type="button" onclick="tmAdd(${id})">إضافة</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
function tmAdd(id){const v=parseT($('#tmv').value);if(!(v>0))return;tkG(id).tm=mkT(v);save();$('#sh').innerHTML='';draw()}
const tmM=(k,id)=>((k=='t'?S.tasks:S.cont).find(x=>x.id==id)||{}).tm;
function tmTick(){[...(S.tasks||[]).filter(t=>t.tm).map(t=>['t',t.id,t.tm,t.s]),...(S.cont||[]).map(c=>['c',c.id,c.tm,c.name])].forEach(([k,id,m,nm])=>{if(!m.run)return;const l=mLeft(m);
 if(l<=0&&!m.ex){m.ex=m.end;save();ringStart();tmBanner(k,id,nm);notif('انتهى الوقت',{body:nm})}
 else if(m.ex&&l>0){m.ov=(m.ov||0)+(Date.now()-m.ex)/1000;m.ex=0}
 const e=document.getElementById((k=='t'?'tm':'ct')+id);if(e){const z=mShow(m);e.textContent=z.t;e.style.color=z.red?'var(--bad)':''}})}
setInterval(tmTick,1000);
function tmBanner(k,id,nm){$('#ban').innerHTML+=`<div class="c" id="tbn${k}${id}" style="border-color:var(--bad)"><b>انتهى الوقت</b><div class="m">${esc(nm)}</div><div class="row" style="margin-top:8px"><button type="button" class="g" style="flex:1" onclick="tmClose('${k}',${id})">إغلاق</button><button type="button" style="flex:1" onclick="tmMoreAsk('${k}',${id})">زيادة الزمن</button></div></div>`}
function tmGone(k,id){ringStop();const e=document.getElementById('tbn'+k+id);if(e)e.remove()}
function tmClose(k,id){tmGone(k,id);const m=tmM(k,id);if(!m)return;mPause(m);m.left=0;if(k=='c'){const c=S.cont.find(x=>x.id==id);c.fin=true;c.el=Math.round(m.used||0);c.e0=Date.now();ctArch(c)}save();draw()}
function tmMoreAsk(k,id){$('#sh').innerHTML=shW(`<b>زيادة الزمن</b><div class="m">كم دقيقة تريد أن تضيف؟</div><div style="margin:8px 0">${[5,10,15,30].map(x=>`<span class="chip" onclick="tmMoreDo('${k}',${id},${x})">${x} دقيقة</span>`).join('')}</div><input id="tmxm" type="text" inputmode="decimal" autocomplete="off" placeholder="أو اكتب المدة بالدقائق" onkeydown="if(event.key==='Enter')tmMoreDo('${k}',${id},parseT(this.value)/60)"><button type="button" onclick="tmMoreDo('${k}',${id},parseT($('#tmxm').value)/60)">إضافة</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
function tmMoreDo(k,id,min){if(!(min>0))return;const m=tmM(k,id);if(!m)return;mMore(m,min*60);tmGone(k,id);$('#sh').innerHTML='';save();draw()}
/* ---------- المؤقت المستقل ---------- */
const fmt=x=>String(Math.floor(x/60)).padStart(2,'0')+':'+String(x%60).padStart(2,'0');
const tG=()=>S.timer||(S.timer={dur:1800,left:1800,run:false,end:0});
const tL=()=>{const m=tG();return m.run?Math.max(0,Math.round((m.end-Date.now())/1000)):m.left};
function tDraw(){const b=$('#tbox');if(b)b.innerHTML=tbox()}
let tMsg='';
function parseT(v){v=String(v||'').trim().replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[٫،]/g,'.').replace(/：/g,':');if(!v)return 0;
 if(v.includes(':')){const[a,b]=v.split(':');return Math.round((+a||0)*60+(+b||0))}return Math.round((+v)*60)}
function tbox(){const m=tG(),l=tL(),run=m.run;
 return `<div class="row sp"><b>⏱ المؤقت</b><span class="m">${tMsg||(run?'يعمل...':l<=0?'انتهى':'متوقف')}</span></div>
 <div id="tmx" style="font-size:46px;text-align:center;font-weight:700;font-variant-numeric:tabular-nums;padding:6px 0">${fmt(l)}</div>
 <div style="text-align:center">${[5,10,15,30,60].map(x=>`<span class="chip" onclick="tPre(${x})">${x} دقيقة</span>`).join('')}</div>
 <div class="row" style="margin-top:8px;flex-wrap:nowrap;gap:6px"><button type="button" class="g" style="padding:10px 12px" onclick="tAdj(-60)">−1</button><input id="tmin" type="text" inputmode="text" autocomplete="off" placeholder="اكتب: 25 أو 1:30" onkeydown="if(event.key==='Enter')tSet()" style="flex:1;margin:0;min-width:0"><button type="button" style="padding:10px 12px" onclick="tSet()">تعيين</button><button type="button" class="g" style="padding:10px 12px" onclick="tAdj(60)">+1</button></div>
 <div class="row" style="margin-top:8px;flex-wrap:nowrap"><button type="button" onclick="tGo()" style="flex:1">${run?'⏸ إيقاف':'▶ تشغيل'}</button><button type="button" class="g" onclick="tReset()">↺ إعادة</button></div>
 `}
function tSet(){const m=tG(),sec=parseT(($('#tmin')||{}).value);
 if(!(sec>0)){tMsg='⚠️ اكتب مدة صحيحة مثل 25 أو 1:30';tDraw();return}
 tMsg='';m.dur=sec;if(m.run){m.left=sec;m.end=Date.now()+sec*1000}else m.left=sec;save();tDraw()}
function tAdj(d){const m=tG();tMsg='';if(m.run)m.end=Math.max(Date.now(),m.end+d*1000);else{m.left=Math.max(0,m.left+d);if(m.left>m.dur)m.dur=m.left}save();tDraw()}
function tPre(x){const m=tG();tMsg='';m.run=false;m.dur=Math.round(x*60);m.left=m.dur;save();tDraw()}
function tGo(){const m=tG();tMsg='';
 if(m.run){m.left=tL();m.run=false}
 else{const v=parseT(($('#tmin')||{}).value);if(v>0&&v!==m.dur){m.dur=v;m.left=v}
  if(m.left<=0)m.left=m.dur;m.end=Date.now()+m.left*1000;m.run=true}
 save();tDraw()}
function tReset(){const m=tG();tMsg='';m.run=false;m.left=m.dur;save();tDraw()}
setInterval(()=>{const m=S.timer;if(!m||!m.run)return;const l=tL(),e=document.getElementById('tmx');if(e)e.textContent=fmt(l);
 if(l<=0){m.run=false;m.left=0;save();beep();notif('انتهى المؤقت ⏱')
 $('#ban').innerHTML=`<div class="c" style="border-color:var(--pri)"><b>انتهى المؤقت ⏱</b><div class="row" style="margin-top:8px"><button type="button" onclick="ringStop();$('#ban').innerHTML=''">إغلاق</button></div></div>`;tDraw()}},1000);
/* ---------- الاختبار ---------- */
function pickQ(){
 const v=S.tasks.filter(t=>t.txt);let pool=v;
 if(S.mist.length&&Math.random()<.5){const m=S.mist[Math.floor(Math.random()*S.mist.length)];const f=v.find(t=>t.id==m.t);if(f)return f}
 return pool.length?pool[Math.floor(Math.random()*pool.length)]:null}
function quiz(){
 if(!qz)qz=pickQ();
 if(!qz)return '<div class="c m">أضف مهمة مع كتابة نص الآيات (الحقل الاختياري) ليظهر الاختبار هنا.</div>';
 const w=qz.txt.split(/\s+/),h=Math.ceil(w.length/2);
 return `<div class="c"><div class="m">سورة ${esc(qz.s)} • الآيات ${qz.a}–${qz.b} • النتيجة ${qok}/${qn}</div>
 <p class="big">${rev?esc(qz.txt):esc(w.slice(0,h).join(' '))+' ...'}</p>
 ${rev?`<div class="row"><button type="button" class="r" style="flex:1" onclick="ans(0)">أخطأت ❌</button><button type="button" style="flex:1" onclick="ans(1)">أصبت ✅</button></div>`:`<button type="button" onclick="rev=true;draw()" style="width:100%">إظهار الإجابة</button>`}</div>`}
function ans(ok){qn++;if(ok){qok++;nextQ();return}
 $('#sh').innerHTML=`<div class="sh"><div><b>نوع الخطأ</b>${['نسيان كلمة','خطأ في التشكيل','تقديم وتأخير','تشابه لفظي'].map(x=>`<button type="button" onclick="mist('${x}')">${x}</button>`).join('')}</div></div>`}
function mist(x){S.mist.push({t:qz.id,type:x,d:ymd(new Date())});save();$('#sh').innerHTML='';nextQ()}
function nextQ(){qz=null;rev=false;draw()}

/* ---------- المنبّهات ---------- */
function alarms(){
 const perm=('Notification'in window)?Notification.permission:'unsupported';
 return `<div class="c"><b>منبّه جديد</b><input id="at" type="time" value="05:00"><select id="ak"><option>حفظ</option><option>مراجعة</option></select>
 <div>${D.map((d,i)=>`<span class="chip ${addDays.includes(i)?'on':''}" onclick="addDays=addDays.includes(${i})?addDays.filter(x=>x!=${i}):[...addDays,${i}];draw()">${d}</span>`).join('')}</div>
 <button type="button" onclick="addAl()" style="margin-top:8px">إضافة المنبّه</button></div>
 ${perm!='granted'&&perm!='unsupported'?'<div class="c"><button type="button" onclick="Notification.requestPermission().then(draw)">🔔 السماح بالإشعارات</button></div>':''}
 <div class="c"><button type="button" onclick="ringStart();setTimeout(ringStop,3500)" style="width:100%">🔊 تجربة صوت المنبّه</button></div>
 <div class="c m">⚠️ المنبّهات تعمل ما دامت هذه الصفحة مفتوحة على الشاشة. للتنبيه وهي مغلقة استعمل منبّه الهاتف بجانبها.</div>`+
 S.alarms.map(a=>`<div class="c"><div class="row sp"><b style="font-size:22px">${a.time} • ${a.k}</b><button type="button" class="g" onclick="S.alarms=S.alarms.filter(x=>x.id!=${a.id});save();draw()">🗑</button></div>
 <div class="m">${a.days.map(i=>D[i]).join('، ')}</div><label><input type="checkbox" style="width:auto" ${a.on?'checked':''} onchange="S.alarms.find(x=>x.id==${a.id}).on=this.checked;save()"> مفعّل</label></div>`).join('')}
function addAl(){if(!addDays.length)return;S.alarms.push({id:S.id++,time:$('#at').value||'05:00',k:$('#ak').value,days:[...addDays].sort(),on:true});save();draw();
 if('Notification'in window&&Notification.permission=='default')Notification.requestPermission()}
let fired='';
/* إشعار يعمل على أندرويد: عبر الـ service worker لأن new Notification غير مدعوم هناك */
function notif(t,o){try{if(typeof Notification=='undefined'||Notification.permission!='granted')return;o=Object.assign({icon:'icon-192.png',badge:'icon-192.png',vibrate:[300,100,300,100,300],requireInteraction:true,tag:'qm-'+Date.now()},o||{});const fb=()=>{try{new Notification(t,o)}catch(e){dbg(e)}};if('serviceWorker' in navigator&&navigator.serviceWorker.getRegistration)navigator.serviceWorker.getRegistration().then(r=>r&&r.showNotification?r.showNotification(t,o):fb()).catch(fb);else fb()}catch(e){dbg(e)}}
/* صفير المنبّه: ثلاث نبرات حادة تتكرر حتى الإيقاف (بحد أقصى دقيقة) */
let ringT=null,ringC=null;
function pulses(){try{ringC=ringC||new(window.AudioContext||window.webkitAudioContext)();const c=ringC;if(c.state=='suspended')c.resume();
 for(let i=0;i<3;i++){const t=c.currentTime+i*.28,o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=1700;
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.8,t+.02);g.gain.setValueAtTime(.8,t+.16);g.gain.linearRampToValueAtTime(0,t+.2);
  o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+.22)}}catch(e){dbg(e)}
 try{navigator.vibrate&&navigator.vibrate([200,100,200])}catch(e){dbg(e)}}
function ringStart(){ringStop();let n=0;pulses();ringT=setInterval(()=>{pulses();if(++n>=40)ringStop()},1500)}
function ringStop(){clearInterval(ringT);ringT=null;try{navigator.vibrate&&navigator.vibrate(0)}catch(e){dbg(e)}}
function beep(){ringStart()}
function fire(k){
 const m=MSG[Math.floor(Math.random()*MSG.length)];beep();
 notif(k=='حفظ'?'وقت الحفظ 📖':'وقت المراجعة 🔁',{body:m})
 $('#ban').innerHTML=`<div class="c" style="border-color:var(--pri)"><b>${k=='حفظ'?'وقت الحفظ 📖':'وقت المراجعة 🔁'}</b><div class="m">${m}</div>
 <div class="row" style="margin-top:8px"><button type="button" onclick="bdone('${k}')">تم ✅</button><button type="button" class="g" onclick="snooze('${k}')">غفوة 15 دقيقة ⏰</button></div></div>`}
function bdone(k){ringStop();const t=due().find(x=>x.type==k);$('#ban').innerHTML='';if(t)done(t.id,'mastered')}
function snooze(k){ringStop();const n=new Date(Date.now()+9e5);S.alarms.push({id:S.id++,time:hm(n),k,days:[n.getDay()],on:true,once:true});save();$('#ban').innerHTML=''}
setInterval(()=>{const n=new Date(),key=ymd(n)+hm(n);if(key==fired)return;
 const a=S.alarms.find(a=>a.on&&a.time==hm(n)&&a.days.includes(n.getDay()));
 if(a){fired=key;fire(a.k);if(a.once){S.alarms=S.alarms.filter(x=>x!==a);save()}}},15000);
/* ---------- الأرشيف ---------- */
let af='all';
const BADGE={mastered:['🟢','ناجحة'],light:['🟡','تحتاج مراجعة'],hard:['🔴','متعثرة']};
const dt=v=>{if(!v)return'';if(v.length==10)return v;const d=new Date(v);return D[d.getDay()]+' • '+hij(d)+' • '+ymd(d)+' '+hm(d)};
const stOf=t=>{const l=[...S.logs].reverse().find(x=>x.t==t.id);return l?l.r:null};
function archT(id,v){const t=S.tasks.find(x=>x.id==id);t.arch=v;if(v)t.doneAt=new Date().toISOString();else delete t.doneAt;save();draw()}
let arSec='d';const arOpen={};
function arCard(id,title,badge,sub,det,btn){const o=arOpen[id];return `<div class="c"><div class="row sp" style="cursor:pointer;flex-wrap:nowrap" onclick="arOpen['${id}']=!arOpen['${id}'];draw()"><b>${title}</b><span class="m" style="display:inline-block;font-size:12px;transform:rotate(${o?180:0}deg)">▾</span></div>${o?`${badge?`<div class="m" style="margin-top:6px">${badge}</div>`:''}${sub?`<div class="m">${sub}</div>`:''}${btn?`<div style="margin-top:8px">${btn}</div>`:''}${det?`<div class="m" style="line-height:1.9;margin-top:8px">${det}</div>`:''}`:''}</div>`}
function arDel(k,id){ask('هل تريد الحذف؟',()=>{if(k=='d')S.arc=(S.arc||[]).filter(a=>a.id!=id);else if(k=='c')S.carc=(S.carc||[]).filter(c=>c.id!=id);else if(k=='t')S.tda=(S.tda||[]).filter(x=>x.id!=id);else if(k=='v')pvD().arc=(pvD().arc||[]).filter(x=>x.id!=id);else if(k=='m')S.tasks=S.tasks.filter(t=>t.id!=id);save();toast('تم الحذف');draw()},'نعم','لا')}
function arRestore(k,id){ask('هل تريد الاسترجاع؟',()=>arRestore2(k,id),'نعم','لا')}
function arRestoreM(id){ask('هل تريد الاسترجاع؟',()=>archT(id,false),'نعم','لا')}
function arRestore2(k,id){
 if(k=='d'){const i=(S.arc||[]).findIndex(a=>a.id==id);if(i<0)return;const a=S.arc[i];const tk=a.tk?JSON.parse(JSON.stringify(a.tk)):{s:a.name,j:0,tm:a.og?mkT(a.og):null,a:1,b:1,type:'مراجعة',stage:0,next:new Date().toISOString()};
  if(tk.id==null||S.tasks.some(x=>x.id==tk.id))tk.id=S.id++;S.tasks.push(tk);S.arc.splice(i,1);
  if(a.lg){const li=S.logs.map((l,ix)=>l.t==a.lg.t&&l.date==a.lg.date&&l.time==a.lg.time?ix:-1).filter(ix=>ix>=0).pop();if(li!==undefined)S.logs.splice(li,1)}
  (tk.js||(tk.j?[tk.j]:[])).forEach(n=>{const j=(S.juz||{})[n];if(j&&j.n>0){j.n--;(j.h=j.h||[]).pop();j.last=j.h.length?j.h[j.h.length-1]:null}})}
 else if(k=='c'){const i=(S.carc||[]).findIndex(c=>c.id==id);if(i<0)return;const c=S.carc.splice(i,1)[0];c.fin=false;c.el=0;c.e0=0;S.cont.push(c)}
 else if(k=='t'){const i=(S.tda||[]).findIndex(x=>x.id==id);if(i<0)return;const x=S.tda.splice(i,1)[0];x.s=0;x.at=0;tdL().push(x)}
 else{const P=pvD(),i=(P.arc||[]).findIndex(x=>x.id==id);if(i<0)return;const x=P.arc.splice(i,1)[0];x.s=0;x.at=0;P.items.push(x)}
 save();toast('تم الاسترجاع');draw()}
const arTy=a=>a.ty||(a.tk&&a.tk.type)||((S.tasks||[]).find(x=>x.id==a.tid)||{}).type||'',arTyL=a=>{const y=arTy(a);return y=='حفظ'?'📖 حفظ':y=='مراجعة'?'🔁 مراجعة':''};
function archive(){const iso=ms=>ms?new Date(ms).toISOString():'',rb=(k,id)=>`<div class="row" style="gap:8px"><button type="button" class="g" style="padding:5px 12px" onclick="arRestore('${k}',${id})">استرجاع</button><button type="button" class="r" style="padding:5px 12px" onclick="arDel('${k}',${id})">حذف</button></div>`;let body='';
 if(arSec=='d'){const A=(S.arc||[]).slice().reverse();
  body=A.map(a=>{const b=BADGE[a.r]||['',''];return arCard('d'+a.id,esc(a.name),b[0]+' '+b[1],(arTyL(a)?arTyL(a)+' • ':'')+(a.sub?esc(a.sub)+' • ':'')+dt(a.en),`بدأت: ${dt(a.st)}<br>انتهت: ${dt(a.en)}<br>الوقت المستغرق: ${hms(a.us)}<br>الوقت الزائد: ${hms(Math.max(a.ov||0,a.og?Math.max(0,(a.us||0)-a.og):0))}<br>الوقت الأصلي: ${a.og?hms(a.og):'—'}`,rb('d',a.id))}).join('')||'<div class="c m">لا مهام مكتملة بعد. تظهر هنا كل مهمة تضغط عليها «تم».</div>';
  const M=S.tasks.filter(t=>t.arch);if(M.length)body+='<div class="ph">مهام مؤرشفة يدوياً</div>'+M.map(t=>arCard('m'+t.id,esc(t.s),'','','',`<div class="row" style="gap:8px"><button type="button" class="g" style="padding:5px 12px" onclick="arRestoreM(${t.id})">استرجاع</button><button type="button" class="r" style="padding:5px 12px" onclick="arDel('m',${t.id})">حذف</button></div>`)).join('')}
 else if(arSec=='w'){body=tcArc()}
 else if(arSec=='c'){const C=(S.carc||[]).slice().sort((a,b)=>(b.e0||0)-(a.e0||0));
  body=C.map(c=>arCard('c'+c.id,esc(c.name),c.heard.length+' من '+c.juz.length+' أجزاء','الأجزاء: '+c.heard.map(uLbl).join('، '),`بدأ: ${c.s0?dt(iso(c.s0)):'—'}<br>انتهى: ${c.e0?dt(iso(c.e0)):'—'}<br>الوقت المستغرق: ${hms(c.el)}<br>الوقت الزائد: ${hms(mOver(c.tm))}<br>الوقت الأصلي: ${hms(mOrig(c.tm))}`,rb('c',c.id))).join('')||'<div class="c m">لا مسابقات منتهية بعد</div>'}
 else{const T=(S.tda||[]).slice().sort((a,b)=>(b.at||0)-(a.at||0)),PV=((S.pv||{}).arc||[]).slice().sort((a,b)=>(b.at||0)-(a.at||0)),f=(x,pre)=>arCard(pre+x.id,esc(x.t),x.s==1?'✓ صح':'✗ غلط','',`أُضيفت: ${x.c?dt(iso(x.c)):'—'}<br>أُنجزت: ${x.at?dt(iso(x.at)):'—'}<br>المدة: ${x.c&&x.at?hms((x.at-x.c)/1000):'—'}`,rb(pre,x.id));
  body=(T.map(x=>f(x,'t')).join('')||'<div class="c m">لا مهام مكتملة في القائمة بعد</div>')+`<div class="c"><div class="row sp" style="cursor:pointer" onclick="arPv()"><b>${svg('lock')} قائمة المهام الخاصة</b><span class="m">${arPvOpen&&pvOk?'▴':'▾'}</span></div>${arPvOpen&&pvOk?(PV.map(x=>f(x,'v')).join('')||'<div class="m">لا مهام خاصة منتهية بعد</div>'):''}</div>`}
 return body+`<div class="arb">${[['d','المراجعة والحفظ'],['c','المسابقات'],['t','قائمة المهمات'],['w','الواجبات']].map(([k,t])=>`<button type="button" class="${arSec==k?'':'g'}" onclick="arSec='${k}';draw()">${t}</button>`).join('')}</div>`}
/* ---------- الإحصائيات ---------- */
function taskGroups(){const g={};S.logs.forEach(l=>{const t=S.tasks.find(x=>x.id==l.t)||{};g[l.t]={id:l.t,r:l.r,s:l.s||t.s||'مهمة محذوفة',a:l.a??t.a,b:l.b??t.b,arch:!!t.arch,n:l.n||(isG(t)?1:0)}});return Object.values(g)}
function taskStats(){
 const G=taskGroups(),c={mastered:0,light:0,hard:0};G.forEach(x=>c[x.r]++);
 const a={mastered:0,light:0,hard:0};S.logs.forEach(l=>a[l.r]++);
 const tot=Math.max(1,c.mastered+c.light+c.hard),arch=S.tasks.filter(t=>t.arch).length;
 return `<div class="c"><b>حالة المهام (حسب آخر تقييم)</b>`+
 ['mastered','light','hard'].map(k=>`<div style="margin-top:16px"><div class="row sp" style="line-height:1.7"><span>${BADGE[k][0]} ${BADGE[k][1]}</span><b>${c[k]}</b></div><div style="height:8px;background:var(--bd);border-radius:6px;margin:8px 0 6px"><div style="height:8px;width:${c[k]/tot*100}%;background:${k=='hard'?'var(--bad)':k=='light'?'#f9a825':'var(--pri)'};border-radius:6px"></div></div><div class="m" style="line-height:1.7">إجمالي المحاولات: ${a[k]}</div></div>`).join('')+
 `<div style="margin-top:12px">🏆 مهام مؤرشفة: <b>${arch}</b></div>`+
 `<div style="margin-top:14px;border-top:1px solid var(--bd)">`+(G.map(x=>`<div class="row sp" style="padding:8px 0;border-bottom:1px solid var(--bd)"><span>${x.arch?'🏆':BADGE[x.r][0]} ${(x.n||/^(مهمة|الجزء)/.test(x.s))?esc(x.s):'سورة '+esc(x.s)} ${(x.a&&!x.n)?`<span class="m">(${x.a}–${x.b})</span>`:''}</span><button type="button" class="g" style="padding:6px 10px;font-size:13px" onclick="delStat(${x.id})">🗑 حذف من الإحصائيات</button></div>`).join('')||'<div class="m" style="padding-top:8px">لا مهام في الإحصائيات بعد</div>')+`</div></div>`}
let pf=null;
function ask(m,f,l,n){pf=f;$('#sh').innerHTML=`<div class="sh"><div><b>${esc(m)}</b><button type="button" class="r" onclick="cf(1)">${l||'نعم، احذف'}</button><button type="button" class="g" onclick="cf(0)">${n||'إلغاء'}</button></div></div>`}
function cf(y){const f=pf;pf=null;$('#sh').innerHTML='';if(y&&f)f()}
function delStat(id){const l=S.logs.find(x=>x.t==id),t=S.tasks.find(x=>x.id==id),n=(t||l||{}).s||'هذه المهمة';ask('حذف '+n+' من الإحصائيات؟ (تُحذف سجلاتها فقط)',()=>{S.logs=S.logs.filter(x=>x.t!=id);save();draw()})}
function stats(){
 const en=S.lang=='en',st=streak(),day=i=>new Date(Date.now()-i*864e5),LM=S.logs.reduce((o,l)=>(o[l.date]=(o[l.date]||0)+1,o),{}),cnt=i=>LM[ymd(day(i))]||0,
 wk=[6,5,4,3,2,1,0].map(i=>{const x=day(i);return[(en?['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][x.getDay()]:D[x.getDay()].slice(0,3)),cnt(i),i==0]}),
 tw=wk.reduce((a,w)=>a+w[1],0),lw=[13,12,11,10,9,8,7].reduce((a,i)=>a+cnt(i),0),dl=tw-lw,mx=Math.max(1,...wk.map(w=>w[1])),hr={};
 S.logs.filter(l=>l.r=='mastered').forEach(l=>{const h=l.time.slice(0,2);hr[h]=(hr[h]||0)+1});
 const b=Object.entries(hr).sort((a,b)=>b[1]-a[1])[0],q={mastered:0,light:0,hard:0};S.logs.forEach(l=>{if(q[l.r]!=null)q[l.r]++});
 const CL={mastered:'#2e7d32',light:'#f9a825',hard:'#e53935'};
 return `<div class="row sp ptl"><b>إنجازاتي</b><button type="button" class="g" onclick="printReport('all')">${qic('doc')} PDF</button></div>
 <section class="hero"><div class="hr-t"><div><div class="hr-g">الاستمرارية</div><div class="hr-d">${st} يوم</div><div class="hr-m">${S.logs.length} جلسة إجمالًا</div></div><div class="flame">${qic('flame')}</div></div><div class="hr-s"><div><b>${tw}</b><span>هذا الأسبوع</span></div><div><b>${dl>0?'+':''}${dl}</b><span>عن الأسبوع الماضي</span></div><div><b>${b?b[0]+':00':'—'}</b><span>أفضل ساعة تركيز</span></div></div></section>
 ${taskStats()}
 <div class="c"><b>آخر 7 أيام</b><div class="bar" style="margin-top:12px">${wk.map(w=>`<div class="${w[2]?'tdy':''}" style="height:${w[1]/mx*100}%">${w[1]||''}</div>`).join('')}</div><div class="row m" style="margin-top:6px">${wk.map(w=>`<span style="flex:1;text-align:center;${w[2]?'color:var(--pri);font-weight:700':''}">${w[0]}</span>`).join('')}</div></div>
 <div class="c"><b>جودة المراجعات</b><div class="qbar"><i style="flex:${q.mastered};background:${CL.mastered}"></i><i style="flex:${q.light};background:${CL.light}"></i><i style="flex:${q.hard};background:${CL.hard}"></i></div><div class="row sp m" style="margin-top:8px"><span><i class="dt" style="background:${CL.mastered}"></i>متقنة ${q.mastered}</span><span><i class="dt" style="background:${CL.light}"></i>تحتاج مراجعة ${q.light}</span><span><i class="dt" style="background:${CL.hard}"></i>متعثرة ${q.hard}</span></div></div>
 <div class="c"><b>آخر العمليات</b><div class="tl">${S.logs.slice(-10).reverse().map(l=>`<div><i class="dt" style="background:${CL[l.r]||'var(--mut)'}"></i><div><b>${l.day} • ${l.h}</b><div class="m">${l.date} ${l.time} (${l.dur} د)</div></div></div>`).join('')||'<div class="m">لا سجلات بعد</div>'}</div></div>`}
/* ---------- جدول الأجزاء ---------- */
function jAdd(i,auto){S.juz=S.juz||{};const j=S.juz[i]||(S.juz[i]={n:0,h:[]});j.n++;j.last=new Date().toISOString();j.h=[...(j.h||[]),j.last].slice(-60);save();if(!auto)draw()}
function jSub(i){const j=(S.juz||{})[i];if(!j||!j.n)return;j.n--;(j.h=j.h||[]).pop();j.last=j.h.length?j.h[j.h.length-1]:null;save();draw()}
function jSubAsk(i){const n=((S.juz||{})[i]||{}).n||0;if(!n){toast('لا جلسات لإنقاصها');return}$('#sh').innerHTML=shW(`<b>إنقاص جلسات من الجزء ${i}</b><div class="m" style="margin:6px 0">عدد الجلسات الحالي: ${n}. كم جلسة تريد أن تنقص؟</div><input id="jsn" type="number" min="1" max="${n}" value="1" inputmode="numeric"><button type="button" onclick="jSubDo(${i})">تأكيد</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
function jSubDo(i){const j=(S.juz||{})[i],k=Math.max(1,Math.min(j.n,+$('#jsn').value||1));for(let x=0;x<k;x++){j.n--;(j.h=j.h||[]).pop()}j.last=j.h.length?j.h[j.h.length-1]:null;save();$('#sh').innerHTML='';draw()}
const jOpen={};
function jT(i){jOpen[i]=!jOpen[i];draw()}
function jz(){
 const J=S.juz||{},now=Date.now();let tot=0,old=0;
 const rows=[...Array(30)].map((_,k)=>{const i=k+1,j=J[i]||{},n=j.n||0,d=j.last?new Date(j.last):null,days=d?Math.floor((now-d)/864e5):null,st=days===null||days>30,h=[...(j.h||[])].reverse();tot+=n;if(st)old++;
  const det=jOpen[i]?`<tr><td colspan="4" style="padding:4px 10px 12px"><div class="m" style="margin-bottom:4px">سجل جلسات الجزء ${i} (${n} جلسة)</div>${h.length?h.map((x,ix)=>{const dd=new Date(x);return `<div style="padding:6px 0;border-top:1px dashed var(--bd)">${h.length-ix}. ${D[dd.getDay()]} • ${ymd(dd)} • ${hm(dd)}<div class="m">${hij(dd)}</div></div>`}).join(''):'<div class="m">لا جلسات مسجّلة بعد</div>'}${n>h.length?`<div class="m">+ ${n-h.length} جلسات أقدم بلا تاريخ</div>`:''}</td></tr>`:'';
  return `<tr style="border-top:1px solid var(--bd)"><td style="padding:10px 6px"><b style="${st?'color:var(--bad)':''}">الجزء ${i}</b><br><button type="button" class="g" style="padding:1px 9px;font-size:12px;margin-top:4px" onclick="jT(${i})">${jOpen[i]?'▴':'▾'} الجلسات</button></td><td style="text-align:center;font-size:20px"><b>${n}</b></td><td class="m" style="text-align:center">${d?(days==0?'اليوم':'قبل '+days+' يوم')+'<br>'+ymd(d):'—'}</td><td style="white-space:nowrap;text-align:left"><button type="button" style="padding:4px 13px" onclick="jAdd(${i})">+</button> <button type="button" class="g" style="padding:4px 13px" onclick="jSubAsk(${i})">−</button></td></tr>${det}`}).join('');
 return `<div style="padding:8px 12px 0"><button type="button" class="g" onclick="printReport('juz')" style="width:100%">📄 حفظ جدول الأجزاء كملف PDF</button></div><div class="row" style="padding:0 12px"><div class="c" style="flex:1;margin:10px 0">🔁 إجمالي المراجعات<br><b style="font-size:22px">${tot}</b></div><div class="c" style="flex:1;margin:10px 0">⚠️ لم يُراجَع منذ 30 يوماً<br><b style="font-size:22px">${old}</b></div></div>
 <div class="c" style="padding:4px 8px;overflow-x:auto"><table style="width:100%;border-collapse:collapse"><tr class="m"><td style="padding:8px 6px">الجزء</td><td style="text-align:center">المراجعات</td><td style="text-align:center">آخر مراجعة</td><td></td></tr>${rows}</table></div>
 <div class="m" style="margin:0 16px">اضغط + عند كل جلسة و− للتراجع. وزر «▾ الجلسات» تحت كل جزء يعرض تواريخ كل جلساته. الأجزاء بالأحمر لم تُراجع منذ أكثر من 30 يوماً.</div>`}
window.addEventListener('unhandledrejection',e=>{try{sync('⚠️ '+((e.reason&&(e.reason.code||e.reason.message))||e.reason))}catch(x){dbg(x)}});

/* ---------- الحساب والمزامنة السحابية ---------- */
let fa=null,fs=null,fu=null,fbOK=false,sm='',pt=null,busy=0;
const EMPTY=()=>({tasks:[],logs:[],alarms:[],mist:[],skipFri:true,id:1});
function sync(m){sm=m;const e=$('#sm');if(e)e.textContent=m;const w=document.getElementById('awm');if(w){w.textContent=m;w.classList.toggle('ok',/^✅/.test(m))}}
/* ---------- تعدد الحسابات والتبديل السريع ---------- */
/* كل حساب إضافي يعمل في تطبيق Firebase مسمّى مستقل، فتبقى جلسته محفوظة ويكون التبديل فورياً */
let addKey='',addPrev=null,accQuiet=0,awAdd=false;
const accList=()=>{try{return JSON.parse(localStorage.getItem('qmrm_accs')||'[]')}catch(e){return[]}};
const accSave=L=>{try{localStorage.setItem('qmrm_accs',JSON.stringify(L))}catch(e){dbg(e)}};
const accAct=()=>{try{return localStorage.getItem('qmrm_acta')||''}catch(e){return''}};
const accCache=uid=>{try{const t=localStorage.getItem('qmrm_u_'+uid);return t?Object.assign(EMPTY(),JSON.parse(t)):null}catch(e){return null}};
const accName=a=>((fu&&a.uid==fu.uid&&prof().name)||a.n||a.name||(a.email||'').split('@')[0]||'—');
const accAv=a=>{const ph=(fu&&a.uid==fu.uid&&prof().photo)||a.photo;return ph?`<img src="${esc(ph)}" referrerpolicy="no-referrer" style="width:100%;height:100%;object-fit:cover" alt="">`:esc((accName(a)||'?').trim().charAt(0).toUpperCase())};
const accNext=()=>accList().find(a=>{try{return !!firebase.app(a.k).auth().currentUser}catch(e){return false}});
function accSeen(key,u){const L=accList();let e=L.find(a=>a.uid==u.uid);if(!e){e={k:key,uid:u.uid};L.push(e)}e.k=key;e.name=u.displayName||e.name||'';e.email=u.email||e.email||'';e.photo=u.photoURL||e.photo||'';accSave(L)}
function accGone(key){accSave(accList().filter(a=>a.k!==key))}
function accCacheSave(){if(!fu)return;try{localStorage.setItem('qmrm_u_'+fu.uid,JSON.stringify(S))}catch(e){dbg(e)}const L=accList(),e=L.find(a=>a.uid==fu.uid);if(e){e.n=prof().name||e.n||'';accSave(L)}}
function accRemove(uid){const L=accList(),e=L.find(a=>a.uid==uid);accSave(L.filter(a=>a.uid!=uid));try{localStorage.removeItem('qmrm_u_'+uid)}catch(x){dbg(x)}if(e&&e.k!=='[DEFAULT]'){try{firebase.app(e.k).delete()}catch(x){dbg(x)}}}
function accEnter(u){if(S._uid&&S._uid!==u.uid){S=accCache(u.uid)||EMPTY();S._uid=u.uid;S.lang=BOOT_LANG;migrate();try{localStorage.setItem('qmrm',JSON.stringify(S))}catch(e){dbg(e)}applyTheme();draw()}}
function accAttach(key,au){
 au.onAuthStateChanged(u=>{
  if(key===addKey&&u){const d=accList().find(a=>a.uid==u.uid);addKey='';awAdd=false;
   if(d){const p=addPrev||{};fa=p.fa;fs=p.fs;fu=p.fu;try{au.signOut()}catch(e){dbg(e)}try{firebase.app(key).delete()}catch(e){dbg(e)}awHide();toast('هذا الحساب مضاف مسبقاً');accSwitch(d.uid);return}}
  if(u)accSeen(key,u);else if(key!==addKey)accGone(key);
  if(au!==fa||accQuiet)return;
  if(u){fu=u;try{localStorage.setItem('qmrm_acta',u.uid)}catch(e){dbg(e)}accEnter(u);if(u.displayName&&!prof().name)prof().name=u.displayName;awHide();pull()}
  else{fu=null;const o=(key!==addKey)?accNext():null;if(o){accSwitch(o.uid,true);return}if(!awG()||key===addKey)awShow()}
  if(tab=='se')draw()})}
function accBoot(dA,dF){const L=accList(),want=L.find(a=>a.uid===accAct());fa=dA;fs=dF;
 L.filter(a=>a.k!=='[DEFAULT]').forEach(a=>{try{const ap=firebase.initializeApp(FB,a.k);if(want&&want.k===a.k){fa=ap.auth();fs=ap.firestore()}accAttach(a.k,ap.auth())}catch(e){dbg(e)}});
 accAttach('[DEFAULT]',dA)}
async function accSwitch(uid,noPush){
 const a=accList().find(x=>x.uid==uid);if(!a||(fu&&fu.uid==uid&&!noPush))return;
 let ap;try{ap=firebase.app(a.k)}catch(e){dbg(e)}
 const au=ap&&ap.auth(),u=au&&au.currentUser;
 if(!u){accGone(a.k);toast('انتهت جلسة هذا الحساب، أضفه من جديد');if(tab=='se')draw();return}
 if(!noPush&&fu){clearTimeout(pt);try{await pushNow()}catch(e){dbg(e)}accCacheSave()}
 fa=au;fs=ap.firestore();fu=u;try{localStorage.setItem('qmrm_acta',uid)}catch(e){dbg(e)}
 S=accCache(uid)||EMPTY();S._uid=uid;S.lang=BOOT_LANG;migrate();try{localStorage.setItem('qmrm',JSON.stringify(S))}catch(e){dbg(e)}
 pvOk=false;arPvOpen=false;tab='home';$('#sh').innerHTML='';awHide();applyTheme();draw();toast('تم التبديل إلى '+accName(a));pull()}
function accTap(uid){$('#sh').innerHTML='';if(!fu||fu.uid!=uid)accSwitch(uid)}
async function accAdd(){if(!fbOK||!fu||busy)return;
 try{clearTimeout(pt);await pushNow()}catch(e){dbg(e)}accCacheSave();
 const k='a'+Date.now().toString(36),ap=firebase.initializeApp(FB,k);
 addPrev={fa,fs,fu};addKey=k;fa=ap.auth();fs=ap.firestore();fu=null;accAttach(k,fa);
 $('#sh').innerHTML='';sync('');awMode='in';awAdd=true;awShow()}
function accCancelAdd(){if(!addKey)return;const k=addKey;addKey='';awAdd=false;const p=addPrev||{};fa=p.fa;fs=p.fs;fu=p.fu;try{firebase.app(k).delete()}catch(e){dbg(e)}sync('');awHide();draw()}
function accBar(){const L=accList();if(!fu||!L.length)return '';
 const cell=(on,inner,label,f,dash)=>`<div onclick="${f}" style="text-align:center;width:62px;cursor:pointer"><div style="width:46px;height:46px;margin:0 auto 3px;border-radius:50%;overflow:hidden;display:flex;align-items:center;justify-content:center;box-sizing:border-box;${dash?'border:2px dashed var(--bd);color:var(--pri)':'background:var(--pri);color:var(--on);font-weight:700;font-size:19px;border:3px solid '+(on?'var(--gold)':'transparent')}">${inner}</div><div style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;${on?'font-weight:700':'opacity:.8'}">${label}</div></div>`;
 return `<div class="dsec">الحسابات</div><div style="display:flex;gap:10px;padding:2px 16px 12px;flex-wrap:wrap;align-items:flex-start">${L.map(a=>cell(a.uid==fu.uid,accAv(a),esc(accName(a)),`accTap('${a.uid}')`)).join('')}${cell(0,svg('plus'),'إضافة حساب','accAdd()',1)}</div>`}
function accCard(){const L=accList();if(!fu)return '';
 return `<div class="ph">الحسابات</div><div class="pcard">${L.map(a=>`<div class="prow act" onclick="accTap('${a.uid}')"><span class="pi" style="overflow:hidden;font-weight:700">${accAv(a)}</span><span class="pl">${esc(accName(a))}<br><small class="m" dir="ltr">${esc(a.email)}</small></span><b style="color:var(--pri)">${fu&&a.uid==fu.uid?'✓':''}</b></div>`).join('')}<div class="prow act" onclick="accAdd()"><span class="pi">${svg('plus')}</span><span class="pl">إضافة حساب</span><span class="ch">${svg('chev')}</span></div></div>`}
function fbInit(){
 if(!FB.apiKey||!window.firebase)return;
    if(!awG()){awSplash();setTimeout(()=>{const a=document.getElementById('aw');if(a&&a.querySelector&&a.querySelector('.awspin'))awHide()},6000)}
    try{firebase.initializeApp(FB);const dA=firebase.auth(),dF=firebase.firestore();fbOK=true;accBoot(dA,dF)}catch(e){dbg(e)}}
/* ===== المزامنة: تلقائية دائماً + تتجدد لحالها ===== */
const INL=300000,PART=300000;let pushing=false,again=false,pushFail=0,unsub=null,dnTry=0;
function cutParts(d){const a=[];let i=0;while(i<d.length){let j=Math.min(d.length,i+PART);if(j<d.length){const c=d.charCodeAt(j-1);if(c>=0xD800&&c<=0xDBFF)j--}a.push(d.slice(i,j));i=j}return a}
function synBar(m,bad){let e=document.getElementById('syb');if(!m){if(e)e.remove();return}
 if(!e){e=document.createElement('div');e.id='syb';e.style.cssText='position:fixed;inset-inline:12px;bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:25;padding:10px 14px;border-radius:14px;font-size:13.5px;line-height:1.5;box-shadow:0 4px 18px #0004;text-align:center';document.body.appendChild(e)}
 e.style.background=bad?'var(--bad)':'var(--card)';e.style.color=bad?'#fff':'var(--tx)';e.textContent=m}
function pushBad(e){const c=(e&&e.code)||'';let m,bad=1;
 if(c==='permission-denied')m='تعذّر رفع بياناتك: صلاحيات Firestore تحتاج تحديثاً (أضف قاعدة parts)';
 else if(c==='invalid-argument'||/size|large|exceed/i.test((e&&e.message)||''))m='تعذّر رفع بياناتك: حجم البيانات كبير، احذف بعض الصور من الدفاتر';
 else if(c==='unavailable'||c==='deadline-exceeded'||c==='network-request-failed'){m='لا يوجد اتصال بالإنترنت، ستُرفع تغييراتك تلقائياً عند عودته';bad=0}
 else m='تعذّرت المزامنة ('+(c||(e&&e.message)||'?')+')، سنعيد المحاولة تلقائياً';
 sync('⚠️ '+m);synBar(m,bad)}
async function pushNow(strict){
 if(!fu||!fs)return false;
 if(pushing){again=true;if(!strict)return false;while(pushing)await new Promise(r=>setTimeout(r,200))}
 pushing=true;let ok=false;
 try{
  do{again=false;
   const uid=fu.uid,d=JSON.stringify(S),u=S._u||Date.now(),ref=fs.collection('users').doc(uid);
   if(d.length<=INL)await ref.set({d,u,n:0});
   else{const ps=cutParts(d),bt=fs.batch(),pc=ref.collection('parts');ps.forEach((x,i)=>bt.set(pc.doc('p'+i),{s:x,u}));bt.set(ref,{d:'',u,n:ps.length});await bt.commit()}
  }while(again);
  ok=true;pushFail=0;synBar('');sync('تمت المزامنة ✅')
 }catch(e){pushFail++;pushBad(e);const c=e&&e.code;if(c!=='permission-denied'&&c!=='invalid-argument')setTimeout(()=>{if(fu&&!pt&&!pushing)pushNow()},Math.min(60000,4000*Math.pow(2,Math.min(pushFail,4))))}
 finally{pushing=false}
 return ok}
function push(){if(!fu)return;clearTimeout(pt);pt=setTimeout(()=>{pt=null;pushNow()},1500)}
async function readCloud(uid){
 for(let t=0;t<2;t++){
  const ref=fs.collection('users').doc(uid),r=await ref.get();
  if(!r.exists)return null;
  const c=r.data();let d=c.d||'';
  if(c.n>0){const q=await ref.collection('parts').get(),m={};q.forEach(x=>{m[x.id]=x.data()});const a=[];let bad=0;
   for(let i=0;i<c.n;i++){const x=m['p'+i];if(!x||x.u!==c.u){bad=1;break}a.push(x.s)}
   if(bad){if(t==0){await new Promise(r=>setTimeout(r,900));continue}throw{code:'parts-mismatch'}}
   d=a.join('')}
  return{d,u:c.u||0}}
 return null}
function localExtra(cl){const ids=a=>new Set((a||[]).map(x=>x.id)),n=ids(cl.nbs),t=ids(cl.tasks);return(S.nbs||[]).some(x=>!n.has(x.id))||(S.tasks||[]).some(x=>!t.has(x.id))}
function adopt(cl,warn){
 const extra=warn&&localExtra(cl);
 if(extra){try{localStorage.setItem('qmrm_prev_'+fu.uid,JSON.stringify({at:Date.now(),s:S}))}catch(e){dbg(e)}}
 S=Object.assign(EMPTY(),cl);S._uid=fu.uid;S.lang=BOOT_LANG;migrate();
 try{localStorage.setItem('qmrm',JSON.stringify(S))}catch(e){dbg(e)}
 idb.set('S',JSON.stringify(S)).catch(()=>{});applyTheme();draw();
 if(extra){synBar('وُجدت بيانات على هذا الجهاز غير موجودة في السحابة. يمكنك استعادتها من الإعدادات ← استعادة بيانات الجهاز.',1);setTimeout(()=>synBar(''),15000)}}
const editingNow=()=>{const a=document.activeElement;return !!a&&(a.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(a.nodeName||''))};
async function syncDown(){
 if(!fu||!fs||pushing||pt)return;
 const uid=fu.uid;
 try{const c=await readCloud(uid);if(!c||!fu||fu.uid!==uid||pt||pushing)return;
  if(c.u>(S._u||0)){
   if(editingNow()&&dnTry<10){dnTry++;setTimeout(syncDown,3000);return}
   dnTry=0;adopt(JSON.parse(c.d),0);sync('تم تحديث بياناتك من السحابة ☁️')}
 }catch(e){dbg(e)}}
function listen(){
 if(unsub){try{unsub()}catch(e){dbg(e)}unsub=null}
 if(!fu||!fs)return;const uid=fu.uid;
 try{unsub=fs.collection('users').doc(uid).onSnapshot(sn=>{if(!fu||fu.uid!==uid||sn.metadata.hasPendingWrites)return;const c=sn.data();if(c&&(c.u||0)>(S._u||0))syncDown()},()=>{})}catch(e){dbg(e)}}
async function pull(){
 try{await idbReady;const uid=fu.uid,c=await readCloud(uid);
  if(!fu||fu.uid!==uid)return;
  if(c){const cl=JSON.parse(c.d);
   if(S._uid!==uid||c.u>(S._u||0)){adopt(cl,1);sync('تم تحميل بياناتك من السحابة ☁️');listen();return}}
  S._uid=uid;save();sync('تمت المزامنة ✅');listen()
 }catch(e){pushBad(e)}}
function prevGet(){try{const t=localStorage.getItem('qmrm_prev_'+(fu&&fu.uid));return t?JSON.parse(t):null}catch(e){return null}}
function restorePrev(){const p=prevGet();if(!p||!fu)return;
 ask('استعادة بيانات هذا الجهاز التي كانت قبل التحميل من السحابة؟ ستُرفع إلى حسابك.',()=>{S=Object.assign(EMPTY(),p.s);S._uid=fu.uid;S.lang=BOOT_LANG;migrate();try{localStorage.removeItem('qmrm_prev_'+fu.uid)}catch(e){dbg(e)}save();applyTheme();draw();toast('تمت الاستعادة')},'نعم، استعد')}
const ERR={'auth/invalid-email':'البريد غير صحيح','auth/invalid-credential':'البريد أو كلمة المرور غير صحيحة','auth/user-not-found':'لا يوجد حساب بهذا البريد','auth/wrong-password':'كلمة المرور غير صحيحة','auth/email-already-in-use':'هذا البريد مسجّل مسبقاً، سجّل الدخول','auth/weak-password':'كلمة المرور ضعيفة (6 أحرف على الأقل)','auth/network-request-failed':'تحقق من الإنترنت','auth/missing-password':'اكتب كلمة المرور','auth/missing-email':'اكتب بريدك الإلكتروني','auth/operation-not-allowed':'تسجيل الدخول بالبريد غير مفعّل في Firebase','auth/too-many-requests':'محاولات كثيرة، انتظر قليلاً','auth/unauthorized-domain':'هذا النطاق غير مصرّح به في Firebase','auth/internal-error':'خطأ داخلي في Firebase','bad-username':'اسم المستخدم من 3 إلى 20 حرفاً: أحرف إنجليزية صغيرة وأرقام و _ و .','username-taken':'اسم المستخدم محجوز، اختر اسماً آخر','username-notfound':'اسم المستخدم غير موجود','permission-denied':'غير مسموح: حدّث قواعد Firestore (القواعد الجديدة في شرح التحديث)','auth/popup-closed-by-user':'أُغلقت نافذة Google قبل إتمام الدخول','auth/popup-blocked':'المتصفح حظر النافذة، اسمح بالنوافذ المنبثقة وأعد المحاولة','auth/cancelled-popup-request':'أُلغيت المحاولة، أعد المحاولة','auth/account-exists-with-different-credential':'هذا البريد مسجّل بطريقة دخول أخرى'};
const er=e=>sync('⚠️ '+(ERR[e.code]||'حدث خطأ')+' ('+(e.code||e.message)+')');
const unOk=u=>/^[a-z0-9_.]{3,20}$/.test(u);
async function unGet(u){const d=await fs.collection('usernames').doc(u).get();return d.exists?d.data():null}
async function claimUn(raw){const u=String(raw||'').trim().toLowerCase(),cu=(fa&&fa.currentUser)||fu;if(!unOk(u))throw{code:'bad-username'};if(!cu)throw{code:'auth/requires-recent-login'};const ref=fs.collection('usernames').doc(u);
 await fs.runTransaction(async tx=>{const d=await tx.get(ref);if(d.exists&&d.data().uid!==cu.uid)throw{code:'username-taken'};tx.set(ref,{uid:cu.uid,email:cu.email})});
 const old=prof().user;if(old&&old!==u){try{await fs.collection('usernames').doc(old).delete()}catch(e){dbg(e)}}prof().user=u;save()}
async function resolveEmail(id){id=id.trim();if(id.includes('@'))return id;const d=await unGet(id.toLowerCase());if(!d)throw{code:'username-notfound'};return d.email}
async function unSave(){try{await claimUn($('#unin').value);toast('تم حفظ اسم المستخدم');draw()}catch(e){er(e)}}
async function doIn(id,p){if(!id||!p){sync('⚠️ اكتب البريد أو اسم المستخدم وكلمة المرور');return}if(busy)return;busy=1;sync('⏳ جارٍ تسجيل الدخول...');try{const m=await resolveEmail(id);await fa.signInWithEmailAndPassword(m,p);sync('✅ تم تسجيل الدخول')}catch(e){er(e)}busy=0}
async function aIn(){return doIn($('#ae').value.trim(),$('#ap').value)}
async function doUp(m,u,p){if(!m.includes('@')||!p){sync('⚠️ لإنشاء حساب اكتب بريدك الإلكتروني وكلمة المرور');return}if(!unOk(u)){er({code:'bad-username'});return}sync('⏳ جارٍ إنشاء الحساب...');
 try{if(await unGet(u))throw{code:'username-taken'};await fa.createUserWithEmailAndPassword(m,p);await claimUn(u);sync('✅ تم إنشاء الحساب باسم المستخدم @'+u)}catch(e){er(e)}}
async function aUp(){return doUp($('#ae').value.trim(),$('#au').value.trim().toLowerCase(),$('#ap').value)}
async function doRs(id){if(!id){sync('⚠️ اكتب بريدك أو اسم المستخدم');return}if(busy)return;busy=1;sync('⏳ جارٍ إرسال الرابط...');
 try{const m=await resolveEmail(id);try{fa.languageCode='ar'}catch(e){dbg(e)}
  try{const ms=await fa.fetchSignInMethodsForEmail(m);if(ms.length&&!ms.includes('password')){sync('ℹ️ هذا البريد مسجّل بواسطة Google فقط: ادخل بزر Google ثم أنشئ كلمة مرور من «إعدادات الحساب».');try{fa.languageCode='ar'}catch(e){dbg(e)}busy=0;return}}catch(e){dbg(e)}
  await fa.sendPasswordResetEmail(m,{url:location.origin+location.pathname,handleCodeInApp:false});
  sync('✅ تم إرسال رسالة إلى \u2066'+m.slice(0,3)+'*'.repeat(Math.max(0,m.length-3))+'\u2069 — لم تصلك؟ افحص البريد المزعج (Spam). وإن كان حسابك عبر Google فادخل بزر Google.')}catch(e){er(e)}try{fa.languageCode='ar'}catch(e){dbg(e)}busy=0}
async function aRs(){return doRs($('#ae').value.trim())}
async function out(){
 clearTimeout(pt);pt=null;if(!(await pushNow(true))){tab='se';draw();sync('تعذّر رفع بياناتك، لم يتم الخروج ⚠️');return}
 const uid=fu.uid;accQuiet=1;
 try{await fa.signOut()}catch(e){dbg(e)}
 accRemove(uid);const o=accNext();$('#sh').innerHTML='';
 if(o){accQuiet=0;await accSwitch(o.uid,true);return}
 fa=firebase.auth();fs=firebase.firestore();fu=null;
 S=EMPTY();clearTimeout(idbT);idb.del('S').catch(()=>{});try{localStorage.removeItem('qmrm');localStorage.removeItem('qmrm_guest');localStorage.removeItem('qmrm_acta')}catch(e){dbg(e)}
 accQuiet=0;draw();awMode='in';awShow()}
/* ---------- منتقي اللون الطيفي ---------- */
const hsv2hex=(h,s,v)=>{const f=n=>{const k=(n+h/60)%6;return v-v*s*Math.max(0,Math.min(k,4-k,1))};return'#'+[f(5),f(3),f(1)].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join('')};
const hex2hsv=hx=>{const n=parseInt(hx.slice(1),16),r=(n>>16)/255,g=((n>>8)&255)/255,b=(n&255)/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;if(d){h=mx==r?((g-b)/d)%6:mx==g?(b-r)/d+2:(r-g)/d+4;h*=60;if(h<0)h+=360}return[h,mx?d/mx:0,mx]};
let cT='app',cH=140,cS=1,cV=.6;
function colSheet(t){cT=t;const hx=x=>(typeof x=='string'&&/^#[0-9a-f]{6}$/i.test(x))?x:'#1565c0',pg=()=>{const n=nbCP();return n.pc!=null?n.pc:nbK().pc};const cur=t=='app'?hx(th().custom||thPal(thCur(),false).pri):(t=='pen'||t=='txt')?hx(nbCol):t=='cov'?hx(nbK().c):hx(pg()||'#ffffff');[cH,cS,cV]=hex2hsv(cur);colRender()}
function colRender(){const hx=hsv2hex(cH,cS,cV);$('#sh').innerHTML=shW(`<b>اختيار اللون</b>${cT=='cov'?`<div id="cvprev" style="max-width:150px;margin:8px auto">${cover({...nbK(),c:hx},'')}</div>`:''}<div class="m" style="margin-top:8px">تدرج اللون</div><input type="range" class="cr" id="cr1" min="0" max="360" value="${Math.round(cH)}" oninput="colSet()" style="background:linear-gradient(90deg,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00)">
 <div class="m">تشبع اللون</div><input type="range" class="cr" id="cr2" min="0" max="100" value="${Math.round(cS*100)}" oninput="colSet()" style="background:linear-gradient(90deg,#fff,${hsv2hex(cH,1,1)})">
 <div class="m">القيمة</div><input type="range" class="cr" id="cr3" min="0" max="100" value="${Math.round(cV*100)}" oninput="colSet()" style="background:linear-gradient(90deg,#000,${hsv2hex(cH,1,1)})">
 <div class="row" style="margin:8px 0"><div id="crp" style="width:56px;height:56px;border-radius:12px;border:2px solid var(--bd);background:${hx}"></div><b id="crh" dir="ltr">${hx}</b></div><button type="button" onclick="colApply()">تعيين</button><button type="button" class="g" onclick="colCancel()">إلغاء</button>`)}
function colSet(){cH=+$('#cr1').value;cS=$('#cr2').value/100;cV=$('#cr3').value/100;const hx=hsv2hex(cH,cS,cV),pure=hsv2hex(cH,1,1);$('#crp').style.background=hx;$('#crh').textContent=hx;$('#cr2').style.background='linear-gradient(90deg,#fff,'+pure+')';$('#cr3').style.background='linear-gradient(90deg,#000,'+pure+')';
 if(cT=='cov'){const e=$('#cvprev .cov');if(e&&e.style&&e.style.setProperty)e.style.setProperty('--cc',hx)}
 else if(cT=='app')applyTheme(hx);
 else if(cT=='pg'){const ta=document.querySelectorAll('#nbpg .rt')[nbPi],w=ta&&ta.parentNode;if(w&&w.style)w.style.backgroundColor=hx}}
function colCancel(){$('#sh').innerHTML='';if(cT=='app')applyTheme();else if(cT=='pg')draw()}
function colApply(){const hx=hsv2hex(cH,cS,cV);$('#sh').innerHTML='';
 if(cT=='app'){th().custom=hx;th().acc=-1;save();applyTheme();draw()}
 else if(cT=='txt'){nbTxtColor(hx)}
 else if(cT=='pen'){nbCol=hx;draw()}
 else if(cT=='pg'){nbCP().pc=hx;nbMark('pc');save();draw()}
 else{nbK().c=hx;save();draw();nbEditCover(nbEd)}}

/* ---------- المظهر واللغة ---------- */
const TH=[
{n:'فجر',h:166,s:1,g:'#f0b44c',ff:"'IBM Plex Sans Arabic'",rd:28,rb:18},
{n:'محيط',h:204,s:1,g:'#e3a94a',ff:"'Almarai'",rd:16,rb:10},
{n:'بنفسج',h:272,s:.95,g:'#d9a441',ff:"'Cairo'",rd:26,rb:14},
{n:'كهرمان',h:27,s:.9,g:'#b8862f',ff:"'Mada'",rd:18,rb:12},
{n:'زمرّد',h:160,s:1,g:'#c9a24a',ff:"'Tajawal'",rd:22,rb:12},
{n:'ورد',h:338,s:1,g:'#d4a24c',ff:"'El Messiri'",rd:24,rb:16},
{n:'قهوة',h:20,s:.5,g:'#c9a24a',ff:"'Noto Naskh Arabic'",rd:14,rb:8},
{n:'غرافيت',h:215,s:.12,g:'#b08d57',ff:"'IBM Plex Sans Arabic'",rd:12,rb:8}];
const hslHex=(h,s,l)=>{h=((h%360)+360)%360;s=Math.max(0,Math.min(100,s))/100;l/=100;const a=s*Math.min(l,1-l),f=n=>{const k=(n+h/30)%12;return l-a*Math.max(-1,Math.min(k-3,9-k,1))};return'#'+[f(0),f(8),f(4)].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join('')};
const hexHsl=x=>{const n=parseInt(x.slice(1),16),r=(n>>16)/255,g=((n>>8)&255)/255,b=(n&255)/255,M=Math.max(r,g,b),m=Math.min(r,g,b),d=M-m;let h=0;if(d){h=M==r?((g-b)/d)%6:M==g?(b-r)/d+2:(r-g)/d+4;h=(h*60+360)%360}const l=(M+m)/2;return[h,d?d/(1-Math.abs(2*l-1))*100:0,l*100]};
const th=()=>S.theme||(S.theme={mode:'auto',acc:0});
function thCur(pv){const t=th(),c=pv||((t.acc<0&&t.custom)?t.custom:null);if(c){const[h,s,l]=hexHsl(c);return{n:'مخصص',h,s:Math.max(.03,Math.min(1.1,s/65)),c,S:s,L:l,g:'#c9a24a',ff:TH[0].ff,rd:20,rb:12}}return TH[t.acc||0]||TH[0]}
function thPal(T,d){const P=thPal0(T,d);if(T.c){const h=T.h,S=T.S,L=T.L;if(d){P.pri=hslHex(h,S,Math.max(L,62));P.h1=hslHex(h,S*.85,Math.min(Math.max(L*.6,12),30));P.h2=hslHex(h+10,S*.85,Math.min(Math.max(L*.6,12),30)+8)}else{P.pri=T.c;P.h1=T.c;P.h2=hslHex(h+10,S,Math.min(L+10,92));P.on=L>68?'#1a1a1a':'#fff'}}return P}
function thPal0(T,d){const h=T.h,s=T.s;return d?{bg:hslHex(h,40*s+4,7.5),card:hslHex(h,32*s+4,12.5),tx:hslHex(h,30*s+6,92),mut:hslHex(h,16*s+4,66),bd:hslHex(h,30*s+4,21),pri:hslHex(h,62*s+10,68),h1:hslHex(h,55*s+6,17),h2:hslHex(h+10,48*s+6,25),on:hslHex(h,50*s,9),bad:'#ef7b7b'}:{bg:hslHex(h,26*s+3,96.5),card:'#ffffff',tx:hslHex(h,40*s+6,13),mut:hslHex(h,14*s+4,40),bd:hslHex(h,22*s+4,90),pri:hslHex(h,58*s+6,30),h1:hslHex(h,60*s+6,24),h2:hslHex(h+10,52*s+6,36),on:'#fff',bad:'#c62828'}}
const thPat="url(\"data:image/svg+xml,"+encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><path d='M40 6 74 40 40 74 6 40Z' fill='none' stroke='white' stroke-width='2'/></svg>")+"\")";
function applyTheme(pv){const t=th(),r=document.documentElement,dm=typeof matchMedia!='undefined'&&matchMedia('(prefers-color-scheme: dark)').matches,dark=t.mode=='dark'||(t.mode=='auto'&&dm);
 if(t.mode=='auto')r.removeAttribute('data-theme');else r.setAttribute('data-theme',t.mode);
 const T=thCur(pv),P=thPal(T,dark),v={bg:P.bg,card:P.card,tx:P.tx,mut:P.mut,bd:P.bd,pri:P.pri,on:P.on,bad:P.bad,h1:P.h1,h2:P.h2,a3:hslHex(T.h,45*T.s+8,dark?35:60),a4:dark?P.bg:hslHex(40,60,94),gold:T.g,ff:T.ff+",system-ui,'Segoe UI',Tahoma,sans-serif",rd:T.rd+'px',rb:T.rb+'px',hp:thPat};
 for(const k in v)r.style.setProperty('--'+k,v[k]);r.style.colorScheme=dark?'dark':'light';
 const m=document.querySelector('meta[name=theme-color]');if(m)m.content=P.h1}
if(typeof matchMedia!='undefined')try{matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(th().mode=='auto')applyTheme()})}catch(e){dbg(e)}
function setTheme(k,v){th()[k]=v;save();applyTheme();draw()}
function appearance(){return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">اللغة والمظهر</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>${look()}`}
function setLang(l){S.lang=l;try{localStorage.setItem('qmrm_lang',l)}catch(e){dbg(e)}try{sessionStorage.setItem('qmrm_lang',l)}catch(e){dbg(e)}save();try{location.reload()}catch(e){dbg(e)}}
function thCard(T,i,on){const dk=th().mode=='dark'||(th().mode=='auto'&&matchMedia('(prefers-color-scheme: dark)').matches),P=thPal(T,dk);return `<div class="thc ${on?'on':''}" onclick="${i<0?"setTheme('acc',-1)":`setTheme('acc',${i})`}" style="--pb:${P.bg};--pd:${P.bd};--p1:${P.h1};--p2:${P.h2};--pc:${P.card};--pg:${T.g};--pp:${P.pri}"><div class="thp"><i class="thh"></i><i class="thl"></i><i class="thl s"></i><i class="tb2"></i></div><b style="font-family:${T.ff}">${T.n}</b></div>`}
function look(){const t=th(),L=S.lang=='en'?'en':'ar',seg=(a,cur,f)=>`<div class="seg">${a.map(([k,x])=>`<span class="${cur==k?'on':''}" onclick="${f}('${k}')">${x}</span>`).join('')}</div>`;
 return `<div class="c"><b>🎨 المظهر</b><div class="m" style="margin-top:6px">الوضع</div>${seg([['light','☀️ نهاري'],['dark','🌙 ليلي'],['auto','🔄 تلقائي']],t.mode,"setThM")}<div class="m" style="margin-top:14px">ثيم التطبيق (يغيّر الألوان والخط والشكل بالكامل)</div><div class="thg">${TH.map((T,i)=>thCard(T,i,(t.acc||0)==i)).join('')}${t.custom?thCard(thCur(t.custom),-1,t.acc<0):''}<div class="thc" onclick="colSheet('app')"><div class="thp" style="display:flex;align-items:center;justify-content:center"><span class="rainbow" style="width:44px;height:44px"></span></div><b>لون مخصص</b></div></div></div>
 <div class="c"><b>🌐 اللغة / Language</b>${seg([['ar','العربية'],['en','English']],L,'setLang')}</div>`}
const setThM=k=>setTheme('mode',k);

const ENR=[[/(\d+) سنة/g,"$1 years"],[/قبل (\d+) يوم/g,"$1 days ago"],[/(\d+) يوماً/g,"$1 days"],[/(\d+) يوم/g,"$1 days"],[/(\d+) كلمة/g,"$1 words"],[/(\d+) جلسة/g,"$1 sessions"],[/(\d+) جلسات/g,"$1 sessions"],[/(\d+) صفحات/g,"$1 pages"]];
const ENX={"سور": "Surahs", "أجزاء": "Juz", "صفحات": "Pages", "ج": "J", "من": "from", "إلى": "to", "أو": "or", "المهام": "Tasks", "تايمر": "Timer", "اختيار": "Choose", "بدأت": "Started", "ابدأ": "Start", "المستغرق": "Elapsed", "إيقاف": "Stop", "تشغيل": "Run", "إعادة": "Reset", "اكتب": "Type", "يعمل": "Running", "المؤقت": "Timer", "الاختبار": "Quiz", "الآيات": "Verses", "النتيجة": "Result", "انتهت": "Finished", "غفوة": "Snooze", "بدأ": "Started", "صح": "Correct", "غلط": "Wrong", "المدة": "Duration", "الإحصائيات": "Statistics", "مهمة": "Task", "حذف": "Delete", "يوم": "day", "أيام": "days", "آخر": "Last", "الجلسات": "Sessions", "المظهر": "Appearance", "إنهاء": "Finish", "استعادة": "Restore", "أرشفة": "Archive", "كلمة المرور": "Password", "الحذف": "Delete", "الدفاتر": "Notebooks", "سادة": "Plain", "جديدة": "New", "الخط": "Font", "خط": "Font", "سنة": "year", "كلمة": "word", "جلسة": "session", "جلسات": "sessions", "ساعة": "h", "بعد": "after", "تذكير": "Reminder", "الحالة": "Status", "الأصلي": "Original", "جامع": "Mosque", "بيت": "Home", "تغيير": "Change", "الشهر": "Month", "المجموع": "Total", "محفوظ": "Saved", "رابط": "Link", "يسار": "Left", "يمين": "Right", "أعلى": "Top", "أسفل": "Bottom", "تأكيد": "confirm", "مجلّد": "Hardcover", "حلزوني": "Spiral", "مسطّر": "Ruled", "مربعات": "Grid", "منقّط": "Dotted", "مدرسي": "School", "مقفل": "Locked", "مؤرشفة": "Archived", "أُنهيت": "Finished", "الملصقات": "Stickers", "إعدادات": "Settings", "القائمة": "Menu", "الاستمرارية": "Streak", "اختر": "Choose", "نعم": "Yes", "لا": "No", "إلغاء": "Cancel", "حفظ": "Save", "تعيين": "Set", "إضافة": "Add", "تم": "Done", "كما هو": "Keep as is", "اختصاره": "Shorten", "جزء": "Juz", "التقارير": "Reports", "تقرير": "Report", "التاريخ": "Date", "الوقت": "Time", "المهمة": "Task", "التقييم": "Rating", "سمع": "Heard", "أنهى": "Finished", "مدى": "Mada", "دفتري": "My notebook", "ملفات": "files", "فتح": "Open", "الكل": "All", "عادي": "Normal", "ضيف": "Guest", "ذكر": "Male", "أنثى": "Female", "دخول": "Sign in", "رجوع": "Back", "صفحة": "Page", "سورة": "Surah", "أصبت": "I was right", "ليلي": "Dark", "أخضر": "green", "أصفر": "yellow", "أحمر": "red", "بلكس": "IBM Plex", "الخط:": "Font:"},SMAP={"الفاتحة": "Al-Fatihah", "البقرة": "Al-Baqarah", "آل عمران": "Aal-Imran", "النساء": "An-Nisa", "المائدة": "Al-Ma'idah", "الأنعام": "Al-An'am", "الأعراف": "Al-A'raf", "الأنفال": "Al-Anfal", "التوبة": "At-Tawbah", "يونس": "Yunus", "هود": "Hud", "يوسف": "Yusuf", "الرعد": "Ar-Ra'd", "إبراهيم": "Ibrahim", "الحجر": "Al-Hijr", "النحل": "An-Nahl", "الإسراء": "Al-Isra", "الكهف": "Al-Kahf", "مريم": "Maryam", "طه": "Ta-Ha", "الأنبياء": "Al-Anbiya", "الحج": "Al-Hajj", "المؤمنون": "Al-Mu'minun", "النور": "An-Nur", "الفرقان": "Al-Furqan", "الشعراء": "Ash-Shu'ara", "النمل": "An-Naml", "القصص": "Al-Qasas", "العنكبوت": "Al-Ankabut", "الروم": "Ar-Rum", "لقمان": "Luqman", "السجدة": "As-Sajdah", "الأحزاب": "Al-Ahzab", "سبأ": "Saba", "فاطر": "Fatir", "يس": "Ya-Sin", "الصافات": "As-Saffat", "الزمر": "Az-Zumar", "غافر": "Ghafir", "فصلت": "Fussilat", "الشورى": "Ash-Shura", "الزخرف": "Az-Zukhruf", "الدخان": "Ad-Dukhan", "الجاثية": "Al-Jathiyah", "الأحقاف": "Al-Ahqaf", "محمد": "Muhammad", "الفتح": "Al-Fath", "الحجرات": "Al-Hujurat", "الذاريات": "Adh-Dhariyat", "الطور": "At-Tur", "النجم": "An-Najm", "القمر": "Al-Qamar", "الرحمن": "Ar-Rahman", "الواقعة": "Al-Waqi'ah", "الحديد": "Al-Hadid", "المجادلة": "Al-Mujadila", "الحشر": "Al-Hashr", "الممتحنة": "Al-Mumtahanah", "الصف": "As-Saff", "الجمعة": "Al-Jumu'ah", "المنافقون": "Al-Munafiqun", "التغابن": "At-Taghabun", "الطلاق": "At-Talaq", "التحريم": "At-Tahrim", "الملك": "Al-Mulk", "القلم": "Al-Qalam", "الحاقة": "Al-Haqqah", "المعارج": "Al-Ma'arij", "نوح": "Nuh", "الجن": "Al-Jinn", "المزمل": "Al-Muzzammil", "المدثر": "Al-Muddaththir", "القيامة": "Al-Qiyamah", "الإنسان": "Al-Insan", "المرسلات": "Al-Mursalat", "النبأ": "An-Naba", "النازعات": "An-Nazi'at", "عبس": "Abasa", "التكوير": "At-Takwir", "الانفطار": "Al-Infitar", "المطففين": "Al-Mutaffifin", "الانشقاق": "Al-Inshiqaq", "البروج": "Al-Buruj", "الطارق": "At-Tariq", "الأعلى": "Al-A'la", "الغاشية": "Al-Ghashiyah", "الفجر": "Al-Fajr", "البلد": "Al-Balad", "الشمس": "Ash-Shams", "الليل": "Al-Layl", "الضحى": "Ad-Duha", "الشرح": "Ash-Sharh", "التين": "At-Tin", "العلق": "Al-Alaq", "القدر": "Al-Qadr", "البينة": "Al-Bayyinah", "الزلزلة": "Az-Zalzalah", "العاديات": "Al-Adiyat", "القارعة": "Al-Qari'ah", "التكاثر": "At-Takathur", "العصر": "Al-Asr", "الهمزة": "Al-Humazah", "الفيل": "Al-Fil", "قريش": "Quraysh", "الماعون": "Al-Ma'un", "الكوثر": "Al-Kawthar", "الكافرون": "Al-Kafirun", "النصر": "An-Nasr", "المسد": "Al-Masad", "الإخلاص": "Al-Ikhlas", "الفلق": "Al-Falaq", "الناس": "An-Nas", "آل_عمران": "Aal-Imran"},SMX={"ص": "Sad", "ق": "Qaf"},SMRE=new RegExp('(?<![\\u0600-\\u06FF_])('+Object.keys(SMAP).sort((a,b)=>b.length-a.length).join('|')+')(?![\\u0600-\\u06FF_])','g');
ENR.push([/(\d+) جزء من (\d+)/g,'$1 of $2 units'],[/سمع (\d+) من (\d+) أجزاء/g,'Heard $1 of $2 units'],[/(\d+) من (\d+) أجزاء/g,'$1 of $2 units'],[/(\d+) جزء/g,'$1 unit(s)'],[/بعد (\d+)/g,'in $1'],[/جامع (\d+)/g,'Mosque $1'],[/بيت (\d+)/g,'Home $1'],[/^تم \((\d+)\)/g,'Done ($1)'],[/(\d+)\. ص(?![\u0600-\u06FF])/g,'$1. Sad'],[/(\d+)\. ق(?![\u0600-\u06FF])/g,'$1. Qaf'],[/(^|[^\u0600-\u06FF])ج(\d+)/g,'$1Juz $2'],[/(^|[^\u0600-\u06FF])ص(\d+)/g,'$1p.$2'],[/صفحة (\d+) \/ (\d+)/g,'Page $1 / $2'],[/تم التطبيق على (\d+) صفحة/g,'Applied to $1 page(s)'],[/صفحة (\d+)/g,'Page $1'],[/(\d+) صفحة/g,'$1 pages']);
Object.assign(EN,{"ثيم التطبيق (يغيّر الألوان والخط والشكل بالكامل)":"App theme (changes colors, font and shape)","لون مخصص":"Custom color","نيلي ملكي":"Royal indigo","محيط":"Ocean","بنفسج":"Violet","كهرمان":"Amber","زمرّد":"Emerald","ورد":"Rose","قهوة":"Coffee","غرافيت":"Graphite","اضغط القلم بجانب اسم الدفتر لتعديل شكله (الغلاف والألوان والصفحة والقفل).":"Tap the pencil next to the notebook name to edit it (cover, colors, page, lock)."});
Object.assign(EN,{"ضع ✓ أو ✗ على المهمة فتنتقل إلى الأرشيف بعد 5 ثوانٍ (اضغط العلامة نفسها لإلغاء)، ومنه تستطيع استرجاعها.":"Mark a task ✓ or ✗ and it moves to the archive after 5 seconds (tap the same mark to cancel); you can restore it from there."});
Object.assign(ENX,{'الصلاة':'Prayer'});Object.assign(EN,{'الحفظ والمراجعة':'Memorization & review','جداول المراجعة والحفظ':'Review and memorization schedules'});
Object.assign(ENX,{'الدفتر':'Notebook'});Object.assign(EN,{"💬 المحادثة":"💬 Chat","المحادثة":"Chat","اكتب رسالة…":"Type a message…","لا توجد رسائل بعد، ابدأ المحادثة":"No messages yet, start the chat","جارٍ التحميل…":"Loading…","إرسال":"Send"});Object.assign(EN,{'تقدّمك وسجل جلساتك':'Your progress and session history'});
Object.assign(EN,{'مزامنة البيانات':'Sync data','اختر طريقة المزامنة مع حسابك.':'Choose how to sync with your account.','تلقائية':'Automatic','يدوية':'Manual','تُرفع تغييراتك إلى حسابك تلقائياً بعد كل تعديل.':'Your changes are uploaded to your account automatically after every edit.','لا تُرفع التغييرات إلا عند ضغط «مزامنة الآن».':'Changes are only uploaded when you tap “Sync now”.','مزامنة الآن':'Sync now','هل تريد الحذف؟':'Do you want to delete this?','اسحب الصورة داخل الغلاف لتحريكها (يمين/يسار/فوق/تحت)، وكبّر أو صغّر:':'Drag the image inside the cover to reposition it, and zoom in or out:'});
Object.assign(EN,{'هل تريد الاسترجاع؟':'Do you want to restore it?','↕ ترتيب':'↕ Reorder','↺ البداية':'↺ Reset start','الأهداف':'Goals','هدف جديد':'New goal','+ هدف جديد':'+ New goal','تعديل الهدف':'Edit goal','تاريخ الاستحقاق':'Due date','تاريخ البدء':'Start date','تذكير تتبع الصلاة':'Prayer tracking reminder','تذكير بتتبع الصلاة':'Prayer tracking reminder','يظهر في صفحة «اليوم» إذا بقيت صلوات بلا تسجيل':'Shown on the Today page when prayers are not recorded','يبدأ التذكير من الساعة':'Reminder starts at','لم تسجّل اليوم':'Not recorded today','تاريخ الاستحقاق قبل تاريخ البدء':'Due date is before start date','الوصف (إختياري)':'Description (optional)','إختر النوع':'Choose type','شريط التقدم تلقائي':'Auto progress bar','ذكّرني':'Remind me','تقدم الإنجازات':'Progress','حذف الهدف':'Delete goal','هل تريد حذف الهدف؟':'Delete this goal?','تذكير بالأهداف':'Goal reminders','اكتب عنوان الهدف':'Enter a goal title','أهداف الحياة':'Life goals','المدى الطويل':'Long term','المدى القصير':'Short term','سنوي':'Yearly','ربع سنوي':'Quarterly','شهري':'Monthly','أسبوعي':'Weekly','يومي':'Daily','أخرى':'Other','تم إرسال رسالة إلى':'Message sent to','الحسابات':'Accounts','إضافة حساب':'Add account','انتهت جلسة هذا الحساب، أضفه من جديد':'This account session expired, add it again','تم التبديل إلى':'Switched to','هذا الحساب مضاف مسبقاً':'This account is already added'});
const ENK=Object.keys(EN).sort((a,b)=>b.length-a.length);
function trs(t){const tt=t.trim();if(tt&&ENX[tt]!==undefined)return t.replace(tt,ENX[tt]);if(tt&&SMX[tt]!==undefined)return t.replace(tt,SMX[tt]);if(tt&&EN[tt]!==undefined)return t.replace(tt,EN[tt]);for(const[a,b]of ENR)t=t.replace(a,b);for(const k of ENK)if(t.includes(k))t=t.split(k).join(EN[k]);if(/[\u0600-\u06FF]/.test(t))t=t.replace(SMRE,m=>SMAP[m]||m);return t.replace(/؟/g,'?')}
const trSkip=n=>{for(;n;n=n.parentNode){if(/^(TEXTAREA|SCRIPT|STYLE)$/.test(n.nodeName||''))return true;if(n.getAttribute&&n.getAttribute('data-notr')!==null)return true;if(n.isContentEditable||(n.getAttribute&&n.getAttribute('contenteditable')==='true'))return true}return false};
const ENO={'حفظ':'Memorize','مراجعة':'Review'};
function trNode(n){if(n.nodeType==3){const pn=n.parentNode;if(!trSkip(pn)){const tt=n.nodeValue.trim();if(pn&&pn.nodeName==='OPTION'&&ENO[tt])n.nodeValue=n.nodeValue.replace(tt,ENO[tt]);else n.nodeValue=trs(n.nodeValue)}return}
 if(n.nodeType!=1)return;(n.nodeName==='OPTION'?[n]:[]).concat([...n.querySelectorAll('option')]).forEach(o=>{if(!o.hasAttribute('value'))o.setAttribute('value',o.textContent)});const w=document.createTreeWalker(n,4,{acceptNode:t=>trSkip(t.parentNode)?2:1});let x;while(x=w.nextNode()){const pn=x.parentNode,tt=x.nodeValue.trim();x.nodeValue=(pn&&pn.nodeName==='OPTION'&&ENO[tt])?x.nodeValue.replace(tt,ENO[tt]):trs(x.nodeValue)}
 (n.matches&&n.matches('[placeholder]')?[n]:[]).concat([...n.querySelectorAll('[placeholder]')]).forEach(e=>e.placeholder=trs(e.placeholder));[...n.querySelectorAll('[data-ph]')].forEach(e=>e.setAttribute('data-ph',trs(e.getAttribute('data-ph'))))}
const IC={target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',tag:'<path d="M3 3h8l10 10-8 8L3 11z"/><circle cx="7.5" cy="7.5" r="1"/>',book:'<path d="M2 4h6a4 4 0 0 1 4 4v12a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v12a3 3 0 0 1 3-3h7z"/>',calendar:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',alarm:'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M5 3 2 6M22 6l-3-3"/>',chart:'<path d="M12 20V10M18 20V4M6 20v-4"/>',folder:'<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8M10 12h4"/>',notebook:'<path d="M4 4a2 2 0 0 1 2-2h12v20H6a2 2 0 0 1-2-2z"/><path d="M8 2v20M12 7h4M12 11h4"/>',library:'<path d="M4 3v18M9 3v18M14 5l5 15M3 21h18"/>',sliders:'<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',lock:'<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',unlock:'<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7-2.6"/>',trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 10v6M14 10v6"/>',box:'<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',check:'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',timer:'<circle cx="12" cy="14" r="8"/><path d="M12 10v4l2.5 1.5M9 2h6"/>',pause:'<path d="M8 5v14M16 5v14" stroke-width="3"/>',play:'<path d="M7 4v16l13-8z" fill="currentColor"/>',reset:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',volume:'<path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10 21a2 2 0 0 0 4 0"/>',repeat:'<path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/>',alert:'<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',flame:'<path d="M12 22a7 7 0 0 0 7-7c0-4-3-6-4-10-2 2-3 4-3 6-2-1-3-3-3-5-3 3-4 6-4 9a7 7 0 0 0 7 7z"/>',trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3"/>',cloud:'<path d="M17.5 19a4.5 4.5 0 0 0 0-9 6 6 0 0 0-11.7 1.5A4 4 0 0 0 6.5 19z"/>',key:'<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M16 7l3 3"/>',palette:'<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 2-2 0-2 1-3 3-3h2a3 3 0 0 0 3-3c0-5-4-10-10-10z"/><circle cx="7.5" cy="11" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16.5" cy="11" r="1"/>',globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',moon:'<path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10z"/>',refresh:'<path d="M21 12a9 9 0 0 1-15.5 6.2M3 12a9 9 0 0 1 15.5-6.2"/><path d="M18 2v4h-4M6 22v-4h4"/>',plus:'<path d="M12 5v14M5 12h14"/>',lines:'<path d="M4 7h16M4 12h16M4 17h16"/>',grid:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>',dots:'<circle cx="6" cy="6" r="1.2"/><circle cx="12" cy="6" r="1.2"/><circle cx="18" cy="6" r="1.2"/><circle cx="6" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="18" cy="12" r="1.2"/><circle cx="6" cy="18" r="1.2"/><circle cx="12" cy="18" r="1.2"/><circle cx="18" cy="18" r="1.2"/>',file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',grad:'<path d="M22 9 12 4 2 9l10 5z"/><path d="M6 11v5c3 2 9 2 12 0v-5"/>',ring:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',square:'<rect x="4" y="5" width="16" height="14" rx="2"/>',leaf:'<path d="M11 20A7 7 0 0 1 4 13c0-6 6-9 16-9 0 10-3 16-9 16zM4 21c2-6 5-9 9-11"/>',chev:'<path d="m15 6-6 6 6 6"/>',download:'<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',hl:'<path d="m9 11-6 6v3h9l3-3"/><path d="m22 12-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4"/>',rl:'<path d="M3 17 17 3l4 4L7 21z"/><path d="M7 13l2 2M10 10l2 2M13 7l2 2"/>',er:'<path d="M20 20H9L3.5 14.5a2 2 0 0 1 0-2.8L12 3.2a2 2 0 0 1 2.8 0l5.5 5.5a2 2 0 0 1 0 2.8L12 20"/><path d="M8 8l8 8"/>',alS:'<path d="M4 6h16M4 12h10M4 18h14"/>',alC:'<path d="M4 6h16M7 12h10M5 18h14"/>',alE:'<path d="M4 6h16M10 12h10M6 18h14"/>',ol:'<path d="M10 6h11M10 12h11M10 18h11M4 6h1v4M4 10h2M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/>',cs:'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m8 12 3 3 5-6"/>',bl:'<circle cx="5" cy="6" r="1.2"/><circle cx="5" cy="12" r="1.2"/><circle cx="5" cy="18" r="1.2"/><path d="M10 6h11M10 12h11M10 18h11"/>',edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',hourglass:'<path d="M6 2h12M6 22h12M7 2v4l5 6-5 6v4M17 2v4l-5 6 5 6v4"/>',users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6.5 6.5 0 0 1 3.5 6"/>',idcard:'<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="11" r="2"/><path d="M5 16a3 3 0 0 1 6 0M14 10h5M14 14h4"/>',copy:'<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',camera:'<path d="M3 8a2 2 0 0 1 2-2h2l2-3h6l2 3h2a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="4"/>',userx:'<circle cx="9" cy="8" r="4"/><path d="M1.5 21a7.5 7.5 0 0 1 15 0M17 8l5 5M22 8l-5 5"/>',logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',g:'<circle cx="12" cy="12" r="7" fill="#43a047" stroke="none"/>',y:'<circle cx="12" cy="12" r="7" fill="#f9a825" stroke="none"/>',r:'<circle cx="12" cy="12" r="7" fill="#e53935" stroke="none"/>'};
const EM={'🎯':'target','🏷':'tag','📖':'book','📅':'calendar','⏰':'alarm','📊':'chart','🗂':'folder','📓':'notebook','📒':'notebook','📚':'library','⚙':'sliders','👤':'user','👨':'user','👩':'user','🔒':'lock','🔓':'unlock','🗑':'trash','📦':'box','✅':'check','⏱':'timer','⏳':'timer','⏸':'pause','▶':'play','↺':'reset','↩':'reset','🔊':'volume','🔔':'bell','🔁':'repeat','⚠':'alert','🔥':'flame','🏆':'trophy','☁':'cloud','🔐':'key','🎨':'palette','🌐':'globe','☀':'sun','🌙':'moon','🔄':'refresh','➕':'plus','📏':'lines','▦':'grid','⠿':'dots','📄':'file','🎓':'grad','📘':'book','🌀':'ring','▭':'square','🌿':'leaf','🟢':'g','🟡':'y','🔴':'r'};
Object.assign(IC,{mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/>',star:'<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',clip:'<path d="m21 11-9 9a5 5 0 0 1-7-7l9-9a3.5 3.5 0 0 1 5 5l-9 9a2 2 0 0 1-3-3l8-8"/>',stop:'<rect x="6" y="6" width="12" height="12" rx="2"/>',mapfold:'<path d="M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3z"/><path d="M9 3v15M15 6v15"/>',clipcheck:'<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',sparkle:'<path d="m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15v4M17 17h4"/>',medal:'<path d="M7.2 15 2.7 7.1a2 2 0 0 1 .1-2.2L4.4 2.8A2 2 0 0 1 6 2h12a2 2 0 0 1 1.6.8l1.6 2.1a2 2 0 0 1 .1 2.2L16.8 15"/><path d="M11 12 5.1 2.2M13 12l5.9-9.8M8 7h8"/><circle cx="12" cy="17" r="5"/>',compass:'<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',pin:'<path d="M12 17v5M9 10.8a2 2 0 0 1-1.1 1.8l-1.8.9A2 2 0 0 0 5 15.2V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.8a2 2 0 0 0-1.1-1.8l-1.8-.9A2 2 0 0 1 15 10.8V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/>',arrowdown:'<path d="M12 5v14M6 13l6 6 6-6"/>',phone:'<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',scissors:'<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.1 15.9M14.5 14.5 20 20M8.1 8.1 12 12"/>',xmark:'<circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/>',printer:'<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>'});
Object.assign(EM,{'🎙':'mic','⭐':'star','⏹':'stop','📎':'clip','📷':'camera','🏫':'grad','🎉':'sparkle','✨':'sparkle','🗓':'calendar','🌴':'sun','🏅':'medal','🧭':'compass','📌':'pin','⬇':'arrowdown','🗄':'box','📱':'phone','✂':'scissors','❌':'xmark','🖨':'printer','📝':'edit','👥':'users'});
const EMR=new RegExp('('+Object.keys(EM).join('|')+')\\uFE0F?','g'),EMT=new RegExp(EMR.source);
const svg=k=>`<span class="ic" data-k="${k}"><svg viewBox="0 0 24 24">${IC[k]}</svg></span>`;
function icons(n){const skip=/^(TEXTAREA|SCRIPT|STYLE|OPTION|TITLE)$/,L=[];
 if(n.nodeType==3){if(n.parentNode&&!skip.test(n.parentNode.nodeName)&&EMT.test(n.nodeValue))L.push(n)}
 else if(n.nodeType==1){const w=document.createTreeWalker(n,4,{acceptNode:t=>skip.test(t.parentNode.nodeName)||!EMT.test(t.nodeValue)?2:1});let x;while(x=w.nextNode())L.push(x)}
 L.forEach(t=>{const f=document.createDocumentFragment();t.nodeValue.split(EMR).forEach((p,i)=>{if(i%2){const tp=document.createElement('template');tp.innerHTML=svg(EM[p]);f.appendChild(tp.content)}else if(p)f.appendChild(document.createTextNode(p))});t.parentNode.replaceChild(f,t)})}
const KL={plus:['إضافة','Add'],trash:['حذف','Delete'],edit:['تعديل','Edit'],check:['تم','Done'],play:['تشغيل','Play'],pause:['إيقاف مؤقت','Pause'],reset:['إعادة','Reset'],refresh:['تحديث','Refresh'],bell:['تنبيه','Alert'],volume:['الصوت','Sound'],chev:['التالي','Next'],download:['تحميل','Download'],copy:['نسخ','Copy'],camera:['كاميرا','Camera'],cloud:['المزامنة','Sync'],logout:['تسجيل الخروج','Sign out'],lock:['قفل','Lock'],unlock:['فتح القفل','Unlock'],sliders:['الإعدادات','Settings'],dots:['المزيد','More'],timer:['المؤقت','Timer'],alarm:['المنبّه','Alarm'],user:['الحساب','Account'],userx:['إزالة المستخدم','Remove user']};
const KT={'✕':['إغلاق','Close'],'×':['إغلاق','Close'],'+':['زيادة','Increase'],'−':['نقصان','Decrease'],'-':['نقصان','Decrease'],'›':['التالي','Next'],'‹':['السابق','Previous'],'☰':['القائمة','Menu']};
function harden(n){const A=S.lang=='en'?1:0,bs=new Set();
 if(n.nodeType==1){const c=n.closest&&n.closest('button');if(c)bs.add(c);if(n.querySelectorAll)n.querySelectorAll('button').forEach(b=>bs.add(b));
  (n.tagName=='INPUT'?[n]:(n.querySelectorAll?[...n.querySelectorAll('input')]:[])).forEach(i=>{if(!i.hasAttribute('maxlength')&&/^(text|search|tel|password|)$/.test(i.getAttribute('type')||''))i.setAttribute('maxlength',120)})}
 else if(n.parentElement){const c=n.parentElement.closest('button');if(c)bs.add(c)}
 bs.forEach(b=>{if(b.hasAttribute('aria-label'))return;const t=b.textContent.trim();if(t){const k=KT[t];if(k)b.setAttribute('aria-label',k[A]);return}const ic=b.querySelector('.ic[data-k]'),k=ic&&KL[ic.dataset.k];if(k)b.setAttribute('aria-label',k[A])})}
function initLang(){const en=S.lang=='en',r=document.documentElement;r.lang=en?'en':'ar';r.dir=en?'ltr':'rtl';
 const f=n=>{if(en)trNode(n);icons(n);try{harden(n)}catch(e){dbg(e)}};new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(f))).observe(document.body,{childList:true,subtree:true});f(document.body)}
/* ---------- الإشعارات ---------- */
function remBody(){const R=(S.rem=S.rem||[]).slice().sort((a,b)=>a.at.localeCompare(b.at)),now=Date.now(),d=new Date(now+3600e3);
 const rel=ms=>{const m=Math.round(ms/6e4);return m<60?m+' دقيقة':m<1440?Math.round(m/60)+' ساعة':Math.round(m/1440)+' يوم'};
 return `<div class="c"><b>تذكير جديد</b><input id="rt" placeholder="اكتب المهمة التي تريد التنبيه عليها" autocomplete="off"><div class="row" style="flex-wrap:nowrap"><input id="rd" type="date" value="${ymd(d)}" style="flex:1;min-width:0"><input id="rh" type="time" value="${hm(d)}" style="flex:1;min-width:0"></div><button type="button" onclick="remAdd()" style="width:100%">إضافة التذكير</button>
 ${('Notification' in window&&Notification.permission=='default')?'<button type="button" class="g" onclick="Notification.requestPermission().then(draw)" style="width:100%;margin-top:6px">🔔 السماح بالإشعارات</button>':''}<div class="m" style="margin-top:6px">يمكنك إضافة أي عدد من التذكيرات. يعمل التنبيه والصفحة مفتوحة، وإن فتحتها بعد الموعد يظهر لك التنبيه فوراً.</div></div>
 <div class="row" style="padding:0 16px"><span class="m">✓ ${R.filter(r=>r.s==1).length} • ✗ ${R.filter(r=>r.s==2).length} • ${R.filter(r=>!r.s).length} بلا تقييم</span></div>
 ${R.map(r=>{const t=new Date(r.at),ms=t-now;return `<div class="c"><div class="row" style="flex-wrap:nowrap;gap:10px;align-items:flex-start">${mk2(r.s||0,`remMk(${r.id},1)`,`remMk(${r.id},2)`)}<div style="flex:1;min-width:0"><b style="${r.s==1?'text-decoration:line-through;color:var(--mut)':r.s==2?'color:var(--bad)':''}">${esc(r.t)}</b><div class="m">${D[t.getDay()]} • ${ymd(t)} • ${hm(t)}</div><div class="m" style="color:${r.done?'var(--mut)':'var(--pri)'}">${r.done?'✅ تم التنبيه':'⏰ بعد '+rel(ms)}</div></div><button type="button" class="g" style="padding:4px 10px" onclick="remDel(${r.id})">🗑</button></div></div>`}).join('')||'<div class="c m">لا تذكيرات بعد</div>'}`}
function remAdd(){const t=$('#rt').value.trim(),d=$('#rd').value,h=$('#rh').value;if(!t||!d||!h)return;S.rem=S.rem||[];S.rem.push({id:S.id++,t,at:new Date(d+'T'+h).toISOString(),done:false});save();draw();try{if('Notification' in window&&Notification.permission=='default')Notification.requestPermission()}catch(e){dbg(e)}}
function remMk(id,v){const r=S.rem.find(x=>x.id==id);chg(r.s,()=>{r.s=r.s==v?0:v;save();draw()})}
function remDel(id){S.rem=(S.rem||[]).filter(x=>x.id!=id);save();draw()}
function remTick(){const now=Date.now();let ch=0;(S.rem||[]).forEach(r=>{if(!r.done&&Date.parse(r.at)<=now){r.done=true;ch=1;const late=now-Date.parse(r.at)>3e5;beep();notif('تذكير: '+r.t)
 $('#ban').innerHTML+=`<div class="c" style="border-color:var(--pri)"><b>🔔 تذكير</b><div style="margin:6px 0">${esc(r.t)}</div>${late?`<div class="m">كان موعده ${hm(new Date(r.at))}</div>`:''}<button type="button" onclick="ringStop();this.parentNode.remove()">تم</button></div>`}});if(ch){save();if(tab=='re')draw()}}
setInterval(remTick,15000);
let reTab='r';
function reminders(){return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">الإشعارات</b><button type="button" class="g" onclick="go('home')">رجوع</button></div><div style="padding:0 12px"><span class="chip ${reTab=='r'?'on':''}" onclick="reTab='r';draw()">التذكيرات</span><span class="chip ${reTab=='a'?'on':''}" onclick="reTab='a';draw()">المنبّهات</span></div>`+(reTab=='a'?alarms():remBody())}
/* ---------- قائمة المهمات (تبويب مستقل) + المهام الخاصة ---------- */
const tdL=()=>S.td=S.td||[];
const tdItem=(x,mk,del)=>`<div class="row" style="flex-wrap:nowrap;padding:8px 0;border-top:1px solid var(--bd)">${mk2(x.s||0,`${mk}(${x.id},1)`,`${mk}(${x.id},2)`)}${tdBadge(mk,x.id)}<span style="flex:1;${x.s==1?'text-decoration:line-through;color:var(--mut)':x.s==2?'color:var(--bad)':''}">${esc(x.t)}</span><button type="button" class="g" style="padding:2px 9px" onclick="ask('هل تريد حذف المهمة؟',()=>${del}(${x.id}),'نعم، احذف')">×</button></div>`;
let tdOrd=false;
const tdItemO=(x,i,n)=>`<div class="row" data-tid="${x.id}" style="flex-wrap:nowrap;padding:8px 0;border-top:1px solid var(--bd)"><span style="flex:1">${esc(x.t)}</span><button type="button" class="g" style="padding:2px 12px" ${i==0?'disabled':''} onclick="tdMv(${x.id},-1)">▲</button><button type="button" class="g" style="padding:2px 12px" ${i==n-1?'disabled':''} onclick="tdMv(${x.id},1)">▼</button></div>`;
function tdMv(id,d){const L=tdL(),i=L.findIndex(y=>y.id==id),j=i+d;if(i<0||j<0||j>=L.length)return;[L[i],L[j]]=[L[j],L[i]];save();const old={};document.querySelectorAll('[data-tid]').forEach(r=>old[r.dataset.tid]=r.getBoundingClientRect().top);draw();
 document.querySelectorAll('[data-tid]').forEach(r=>{const dy=(old[r.dataset.tid]||0)-r.getBoundingClientRect().top;if(dy){r.style.transition='none';r.style.transform='translateY('+dy+'px)';r.getBoundingClientRect();r.style.transition='transform .25s ease';r.style.transform=''}})}
const tdForm=(add,id)=>`<div class="row" style="margin-top:8px;flex-wrap:nowrap"><input id="${id}" placeholder="اكتب مهمة جديدة" autocomplete="off" onkeydown="if(event.key==='Enter')${add}()" style="flex:1;margin:0;min-width:0"><button type="button" onmousedown="event.preventDefault()" onclick="${add}()">${svg('plus')}</button></div>`;
function todos(){const T=tdL(),ok=T.filter(x=>x.s==1).length,no=T.filter(x=>x.s==2).length;
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">قائمة المهمات</b><span class="row" style="gap:8px"><span class="m">${T.length} مهمة • في الأرشيف ${(S.tda||[]).length}</span>${T.length>1?`<button type="button" class="g" style="padding:4px 12px" onclick="tdOrd=!tdOrd;draw()">${tdOrd?'تم':'↕ ترتيب'}</button>`:''}</span></div><div class="c">${T.map((x,i)=>tdOrd&&T.length>1?tdItemO(x,i,T.length):tdItem(x,'tdMk','tdDel')).join('')||'<div class="m">لا مهام بعد، أضف مهمتك الأولى</div>'}${tdForm('tdAdd','tdi')}</div><div class="m" style="padding:0 18px 8px">ضع ✓ أو ✗ على المهمة فتنتقل إلى الأرشيف بعد 5 ثوانٍ (اضغط العلامة نفسها لإلغاء)، ومنه تستطيع استرجاعها.</div>${goalCard()}${privCard()}`}
const kbKeep=id=>{const e=document.getElementById(id);if(e)e.focus({preventScroll:true})};
function tdAdd(){const v=$('#tdi').value.trim();if(!v)return;tdL().push({id:S.id++,t:v,s:0,c:Date.now()});save();draw();kbKeep('tdi')}
const tdCd={};
const tdBadge=(mk,id)=>{const c=tdCd[mk+id];return c?`<span class="tkc" id="tdc${mk+id}">${c.n}</span>`:''};
function tdPick(mk,mv,get,id,v){const key=mk+id,x=get(id);if(!x)return;const c=tdCd[key];if(c){clearInterval(c.iv);delete tdCd[key];if(x.s==v){x.s=0;save();draw();return}}
 x.s=v;save();tdCd[key]={n:5,iv:setInterval(()=>{const c=tdCd[key];if(!c)return;c.n--;if(c.n<=0){clearInterval(c.iv);delete tdCd[key];if(get(id))mv(id,v)}else{const e=document.getElementById('tdc'+key);if(e)e.textContent=c.n}},1000)};draw()}
const tdMk=(id,v)=>tdPick('tdMk',tdMove,i=>tdL().find(y=>y.id==i),id,v);
function tdMove(id,v){const x=tdL().find(y=>y.id==id);x.s=v;x.at=Date.now();S.td=tdL().filter(y=>y.id!=id);(S.tda=S.tda||[]).push(x);save();toast('نُقلت المهمة إلى الأرشيف');draw()}
function tdDel(id){S.td=tdL().filter(y=>y.id!=id);save();draw()}
/* ---------- الأهداف ---------- */
const GT=['أهداف الحياة','المدى الطويل','المدى القصير','سنوي','ربع سنوي','شهري','أسبوعي','يومي','أخرى'];
const glL=()=>S.goals=S.goals||[];
let glOpen=0,glDr=null,glOrd=false;
const glPr=g=>g.auto?((g.tasks||[]).length?Math.round(g.tasks.filter(x=>x.s).length/g.tasks.length*100):0):Math.max(0,Math.min(100,+g.p||0));
const glRing=(p,z)=>{const r=z/2-8,c=2*Math.PI*r,h=z/2;return `<svg width="${z}" height="${z}" viewBox="0 0 ${z} ${z}"><circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="var(--bd)" stroke-width="9"/><circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="var(--pri)" stroke-width="9" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c*(1-p/100)}" transform="rotate(-90 ${h} ${h})" style="transition:stroke-dashoffset .4s"/><text x="50%" y="50%" text-anchor="middle" dominant-baseline="central" fill="var(--pri)" font-weight="700" font-size="${z/5}">${p}%</text></svg>`};
const glDays=g=>Math.round((new Date(g.due+'T00:00')-new Date(ymd(new Date())+'T00:00'))/864e5);
const glLeft=g=>{const d=glDays(g);return d<0?'متأخر '+(-d)+' يوم':d==0?'اليوم':d==1?'غداً':'بعد '+d+' يوم'};
const goalCard=()=>{const L=glL(),a=L.length?Math.round(L.reduce((t,g)=>t+glPr(g),0)/L.length):0;return `<div class="c" onclick="go('gl')" style="cursor:pointer"><div class="row sp"><b>🎯 الأهداف</b><span class="ch">${svg('chev')}</span></div><div class="m">${L.length?L.length+' هدف • متوسط التقدم '+a+'%':'تابع أهدافك ومهامها ونسبة تقدمك'}</div></div>`};
const glRemHtml=()=>{const L=glL().filter(g=>g.rem&&g.due&&glPr(g)<100&&glDays(g)<=1);return L.length?`<div class="c" onclick="go('gl')" style="cursor:pointer;border-color:var(--gold)"><b>🔔 تذكير بالأهداف</b>${L.map(g=>`<div class="m">${esc(g.t)} — ${glLeft(g)}${glDays(g)<-30?' ('+g.due+')':''}</div>`).join('')}</div>`:''};
function glNew(){glDr={id:0,t:'',ty:'',start:ymd(new Date()),due:'',d:'',auto:true,rem:false};draw()}
function glEdit(id){const g=glL().find(x=>x.id==id);if(!g)return;glDr={id:g.id,t:g.t,ty:g.ty||'',start:g.start||'',due:g.due||'',d:g.d||'',auto:!!g.auto,rem:!!g.rem};draw()}
function glSave(){const d=glDr;if(!d.t.trim()){toast('اكتب عنوان الهدف');return}
 if(d.start&&d.due&&d.due<d.start){toast('تاريخ الاستحقاق قبل تاريخ البدء');return}
 if(d.id){const g=glL().find(x=>x.id==d.id);if(g){g.t=d.t.trim();g.ty=d.ty;g.start=d.start;g.due=d.due;g.d=d.d;g.auto=d.auto;g.rem=d.rem}glOpen=d.id}
 else{const g={id:S.id++,t:d.t.trim(),ty:d.ty,start:d.start,due:d.due,d:d.d,auto:d.auto,rem:d.rem,p:0,tasks:[],c:Date.now()};glL().push(g);glOpen=g.id}
 glDr=null;save();draw()}
function glDel(id){S.goals=glL().filter(x=>x.id!=id);glOpen=0;save();draw()}
function glTa(id){const g=glL().find(x=>x.id==id),v=($('#gti')||{value:''}).value.trim();if(!g||!v)return;(g.tasks=g.tasks||[]).push({id:S.id++,t:v,s:0});save();draw();kbKeep('gti')}
function glTk(id,tid){const g=glL().find(x=>x.id==id),x=g&&(g.tasks||[]).find(y=>y.id==tid);if(!x)return;x.s=x.s?0:1;save();draw()}
function glMv(id,tid,d){const g=glL().find(x=>x.id==id);if(!g)return;const L=g.tasks||[],i=L.findIndex(y=>y.id==tid),j=i+d;if(i<0||j<0||j>=L.length)return;[L[i],L[j]]=[L[j],L[i]];save();const old={};document.querySelectorAll('[data-tid]').forEach(r=>old[r.dataset.tid]=r.getBoundingClientRect().top);draw();
 document.querySelectorAll('[data-tid]').forEach(r=>{const dy=(old[r.dataset.tid]||0)-r.getBoundingClientRect().top;if(dy){r.style.transition='none';r.style.transform='translateY('+dy+'px)';r.getBoundingClientRect();r.style.transition='transform .25s ease';r.style.transform=''}})}
function glTd(id,tid){const g=glL().find(x=>x.id==id);if(!g)return;g.tasks=(g.tasks||[]).filter(y=>y.id!=tid);save();draw()}
function glPv(id,v){const g=glL().find(x=>x.id==id);if(!g)return;g.p=+v;const p=glPr(g),r=document.getElementById('glr'),e=document.getElementById('glp');if(r)r.innerHTML=glRing(p,120);if(e)e.textContent=p+'%'}
const glSw=(t,k)=>`<div class="row sp" style="flex-wrap:nowrap;padding:8px 0"><span>${t}</span><span class="sw ${glDr[k]?'on':''}" onclick="glDr.${k}=!glDr.${k};draw()"></span></div>`;
function glForm(){const d=glDr;return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">${d.id?'تعديل الهدف':'هدف جديد'}</b><span class="row" style="gap:8px"><button type="button" class="g" style="padding:4px 12px" onclick="glDr=null;draw()">إلغاء</button><button type="button" style="padding:4px 14px" onclick="glSave()">حفظ</button></span></div>
 <div class="c"><div class="m">العنوان</div><input value="${esc(d.t)}" oninput="glDr.t=this.value" autocomplete="off">
 <div class="m" style="margin-top:8px">النوع</div><select onchange="glDr.ty=this.value"><option value="">إختر النوع</option>${GT.map(x=>`<option ${d.ty==x?'selected':''}>${x}</option>`).join('')}</select>
 <div class="m" style="margin-top:8px">تاريخ البدء</div><input type="date" value="${esc(d.start)}" onchange="glDr.start=this.value">
 <div class="m" style="margin-top:8px">تاريخ الاستحقاق</div><input type="date" value="${esc(d.due)}" onchange="glDr.due=this.value">
 <div class="m" style="margin-top:8px">الوصف (إختياري)</div><textarea rows="4" oninput="glDr.d=this.value">${esc(d.d)}</textarea>
 ${glSw('شريط التقدم تلقائي','auto')}${glSw('ذكّرني','rem')}${d.rem&&!d.due?'<div class="m">حدّد تاريخ الاستحقاق ليظهر التذكير</div>':''}</div>`}
function glDetail(g){const p=glPr(g),T=g.tasks||[],ok=T.filter(x=>x.s).length;
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">${esc(g.t)}</b><span class="row" style="gap:6px"><button type="button" class="g" style="padding:4px 12px" onclick="glEdit(${g.id})">تعديل</button><button type="button" class="g" style="padding:4px 12px" onclick="glOpen=0;glOrd=false;draw()">رجوع</button></span></div>
 <div class="c"><div class="row sp" style="flex-wrap:nowrap"><div id="glr">${glRing(p,120)}</div><div class="m" style="line-height:2">✅ ${ok} من ${T.length} مهام<br>${g.ty?'🏷 '+esc(g.ty)+'<br>':''}${g.start?'📅 تاريخ البدء: '+g.start+'<br>':''}${g.due?'📅 تاريخ الاستحقاق: '+g.due+' • '+glLeft(g)+'<br>':''}${g.rem?'🔔 التذكير مفعّل':''}</div></div>${g.d?`<div class="m" style="margin-top:8px;white-space:pre-wrap">${esc(g.d)}</div>`:''}</div>
 <div class="c"><div class="row sp"><b>تقدم الإنجازات</b><b id="glp" style="color:var(--pri)">${p}%</b></div>${g.auto?'':`<input type="range" min="0" max="100" value="${p}" oninput="glPv(${g.id},this.value)" onchange="save()" style="padding:0;margin:10px 0"><div class="m">بإمكانك ضبط نسبة تقدم الهدف يدوياً</div>`}</div>
 <div class="c"><div class="row sp"><b>مهام</b><span class="row" style="gap:8px"><span class="m">${ok}/${T.length}</span>${T.length>1?`<button type="button" class="g" style="padding:4px 12px" onclick="glOrd=!glOrd;draw()">${glOrd?'تم':'↕ ترتيب'}</button>`:''}</span></div>${T.map((x,i)=>glOrd&&T.length>1?`<div class="row" data-tid="${x.id}" style="flex-wrap:nowrap;padding:8px 0;border-top:1px solid var(--bd)"><span style="flex:1">${esc(x.t)}</span><button type="button" class="g" style="padding:2px 12px" ${i==0?'disabled':''} onclick="glMv(${g.id},${x.id},-1)">▲</button><button type="button" class="g" style="padding:2px 12px" ${i==T.length-1?'disabled':''} onclick="glMv(${g.id},${x.id},1)">▼</button></div>`:`<div class="row" style="flex-wrap:nowrap;padding:8px 0;border-top:1px solid var(--bd)"><span class="ck ${x.s?'on':''}" onclick="glTk(${g.id},${x.id})">${MKC}</span><span style="flex:1;${x.s?'text-decoration:line-through;color:var(--mut)':''}">${esc(x.t)}</span><button type="button" class="g" style="padding:2px 9px" onclick="ask('هل تريد حذف المهمة؟',()=>glTd(${g.id},${x.id}),'نعم','لا')">×</button></div>`).join('')||'<div class="m">لا مهام بعد</div>'}<div class="row" style="margin-top:8px;flex-wrap:nowrap"><input id="gti" placeholder="اكتب مهمة جديدة" autocomplete="off" onkeydown="if(event.key==='Enter')glTa(${g.id})" style="flex:1;margin:0;min-width:0"><button type="button" onmousedown="event.preventDefault()" onclick="glTa(${g.id})">${svg('plus')}</button></div></div>
 <div class="c"><button type="button" class="r" style="width:100%" onclick="ask('هل تريد حذف الهدف؟',()=>glDel(${g.id}),'نعم','لا')">حذف الهدف</button></div>`}
function goalsPage(){if(glDr)return glForm();const g=glL().find(x=>x.id==glOpen);if(g)return glDetail(g);
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">🎯 الأهداف</b><span class="row" style="gap:8px"><button type="button" style="padding:4px 12px" onclick="glNew()">+ هدف جديد</button><button type="button" class="g" style="padding:4px 12px" onclick="go('td')">رجوع</button></span></div>`+(glL().map(g=>{const p=glPr(g);return `<div class="c" onclick="glOpen=${g.id};draw()" style="cursor:pointer"><div class="row sp"><b>${esc(g.t)}</b><span class="m">${esc(g.ty||'')}</span></div><div style="height:8px;border-radius:6px;background:var(--bd);margin:10px 0 6px;overflow:hidden"><div style="height:100%;width:${p}%;background:var(--pri);border-radius:6px;transition:width .4s"></div></div><div class="row sp m"><span>${p}%</span><span>${g.start||g.due?'📅 '+(g.start&&g.due?g.start+' – '+g.due:g.start||g.due):''}${g.rem?' 🔔':''}</span></div></div>`}).join('')||'<div class="c m">لا أهداف بعد، اضغط «+ هدف جديد»</div>')}
/* ---------- تذكير تتبع الصلاة ---------- */
const prRem=()=>Object.assign({on:true,t:'21:00'},prP().rem||{});
function prRemSet(k,v){const P=prP();P.rem=Object.assign(prRem(),{[k]:v});save();draw()}
let prRemOpen=false;
const prRemCard=()=>{const R=prRem();return `<div class="c"><div class="row sp" style="flex-wrap:nowrap;align-items:center"><span onclick="prRemOpen=!prRemOpen;draw()" style="cursor:pointer;flex:1;display:flex;align-items:center;gap:8px"><b>تذكير تتبع الصلاة</b><span style="font-size:12px;color:var(--mut);display:inline-block;transition:transform .2s;transform:rotate(${prRemOpen?180:0}deg)">▾</span></span><span class="sw ${R.on?'on':''}" onclick="prRemSet('on',${!R.on})"></span></div>${prRemOpen?`<div class="m" style="margin-top:4px">يظهر في صفحة «اليوم» إذا بقيت صلوات بلا تسجيل</div>${R.on?`<div class="row sp" style="margin-top:8px"><span class="m">يبدأ التذكير من الساعة</span><input type="time" value="${R.t}" onchange="prRemSet('t',this.value||'21:00')" style="width:auto;margin:0"></div>`:''}`:''}</div>`};
const prRemHtml=()=>{const P=prP(),R=prRem(),now=new Date(),today=ymd(now);if(!R.on||!P.start||today<P.start)return '';
 const rec=P.days[today]||{},miss=PK.map((p,i)=>(!rec[p]||!rec[p].s)?PN[i]:'').filter(Boolean);let past=0;
 for(let i=1;i<=7;i++){const d=new Date(now);d.setDate(d.getDate()-i);const k=ymd(d);if(k<P.start)break;if(prQ(k))past++}
 const td=miss.length&&hm(now)>=R.t;if(!td&&!past)return '';
 return `<div class="c" onclick="prY=0;go('pr')" style="cursor:pointer;border-color:var(--gold)"><b>${svg('moon')} تذكير بتتبع الصلاة</b>${td?`<div class="m">لم تسجّل اليوم: ${miss.join('، ')}</div>`:''}${past?`<div class="m">${past} ${past==1?'يوم سابق':'أيام سابقة'} بلا تسجيل (آخر 7 أيام)</div>`:''}</div>`};
let pvOk=false,pvAfter='',arPvOpen=false;
const pvD=()=>S.pv||(S.pv={lock:null,items:[]});
const privCard=()=>`<div class="c" onclick="go('pv')" style="cursor:pointer"><div class="row sp"><b>${svg('lock')} المهام الخاصة</b><span class="ch">${svg('chev')}</span></div><div class="m">قائمة مهام محمية بكلمة سر</div></div>`;
function privPage(){const P=pvD(),hd=`<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">${svg('lock')} المهام الخاصة</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>`;
 if(!P.lock)return hd+`<div class="c"><b>إنشاء كلمة سر للمهام الخاصة</b><input id="pvp" type="password" dir="ltr" placeholder="كلمة السر (4 أحرف على الأقل)"><input id="pvp2" type="password" dir="ltr" placeholder="تأكيد كلمة السر">${qBox('pv')}<div id="pvm" class="m" style="color:var(--bad)"></div><button type="button" onclick="pvCreate()" style="width:100%">حفظ</button></div>`;
 if(!pvOk)return hd+`<div class="c"><b>${svg('lock')} أدخل كلمة السر</b><input id="pvp" type="password" dir="ltr" placeholder="كلمة السر" onkeydown="if(event.key==='Enter')pvCheck()"><div id="pvm" class="m" style="color:var(--bad)"></div><button type="button" onclick="pvCheck()" style="width:100%">فتح</button><button type="button" class="g" onclick="pvForgot()" style="width:100%;margin-top:6px">نسيت كلمة السر</button></div>`;
 const T=P.items,ok=T.filter(x=>x.s==1).length,no=T.filter(x=>x.s==2).length;
 return hd+`<div class="c"><div class="row sp"><span class="m">✓ ${ok} • ✗ ${no} • ${T.length}</span><button type="button" class="g" style="padding:4px 12px" onclick="pvOk=false;draw()">${svg('lock')} قفل الآن</button><button type="button" class="g" style="padding:4px 12px" onclick="pvRmSheet()">إزالة القفل</button></div>${T.map(x=>tdItem(x,'pvMk','pvDel')).join('')||'<div class="m" style="margin-top:6px">لا مهام خاصة بعد</div>'}${tdForm('pvAdd','pvi')}</div>`}
async function pvCreate(){const a=$('#pvp').value,b=$('#pvp2').value,q=qRead('pv');if(a.length<4||a!==b||!nrm(q.a)){$('#pvm').textContent=a.length<4?'⚠️ كلمة السر 4 أحرف على الأقل':a!==b?'⚠️ كلمتا السر غير متطابقتين':'⚠️ اكتب جواب سؤال الأمان';return}const P=pvD();P.lock=await hp(a);P.sq=q.q;P.sa=await hp(nrm(q.a));pvOk=true;save();draw()}
function pvForgot(){const P=pvD();if(!P.sq){$('#sh').innerHTML=noSq();return}$('#sh').innerHTML=shW(`<b>سؤال الأمان</b><div style="margin:8px 0">${esc(P.sq)}</div><input id="pva" placeholder="الجواب" autocomplete="off"><div id="pvm2" class="m" style="color:var(--bad)"></div><button type="button" onclick="pvForgotCheck()">تأكيد وإزالة القفل</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
async function pvForgotCheck(){const P=pvD();if(await hp(nrm($('#pva').value))===P.sa){P.lock=null;P.sq=null;P.sa=null;pvOk=false;save();$('#sh').innerHTML='';toast('أُزيل القفل، يمكنك إنشاء كلمة سر جديدة');draw()}else $('#pvm2').textContent='⚠️ الجواب غير صحيح'}
function pvRmSheet(){$('#sh').innerHTML=shW(`<b>إزالة قفل المهام الخاصة</b><div class="m" style="margin:6px 0">اكتب كلمة السر لإزالة القفل.</div><input id="pvr" type="password" dir="ltr" placeholder="كلمة السر"><div id="pvm2" class="m" style="color:var(--bad)"></div><button type="button" onclick="pvRmDo()">إزالة القفل</button><button type="button" class="g" onclick="pvForgot()">نسيت كلمة السر</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
async function pvRmDo(){const P=pvD();if(await hp($('#pvr').value)===P.lock){P.lock=null;P.sq=null;P.sa=null;pvOk=false;save();$('#sh').innerHTML='';toast('أُزيل القفل');draw()}else $('#pvm2').textContent='⚠️ كلمة السر غير صحيحة'}
async function pvCheck(){if(await hp($('#pvp').value)===pvD().lock){pvOk=true;if(pvAfter=='ar'){pvAfter='';arPvOpen=true;tab='ar'}draw()}else $('#pvm').textContent='⚠️ كلمة السر غير صحيحة'}
function pvAdd(){const v=$('#pvi').value.trim();if(!v)return;pvD().items.push({id:S.id++,t:v,s:0,c:Date.now()});save();draw();kbKeep('pvi')}
const pvMk=(id,v)=>tdPick('pvMk',pvMove,i=>pvD().items.find(y=>y.id==i),id,v);
function pvMove(id,v){const P=pvD(),x=P.items.find(y=>y.id==id);x.s=v;x.at=Date.now();P.items=P.items.filter(y=>y.id!=id);(P.arc=P.arc||[]).push(x);save();toast('نُقلت المهمة إلى الأرشيف');draw()}
function pvDel(id){pvD().items=pvD().items.filter(y=>y.id!=id);save();draw()}
function arPv(){const P=pvD();if(!P.lock){toast('أنشئ كلمة سر أولاً من «المهام الخاصة» في تبويب اليوم');return}if(!pvOk){pvAfter='ar';tab='pv';draw();return}arPvOpen=!arPvOpen;draw()}

/* ---------- المتسابقون ---------- */
let ctTab='list',ctDraft={name:'',juz:[],min:''};const uLbl=u=>u[0]=='ج'?'جزء '+u.slice(1):u[0]=='ص'?'صفحة '+u.slice(1):'سورة '+u;const ctOpen={};
const ctL=c=>mLeft(c.tm);
function conts(){const C=S.cont=S.cont||[];
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">المتسابقون</b><button type="button" class="g" onclick="go('home')">رجوع</button></div><div style="padding:0 12px"><span class="chip ${ctTab=='list'?'on':''}" onclick="ctTab='list';draw()">المتسابقون</span><span class="chip ${ctTab=='st'?'on':''}" onclick="ctTab='st';draw()">إحصائيات المسابقة</span><span class="chip ${ctTab=='dt'?'on':''}" onclick="ctTab='dt';draw()">إحصائيات المسابقة / التفصيل</span></div>`+(ctTab=='st'?ctStats(allC()):ctTab=='dt'?ctDetail(allC()):ctList(C))}
function ctList(C){const d=ctDraft;
 const form=`<div class="c"><b>متسابق جديد</b><input placeholder="اسم المتسابق" value="${esc(d.name)}" oninput="ctDraft.name=this.value" autocomplete="off"><div class="row" style="flex-wrap:nowrap;gap:6px"><div class="m" style="flex:1">${d.juz.length?esc(d.juz.map(uLbl).join('، ')):'لم تُختر أجزاء أو سور أو صفحات'}</div><button type="button" onclick="ctPick('new')" style="padding:10px 14px">${svg('plus')} اختيار</button></div><input placeholder="مدة التايمر بالدقائق (اكتبها أنت)" value="${esc(d.min)}" oninput="ctDraft.min=this.value" autocomplete="off"><button type="button" onclick="ctAdd()" style="width:100%">إضافة المتسابق</button></div>`;
 return form+C.map(c=>{const open=ctOpen[c.id],m=c.tm,l=ctL(c);
  return `<div class="c"><div class="row sp"><b style="font-size:17px">${esc(c.name)}</b><span class="m">${c.fin?'✅ أنهى • '+fmt(c.el):(m.run?'يعمل...':'قيد المسابقة')}</span></div>
  <div class="m" style="margin-top:6px">الأجزاء — اضغط على الجزء لتحديد هل سمعه فعلاً</div><div>${c.juz.map(n=>`<span class="chip ${c.heard.includes(n)?'on':''}" onclick="ctHeard(${c.id},'${n}')">${n}</span>`).join('')}</div><div class="m">سمع ${c.heard.length} من ${c.juz.length} أجزاء</div>
  <div style="margin-top:8px;padding:8px;border:1px solid var(--bd);border-radius:12px"><div class="row sp" style="flex-wrap:nowrap"><button type="button" class="g" style="padding:6px 10px" onclick="ctAdj(${c.id},-1800)">−30</button><b id="ct${c.id}" style="font-size:28px;font-variant-numeric:tabular-nums;color:${mShow(m).red?'var(--bad)':'inherit'}">${mShow(m).t}</b><button type="button" class="g" style="padding:6px 10px" onclick="ctAdj(${c.id},1800)">+30</button><button type="button" onclick="ctToggle(${c.id})">${m.run?'⏸ إيقاف':'⏱ تشغيل'}</button><button type="button" class="g" onclick="ctReset(${c.id})">↺</button></div><div class="row" style="margin-top:6px;flex-wrap:nowrap;gap:6px"><input id="cti${c.id}" type="text" autocomplete="off" placeholder="اكتب المدة: 25 أو 1:30" onkeydown="if(event.key==='Enter')ctSet(${c.id})" style="flex:1;margin:0;min-width:0"><button type="button" class="g" style="padding:8px 12px" onclick="ctSet(${c.id})">تعيين</button></div></div>
  <div class="row" style="margin-top:8px"><button type="button" class="g" onclick="ctStart(${c.id})">${c.s0?'⏱ بدأ '+hm(new Date(c.s0)):'▶ ابدأ'}</button>${c.s0?`<button type="button" class="g" onclick="ctRs(${c.id})">↺ البداية</button>`:''}<button type="button" class="g" style="flex:1" onclick="ctOpen[${c.id}]=!ctOpen[${c.id}];draw()">${open?'▴ إغلاق':'▾ تعديل الأجزاء'}</button><button type="button" style="flex:1" onclick="ctFinish(${c.id})">${c.fin?'↺ إعادة فتح':'✅ إنهاء'}</button><button type="button" class="g" onclick="ask('حذف المتسابق؟',()=>ctDel(${c.id}),'نعم، احذف')">🗑</button></div>
  ${open?`<div class="row" style="margin-top:8px"><button type="button" class="g" style="flex:1" onclick="ctPick(${c.id})">${svg('plus')} تعديل الأجزاء / السور / الصفحات</button></div>`:''}</div>`}).join('')}
function ctAdd(){const d=ctDraft;if(!d.name.trim()||!d.juz.length)return;const j=[...d.juz],dur=parseT(d.min)||0;
 S.cont.push({id:S.id++,name:d.name.trim(),juz:j,heard:[...j],tm:mkT(dur),fin:false,el:0,at:Date.now()});ctDraft={name:'',juz:[],min:''};save();draw()}
const ctG=id=>S.cont.find(x=>x.id==id);
function ctHeard(id,n){const c=ctG(id);c.heard=c.heard.includes(n)?c.heard.filter(x=>x!=n):[...c.heard,n];save();draw()}
const allC=()=>(S.cont||[]).concat(S.carc||[]);
function ctArch(c){(S.carc=S.carc||[]).push(c);S.cont=S.cont.filter(x=>x.id!=c.id)}
function ctDel(id){S.cont=S.cont.filter(x=>x.id!=id);save();draw()}
function ctSet(id){const c=ctG(id),v=parseT(($('#cti'+id)||{}).value);if(!(v>0))return;mSet(c.tm,v);save();draw()}
function ctAdj(id,d){mAdj(ctG(id).tm,d);save();draw()}
function ctToggle(id){const c=ctG(id),m=c.tm;if(m.run)mPause(m);else{if(!mStart(m,parseT(($('#cti'+id)||{}).value))){toast('اكتب مدة التايمر أولاً');return}c.fin=false;c.s0=c.s0||Date.now()}save();draw()}
function ctStart(id){const c=ctG(id),m=c.tm;if(!c.s0)c.s0=Date.now();if(!m.run){if(mStart(m,parseT(($('#cti'+id)||{}).value)))c.fin=false;else toast('اكتب مدة التايمر لتشغيل العدّاد')}save();draw()}
function ctRs(id){const c=ctG(id);if(!c)return;c.s0=0;save();draw()}
function ctReset(id){const c=ctG(id);mReset(c.tm);c.fin=false;c.el=0;c.s0=0;c.e0=0;save();draw()}
function ctFinish(id){const c=ctG(id),m=c.tm;if(m.run)mPause(m);c.fin=true;c.el=Math.round(m.used||0);c.e0=Date.now();ctArch(c);save();draw();toast('انتقل المتسابق إلى الأرشيف')}
function ctDetail(C){if(!C.length)return '<div class="c m">أضف متسابقين لتظهر المقارنة</div>';const G={};C.forEach(c=>(G[c.juz.length]=G[c.juz.length]||[]).push(c));const tt=ms=>ms?hm(new Date(ms)):'—',cs='style="padding:6px 4px;border-bottom:1px solid var(--bd);text-align:center;white-space:nowrap"';
 return Object.keys(G).map(Number).sort((a,b)=>a-b).map(k=>`<div class="c"><b>${k} ${k==1?'جزء':'أجزاء'}</b><div class="m">مقارنة المتسابقين الذين لديهم نفس عدد الأجزاء (وليس بالضرورة نفس الأجزاء)</div><div style="overflow-x:auto;margin-top:6px"><table style="width:100%;border-collapse:collapse;font-size:13px"><tr class="m"><td ${cs}>#</td><td ${cs}>الاسم</td><td ${cs}>الأجزاء</td><td ${cs}>الوقت المخصص</td><td ${cs}>المستهلك</td><td ${cs}>الزائد</td><td ${cs}>البداية</td><td ${cs}>النهاية</td></tr>${G[k].slice().sort((a,b)=>((a.fin?a.el:mUsed(a.tm))||9e9)-((b.fin?b.el:mUsed(b.tm))||9e9)).map((c,i)=>`<tr><td ${cs}><span class="rk ${i<3?'r'+(i+1):''}">${i+1}</span></td><td ${cs}><b>${esc(c.name)}</b></td><td ${cs}>${c.juz.join('،')}</td><td ${cs}>${hms(mOrig(c.tm))}</td><td ${cs}>${hms(c.fin?c.el:mUsed(c.tm))}</td><td ${cs}>${hms(mOver(c.tm))}</td><td ${cs}>${tt(c.s0)}</td><td ${cs}>${c.fin?tt(c.e0):'—'}</td></tr>`).join('')}</table></div></div>`).join('')}
function ctStats(C){if(!C.length)return '<div class="c m">أضف متسابقين لتظهر الإحصائيات</div>';
 const rk=(L,f)=>L.map((c,i)=>`<div class="row" style="padding:8px 0;border-top:1px solid var(--bd);flex-wrap:nowrap"><span class="rk ${i<3?'r'+(i+1):''}">${i+1}</span><b style="flex:1">${esc(c.name)}</b><span class="m" style="text-align:end">${f(c)}</span></div>`).join('');
 const most=[...C].sort((a,b)=>b.heard.length-a.heard.length||((a.el||9e9)-(b.el||9e9))),fast=C.filter(c=>c.fin&&c.el>0).sort((a,b)=>a.el-b.el||b.heard.length-a.heard.length),tot=C.reduce((a,c)=>a+c.heard.length,0);
 return `<div style="padding:8px 12px 0"><button type="button" class="g" onclick="printReport('ct')" style="width:100%">📄 حفظ إحصائيات المتسابقين كملف PDF</button></div><div class="row" style="padding:0 12px"><div class="c" style="flex:1;margin:10px 0">المتسابقون<br><b style="font-size:22px">${C.length}</b></div><div class="c" style="flex:1;margin:10px 0">إجمالي الأجزاء المسموعة<br><b style="font-size:22px">${tot}</b></div></div>
 <div class="c"><b>🏆 الأكثر استماعاً للأجزاء</b>${rk(most,c=>c.heard.length+' جزء من '+c.juz.length)}</div>
 <div class="c"><b>⏱ الأسرع وقتاً</b>${fast.length?rk(fast,c=>fmt(c.el)+'<br>'+c.heard.length+' جزء • '+fmt(Math.round(c.el/Math.max(1,c.heard.length)))+' للجزء'):'<div class="m" style="margin-top:6px">تظهر هنا بعد أن يُنهي المتسابقون (زر «إنهاء» أو انتهاء التايمر).</div>'}</div>`}
/* ---------- النسخ الاحتياطي والتقارير ---------- */
const bkJson=()=>JSON.stringify({app:'qmrm',v:1,at:Date.now(),data:S});
function exportData(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([bkJson()],{type:'application/json'}));a.download='qmrm-backup-'+ymd(new Date())+'.json';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500);S.lastBk=Date.now();save();toast('تم حفظ النسخة الاحتياطية');if(tab=='bk')draw()}
function importData(inp){const f=inp.files[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{try{const o=JSON.parse(rd.result);if(o.app!=='qmrm'||!o.data||!Array.isArray(o.data.tasks))throw 0;ask('استبدال بياناتك الحالية بمحتوى هذه النسخة؟ سيُحفظ نسخة أمان من بياناتك الحالية للتراجع.',()=>{try{localStorage.setItem('qmrm_pre_import',JSON.stringify({at:Date.now(),s:S}))}catch(e){toast('تعذّر حفظ نسخة الأمان لامتلاء المساحة')}S=Object.assign(EMPTY(),o.data);migrate();S._u=Date.now();save();toast('تم استيراد البيانات');go('home')},'نعم، استبدل')}catch(e){toast('الملف غير صالح')}};rd.readAsText(f)}
const preGet=()=>{try{const t=localStorage.getItem('qmrm_pre_import');return t?JSON.parse(t):null}catch(e){return null}};
function undoImport(){const p=preGet();if(!p||!p.s)return;ask('التراجع عن آخر استيراد واسترجاع بياناتك قبله؟',()=>{S=Object.assign(EMPTY(),p.s);migrate();S._u=Date.now();save();try{localStorage.removeItem('qmrm_pre_import')}catch(e){dbg(e)}toast('تم التراجع عن الاستيراد');go('home')},'نعم، تراجع')}
function setBkf(v){S.bkf=v;save();draw()}
function bkCheck(){const f=S.bkf||'7';if(f=='off')return;if(!S.lastBk){S.lastBk=Date.now();save();return}
 if(Date.now()-S.lastBk>f*864e5&&!$('#ban').innerHTML.includes('bkb'))$('#ban').innerHTML+=`<div class="c bkb" style="border-color:var(--pri)"><b>${svg('download')} النسخة الاحتياطية</b><div class="m" style="margin:6px 0">حان وقت حفظ نسخة من بياناتك على جهازك.</div><div class="row"><button type="button" onclick="exportData();this.closest('.c').remove()">حفظ الآن</button><button type="button" class="g" onclick="this.closest('.c').remove()">لاحقاً</button></div></div>`}
setInterval(bkCheck,36e5);
function backup(){const f=S.bkf||'7',lb=S.lastBk?new Date(S.lastBk):null;
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">النسخ الاحتياطي والتقارير</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>
 <div class="c"><b>حفظ بياناتك على جهازك</b><div class="m" style="margin-top:4px">آخر نسخة: ${lb?ymd(lb)+' '+hm(lb):'لم تُحفظ بعد'}</div><button type="button" onclick="exportData()" style="width:100%;margin-top:8px">${svg('download')} حفظ نسخة احتياطية (ملف)</button><label style="display:block;text-align:center;margin-top:8px;padding:10px 14px;border-radius:10px;border:1px solid var(--pri);color:var(--pri);cursor:pointer">استيراد نسخة من ملف<input type="file" accept=".json,application/json" style="display:none" onchange="importData(this)"></label>${preGet()?`<button type="button" class="g" onclick="undoImport()" style="width:100%;margin-top:8px">↩ التراجع عن آخر استيراد (${ymd(new Date(preGet().at))})</button>`:''}</div>
 <div class="c"><b>تذكير النسخ الدوري</b><div style="margin-top:6px">${[['off','إيقاف'],['1','يومياً'],['7','أسبوعياً'],['30','شهرياً']].map(([k,t])=>`<span class="chip ${f==k?'on':''}" onclick="setBkf('${k}')">${t}</span>`).join('')}</div><div class="m" style="margin-top:6px">المتصفح لا يسمح بالكتابة التلقائية على ملفات جهازك، لذلك يظهر لك تنبيه في الموعد وتضغط «حفظ الآن» فيُحمَّل الملف.</div></div>
 <div class="c"><b>التقارير (PDF / Word)</b>${[['all','إنجازاتي كاملة (كل التقارير في ملف واحد)'],['wk','تقرير أسبوعي للمعلم (آخر 7 أيام)'],['ach','سجل الإنجازات'],['juz','جدول الأجزاء'],['ct','المتسابقون'],['prw','متتبع الصلاة — الأسبوع'],['pr','متتبع الصلاة — الشهر'],['pry','متتبع الصلاة — السنة'],['td','قائمة المهمات'],['arc','الأرشيف']].map(([k,t])=>`<div class="row" style="flex-wrap:nowrap;padding:8px 0;border-top:1px solid var(--bd)"><span style="flex:1;${k=='all'?'font-weight:700':''}">${t}</span><button type="button" style="padding:6px 12px" onclick="printReport('${k}')">PDF</button><button type="button" class="g" style="padding:6px 12px" onclick="exportWord('${k}')">Word</button></div>`).join('')}<div class="m" style="margin-top:6px">PDF: تفتح نافذة الطباعة فاختر «حفظ بصيغة PDF». Word: يُحمَّل ملف .docx يفتح في Word على الهاتف.</div></div>`}
const streak=()=>{const ds=new Set(S.logs.map(l=>l.date));let st=0,d=new Date();if(!ds.has(ymd(d)))d=new Date(d-864e5);while(ds.has(ymd(d))){st++;d=new Date(d-864e5)}return st};
/* ---------- ملفات DOCX حقيقية (تُفتح في Word على الهاتف) ---------- */
const CRCT=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
const crc32=u=>{let c=0xFFFFFFFF;for(let i=0;i<u.length;i++)c=CRCT[(c^u[i])&255]^(c>>>8);return(c^0xFFFFFFFF)>>>0};
const u8=t=>new TextEncoder().encode(t);
function zipStore(files){const parts=[],cen=[];let off=0;const w16=(a,v)=>a.push(v&255,(v>>8)&255),w32=(a,v)=>a.push(v&255,(v>>8)&255,(v>>16)&255,(v>>>24)&255);
 files.forEach(f=>{const nm=u8(f.name),crc=crc32(f.data),L=f.data.length,h=[];w32(h,0x04034b50);w16(h,20);w16(h,0x0800);w16(h,0);w16(h,0);w16(h,0x21);w32(h,crc);w32(h,L);w32(h,L);w16(h,nm.length);w16(h,0);
  parts.push(Uint8Array.from(h),nm,f.data);const c=[];w32(c,0x02014b50);w16(c,20);w16(c,20);w16(c,0x0800);w16(c,0);w16(c,0);w16(c,0x21);w32(c,crc);w32(c,L);w32(c,L);w16(c,nm.length);w16(c,0);w16(c,0);w16(c,0);w16(c,0);w32(c,0);w32(c,off);cen.push(Uint8Array.from(c),nm);off+=h.length+nm.length+L});
 const cs=cen.reduce((a,x)=>a+x.length,0),e=[];w32(e,0x06054b50);w16(e,0);w16(e,0);w16(e,files.length);w16(e,files.length);w32(e,cs);w32(e,off);w16(e,0);
 const all=[...parts,...cen,Uint8Array.from(e)],out=new Uint8Array(all.reduce((a,x)=>a+x.length,0));let q=0;all.forEach(x=>{out.set(x,q);q+=x.length});return out}
const xe=t=>String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const stripT=h=>String(h).replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&amp;/g,'&');
function dxRun(t,o){o=o||{};if(!t)return '';return `<w:r><w:rPr>${o.f?`<w:rFonts w:ascii="${xe(o.f)}" w:hAnsi="${xe(o.f)}" w:cs="${xe(o.f)}"/>`:''}${o.b?'<w:b/><w:bCs/>':''}${o.c?`<w:color w:val="${o.c}"/>`:''}${o.sz?`<w:sz w:val="${o.sz}"/><w:szCs w:val="${o.sz}"/>`:''}${/[\u0600-\u06FF]/.test(t)?'<w:rtl/>':''}</w:rPr><w:t xml:space="preserve">${xe(t)}</w:t></w:r>`}
const dxP=(runs,o)=>{o=o||{};return `<w:p><w:pPr>${o.pb?'<w:pageBreakBefore/>':''}<w:bidi/>${o.sp?`<w:spacing w:before="${o.sp[0]}" w:after="${o.sp[1]}"/>`:''}${o.al?`<w:jc w:val="${o.al}"/>`:''}</w:pPr>${runs}</w:p>`};
function dxT(h,rows,AH){const n=h.length,w=Math.floor(9000/n),bd=['top','left','bottom','right','insideH','insideV'].map(x=>`<w:${x} w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/>`).join('');
 const cell=(t,fill,o)=>`<w:tc><w:tcPr><w:tcW w:w="${w}" w:type="dxa"/>${fill?`<w:shd w:val="clear" w:color="auto" w:fill="${fill}"/>`:''}<w:vAlign w:val="center"/></w:tcPr>${dxP(dxRun(t,o),{al:'center'})}</w:tc>`;
 return `<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="9000" w:type="dxa"/><w:tblBorders>${bd}</w:tblBorders><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid>${h.map(()=>`<w:gridCol w:w="${w}"/>`).join('')}</w:tblGrid><w:tr><w:trPr><w:tblHeader/></w:trPr>${h.map(x=>cell(stripT(x),AH,{b:1,c:'FFFFFF',sz:20})).join('')}</w:tr>${rows.map((r,i)=>`<w:tr>${r.map(c=>cell(c.t,c.f||(i%2?'F4F7F5':''),{sz:20})).join('')}</w:tr>`).join('')}</w:tbl>`+dxP('',{sp:[0,60]})}
function dxImg(rid,cx,cy,id){return `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${id}" name="img${id}"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="${id}" name="img${id}.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`}
function docxFiles(body,imgs){imgs=imgs||[];const hd='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',W='http://schemas.openxmlformats.org/wordprocessingml/2006/main',R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
 const ct=hd+'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>';
 const rels=hd+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'+R+'/officeDocument" Target="word/document.xml"/></Relationships>';
 const drels=hd+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdS" Type="'+R+'/styles" Target="styles.xml"/>'+imgs.map(i=>'<Relationship Id="'+i.rid+'" Type="'+R+'/image" Target="media/'+i.name+'"/>').join('')+'</Relationships>';
 const styles=hd+'<w:styles xmlns:w="'+W+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="ar-SA" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="80"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>';
 const doc=hd+'<w:document xmlns:w="'+W+'" xmlns:r="'+R+'" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>'+body+'<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1000" w:right="1000" w:bottom="1000" w:left="1000" w:header="500" w:footer="500" w:gutter="0"/><w:bidi/></w:sectPr></w:body></w:document>';
 return zipStore([{name:'[Content_Types].xml',data:u8(ct)},{name:'_rels/.rels',data:u8(rels)},{name:'word/document.xml',data:u8(doc)},{name:'word/styles.xml',data:u8(styles)},{name:'word/_rels/document.xml.rels',data:u8(drels)},...imgs.map(i=>({name:'word/media/'+i.name,data:i.data}))])}
function dlBlob(bytes,name,mime){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([bytes],{type:mime}));a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},800)}
const DOCX_MIME='application/vnd.openxmlformats-officedocument.wordprocessingml.document';
/* ---------- التقارير (تصميم احترافي + نسخة DOCX) ---------- */
const nbAcc=()=>{const t=th();return(t.acc<0&&t.custom)?t.custom:thPal(thCur(),false).pri};
const REPT={all:'إنجازاتي كاملة',ach:'سجل الإنجازات',juz:'جدول الأجزاء',ct:'إحصائيات المتسابقين',prw:'متتبع الصلاة — الأسبوع',pr:'متتبع الصلاة — الشهر',pry:'متتبع الصلاة — السنة',td:'قائمة المهمات',arc:'الأرشيف',wk:'تقرير أسبوعي للمعلم'};
function repHtml(k,mode){const dx=mode=='docx',P=prof(),now=new Date(),AC=nbAcc(),AH=AC.slice(1).toUpperCase(),who=(P.name?P.name+' • ':'')+ymd(now)+' • '+hij(now),bgOf=h=>{const m=/background:#([0-9a-f]{6})/i.exec(String(h));return m?m[1].toUpperCase():''};
 const T=dx?(h,rows)=>dxT(h,rows.map(r=>r.map(x=>({t:stripT(x),f:bgOf(x)}))),AH):(h,rows)=>`<table style="width:100%;border-collapse:collapse;margin:6px 0 18px;font-size:12.5px"><thead><tr style="background:${AC};color:#fff">${h.map(x=>`<th style="padding:7px 8px;border:1px solid ${AC};font-weight:600">${x}</th>`).join('')}</tr></thead><tbody>${rows.map((r,i)=>`<tr style="background:${i%2?'#f4f7f5':'#fff'};page-break-inside:avoid">${r.map(x=>`<td style="padding:6px 8px;border:1px solid #d6dcd8;text-align:center">${x}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
 const H=dx?x=>dxP(dxRun(x,{b:1,sz:28,c:AH}),{sp:[260,100]}):x=>`<h2 style="font-size:16px;margin:22px 0 8px;padding:7px 12px;border-inline-start:5px solid ${AC};background:#f1f5f2;border-radius:4px;color:#1c2a1f">${x}</h2>`;
 const K=dx?it=>dxT(it.map(x=>x[0]),[it.map(x=>({t:String(x[1]),f:''}))],AH):it=>`<div style="display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 14px">${it.map(x=>`<div style="flex:1 1 28%;min-width:110px;padding:10px 12px;border-radius:10px;background:#f1f5f2;border:1px solid #d6e2d9;text-align:center"><div style="font-size:11px;color:#5c6b60">${x[0]}</div><div style="font-size:22px;font-weight:700;color:${AC}">${x[1]}</div></div>`).join('')}</div>`;
 let o=dx?dxP(dxRun('مُثبِّت القرآن',{c:AH,sz:22}))+dxP(dxRun(REPT[k]||'تقرير',{b:1,sz:44,c:AH}))+dxP(dxRun(who,{c:'666666',sz:20}),{sp:[0,200]}):`<div dir="${S.lang=='en'?'ltr':'rtl'}" style="font-family:system-ui,Tahoma,sans-serif;color:#1c2a1f;background:#fff;padding:6px"><div style="background:linear-gradient(135deg,${AC},#0d3b16);color:#fff;border-radius:14px;padding:20px 22px;margin-bottom:8px"><div style="font-size:12px;opacity:.85">مُثبِّت القرآن</div><div style="font-size:26px;font-weight:700;margin:3px 0 6px">${REPT[k]||'تقرير'}</div><div style="font-size:12px;opacity:.92">${esc(who)}</div></div>`;
 if(k=='all'||k=='ach'){const c={mastered:0,light:0,hard:0};taskGroups().forEach(x=>c[x.r]++);
  o+=H('ملخص')+K([['عدد الجلسات',S.logs.length],['أيام الاستمرارية',streak()],['مهام ناجحة',c.mastered],['تحتاج مراجعة',c.light],['متعثرة',c.hard],['مراجعات الأجزاء',Object.values(S.juz||{}).reduce((a,j)=>a+(j.n||0),0)]]);
  o+=H('سجل الجلسات')+T(['#','التاريخ','اليوم','الوقت','المهمة','المدة (د)','التقييم'],S.logs.slice(-200).reverse().map((l,i)=>[i+1,l.date,l.day,l.time,esc(l.s||'—'),l.dur,(BADGE[l.r]||['','—'])[1]]))}
 if(k=='all'||k=='juz'){const J=S.juz||{};o+=H('جدول الأجزاء')+T(['الجزء','عدد المراجعات','آخر مراجعة'],[...Array(30)].map((_,i)=>{const j=J[i+1]||{};return[i+1,j.n||0,j.last?ymd(new Date(j.last)):'—']}))}
 if(k=='all'||k=='ct'){const C=allC();if(C.length)o+=H('المتسابقون')+T(['الاسم','الأجزاء المطلوبة','الأجزاء المسموعة','الوقت','المعدل لكل جزء'],C.map(c=>[esc(c.name),c.juz.map(uLbl).join('، '),c.heard.length+' ('+c.heard.map(uLbl).join('، ')+')',c.fin?fmt(c.el):'—',c.fin&&c.heard.length?fmt(Math.round(c.el/c.heard.length)):'—']))}
 if(k=='all'||k=='prw')o+=prRepW(T,H,K);if(k=='all'||k=='pr')o+=prRepM(T,H);if(k=='all'||k=='pry')o+=prRepY(T,H);if(k=='all'||k=='td')o+=repTd(T,H);if(k=='all'||k=='arc')o+=repArc(T,H);if(k=='wk')o+=repWk(T,H,K);
 if(dx)return o.replace(/<div[^>]*>([\s\S]*?)<\/div>/g,(m,t)=>dxP(dxRun(stripT(t),{c:'666666',sz:18})));
 return o+`<div style="text-align:center;font-size:11px;color:#7a877d;margin-top:22px;padding-top:8px;border-top:1px solid #d6dcd8">أُنشئ بواسطة تطبيق مُثبِّت القرآن • ${ymd(now)}</div></div>`}
function repTd(T,H){const L=(S.td||[]).concat(S.tda||[]),P=((S.pv||{}).items||[]).length;return L.length?H('قائمة المهمات')+T(['المهمة','الحالة','أُضيفت','أُنجزت'],L.map(x=>[esc(x.t),x.s==1?'✓ صح':x.s==2?'✗ غلط':'—',x.c?ymd(new Date(x.c)):'—',x.at?ymd(new Date(x.at)):'—']))+(P?'<div style="font-size:12px;color:#555">المهام الخاصة (محمية بكلمة سر) غير مضمّنة في التقرير.</div>':''):''}
function repArc(T,H){const A=(S.arc||[]).slice().reverse();return A.length?H('أرشيف المراجعة والحفظ')+T(['المهمة','النوع','التاريخ','المستغرق','الزائد','الأصلي'],A.map(a=>[esc(a.name),arTy(a)||'—',ymd(new Date(a.en))+' '+hm(new Date(a.en)),hms(a.us),hms(a.ov||0),a.og?hms(a.og):'—'])):''}
const dxLang=b=>{if(S.lang!=='en')return b;return b.replace(/(<w:t[^>]*>)([^<]*)(<\/w:t>)/g,(m,a,t,c)=>a+xe(trs(t.replace(/&quot;/g,'"').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&')))+c).replace(/<w:bidi\/>|<w:bidiVisual\/>|<w:rtl\/>/g,'')};
function exportWord(k){dlBlob(docxFiles(dxLang(repHtml(k,'docx'))),'qmrm-report-'+k+'-'+ymd(new Date())+'.docx',DOCX_MIME);toast('تم حفظ ملف Word (docx)')}
/* ---------- تصدير الدفتر (PDF / Word) بشكل مطابق للصفحة: الخطوط والألوان والتمييز والصور ---------- */
function nbRunsOf(el,inh,out){[...el.childNodes].forEach(c=>{if(c.nodeType===3){if(c.nodeValue)out.push({t:c.nodeValue,c:inh.c,f:inh.f})}else if(c.nodeType===1){if(c.tagName==='BR'){out.push({br:1});return}const st=c.style||{};nbRunsOf(c,{c:st.color||(c.tagName==='A'?'#1565c0':inh.c),f:(st.fontFamily&&st.fontFamily.replace(/"/g,"'"))||inh.f},out)}});return out}
function nbAvail(n,row,lh,W,pad){let xl=pad,xr=W-pad;const y0=row*lh,y1=(row+1)*lh;(n.im||[]).forEach(o=>{const c=o.c||{l:0,t:0,r:0,b:0},cw=1-c.l-c.r,ch=1-c.t-c.b,h=o.w/(o.ar*cw/ch)*W,top=o.y*W,bot=top+h;if(y1>top&&y0<bot){if((o.x+o.w/2)<.5)xl=Math.max(xl,(o.x+o.w)*W+4);else xr=Math.min(xr,o.x*W-4)}});return[xl,xr]}
function nbWrap(runs,avail,meas,row0){const A=typeof avail=='function'?avail:()=>avail,lines=[];let row=row0||0,line=[],lw=0;const room=()=>{let w=A(row),g=0;while(w<40&&g++<80){row++;w=A(row)}return w};let cap=room();
 const flush=()=>{line.row=row;lines.push(line);line=[];lw=0;row++;cap=room()};
 runs.forEach(r=>{if(r.br){flush();return}r.t.split(/(\s+)/).forEach(tk=>{if(!tk)return;const w=meas(r.f,tk),sp=/^\s+$/.test(tk);if(!sp&&lw+w>cap&&line.some(x=>!/^\s+$/.test(x.t)))flush();if(sp&&!line.length)return;line.push({t:tk,c:r.c,f:r.f,w});lw+=w})});
 if(line.length||!lines.length){line.row=row;lines.push(line);row++}lines.next=row;return lines}
function nbRule(c,paper,W,H,lh,ln){c.strokeStyle=ln;c.fillStyle=ln;c.lineWidth=1;const hl=y=>{c.beginPath();c.moveTo(0,y+.5);c.lineTo(W,y+.5);c.stroke()};
 if(paper=='lined'||paper=='school'){for(let y=lh-1;y<=H;y+=lh)hl(y);if(paper=='school'){c.fillStyle='#e57373';c.fillRect(W-3,0,3,H)}}
 else if(paper=='grid'){for(let y=0;y<=H;y+=lh)hl(y);for(let x=0;x<=W;x+=lh){c.beginPath();c.moveTo(x+.5,0);c.lineTo(x+.5,H);c.stroke()}}
 else if(paper=='dot'){for(let y=lh/2;y<H;y+=lh)for(let x=lh/2;x<W;x+=lh){c.beginPath();c.arc(x,y,1.3,0,6.2832);c.fill()}}
 else if(paper=='en'){for(let y0=0;y0<H;y0+=lh){hl(y0+Math.round(lh*.18));hl(y0+lh-1);c.setLineDash([5,4]);hl(y0+Math.round(lh*.55));c.setLineDash([])}}}

const NBSH=[['','〰️ عادي'],['star','⭐ نجمة'],['spark','✨ لمعة'],['bow','🎀 فيونكة'],['heart','❤️ قلب'],['snow','❄️ ندفة'],['flower','🌸 زهرة'],['pac','🟡 نقاط'],['math','➕ رياضيات']];let nbShape='';
const nbHeart=(g,R)=>{g.moveTo(0,R*.8);g.bezierCurveTo(-R*1.3,-R*.1,-R*.7,-R*1,0,-R*.4);g.bezierCurveTo(R*.7,-R*1,R*1.3,-R*.1,0,R*.8);g.fill()},
 nbStar=(g,R,k)=>{g.beginPath();for(let j=0;j<10;j++){const r=j%2?R*k:R,a=-Math.PI/2+j*Math.PI/5;g[j?'lineTo':'moveTo'](Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill()};
const NBSHF={
 star:(g,i,z)=>{g.rotate(i%2?.3:-.3);nbStar(g,z/2,.45);return z*1.15},
 spark:(g,i,z)=>{const R=(i%2?z*.28:z*.5);g.moveTo(0,-R);g.quadraticCurveTo(0,0,R,0);g.quadraticCurveTo(0,0,0,R);g.quadraticCurveTo(0,0,-R,0);g.quadraticCurveTo(0,0,0,-R);g.fill();return R*2+z*.25},
 bow:(g,i,z)=>{if(i%5){g.arc(0,0,Math.max(1.2,z*.07),0,7);g.fill();return z*.4}const R=z*.55;g.moveTo(0,0);g.lineTo(-R,-R*.6);g.lineTo(-R,R*.6);g.closePath();g.moveTo(0,0);g.lineTo(R,-R*.6);g.lineTo(R,R*.6);g.closePath();g.fill();g.beginPath();g.arc(0,0,R*.28,0,7);g.fill();return z*1.1},
 heart:(g,i,z)=>{nbHeart(g,z*.45);g.save();g.translate(z*.5,z*.3);g.globalAlpha=.55;g.beginPath();nbHeart(g,z*.2);g.restore();return z*1.25},
 snow:(g,i,z)=>{const R=z*.5;g.lineWidth=Math.max(1.2,z*.08);for(let j=0;j<3;j++){g.save();g.rotate(j*Math.PI/3);g.moveTo(-R,0);g.lineTo(R,0);for(const sg of[-1,1]){g.moveTo(sg*R*.62,0);g.lineTo(sg*R*.82,-R*.22);g.moveTo(sg*R*.62,0);g.lineTo(sg*R*.82,R*.22)}g.restore()}g.stroke();return z*1.2},
 flower:(g,i,z)=>{const R=z*.5;for(let j=0;j<5;j++){const a=j*Math.PI*2/5-Math.PI/2;g.moveTo(Math.cos(a)*R*.55+R*.45,Math.sin(a)*R*.55);g.arc(Math.cos(a)*R*.55,Math.sin(a)*R*.55,R*.45,0,7)}g.fill();g.save();g.fillStyle='rgba(255,255,255,.92)';nbStar(g,R*.42,.5);g.restore();return z*1.2},
 pac:(g,i,z)=>{if(i%4){g.arc(0,0,z*.15,0,7);g.fill();return z*.85}g.moveTo(0,0);g.arc(0,0,z*.5,Math.PI+.5,Math.PI*3-.5);g.closePath();g.fill();return z*1.3},
 math:(g,i,z)=>{const R=z*.38,k=i%4;g.lineWidth=Math.max(1.5,z*.15);if(k==0){g.moveTo(-R,0);g.lineTo(R,0);g.moveTo(0,-R);g.lineTo(0,R)}else if(k==1){g.moveTo(-R,0);g.lineTo(R,0)}else if(k==2){g.moveTo(-R,-R);g.lineTo(R,R);g.moveTo(R,-R);g.lineTo(-R,R)}else{g.moveTo(-R,0);g.lineTo(R,0);g.moveTo(R*.02,-R*.85);g.lineTo(R*.02,-R*.85);g.moveTo(0,R*.85);g.lineTo(0,R*.85)}g.stroke();return z*1.1}};
function nbStamp(g,s,W){const P=s.p.map(([x,y])=>[x*W,y*W]),z=Math.max(12,s.w*5),F=NBSHF[s.sh];let i=0,adv=0;g.save();g.fillStyle=g.strokeStyle=s.c;g.lineCap=g.lineJoin='round';g.globalAlpha=1;
 const put=(x,y)=>{g.save();g.translate(x,y);g.beginPath();adv=Math.max(3,F(g,i++,z));g.restore()};
 put(P[0][0],P[0][1]);let need=adv;
 for(let k=1;k<P.length;k++){const[x0,y0]=P[k-1],[x1,y1]=P[k],L=Math.hypot(x1-x0,y1-y0);let pos=0;while(L-pos>=need){pos+=need;const t=pos/L;put(x0+(x1-x0)*t,y0+(y1-y0)*t);need=adv}need-=L-pos}
 g.restore()}

function nbStroke(g,s,W){if(s.sh&&NBSHF[s.sh])return nbStamp(g,s,W);g.beginPath();g.lineCap='round';g.lineJoin='round';g.strokeStyle=s.c;g.lineWidth=s.w;g.globalAlpha=1;s.p.forEach(([x,y],j)=>j?g.lineTo(x*W,y*W):g.moveTo(x*W,y*W));if(s.p.length==1)g.lineTo(s.p[0][0]*W+.1,s.p[0][1]*W);g.stroke()}
async function nbDrawText(c,b,n,f,lh,W,H,fg){const h=(n.h!=null&&n.h!=='')?nbClean(n.h):fromText(n.x),d=new DOMParser().parseFromString('<body>'+h+'</body>','text/html'),pad=12,avail=W-2*pad,rtl=S.lang!='en',base=f.ff,fs=f.fs,fam=new Set([base]);
 const blocks=[...d.body.children].map(el=>{const runs=nbRunsOf(el,{c:'',f:''},[]);runs.forEach(r=>{if(r.f)fam.add(r.f)});return{al:(el.style&&el.style.textAlign)||'start',runs}});
 try{await Promise.all([...fam].map(fm=>document.fonts.load(fs+'px '+fm,'اAa')))}catch(e){dbg(e)}
const meas=(ff,t)=>{c.font=fs+'px '+(ff||base);return c.measureText(t).width};let row=0;const AV=q=>{const a=nbAvail(n,q,lh,W,pad);return a[1]-a[0]};
 blocks.forEach(bl=>{const L=nbWrap(bl.runs,AV,meas,row);L.forEach(ln=>{const rr=ln.row,y=(rr+1)*lh-Math.round(lh*.3);if(y-lh>H)return;const[xl,xr]=nbAvail(n,rr,lh,W,pad),tw=ln.reduce((a,x)=>a+x.w,0),al=bl.al;
  let x=rtl?(al=='center'?(xl+xr+tw)/2:al=='end'?xl+tw:xr):(al=='center'?(xl+xr-tw)/2:al=='end'?xr-tw:xl);
  ln.forEach(sg=>{c.font=fs+'px '+(sg.f||base);c.fillStyle=sg.c||fg;c.direction=rtl?'rtl':'ltr';c.textAlign='left';if(rtl){x-=sg.w;c.fillText(sg.t,x,y)}else{c.fillText(sg.t,x,y);x+=sg.w}})});row=L.next})}
async function nbDrawObj(c,o,W){const im=new Image();await new Promise(r=>{im.onload=r;im.onerror=r;im.src=o.src});if(!im.width)return;const k=o.c||{l:0,t:0,r:0,b:0},cw=1-k.l-k.r,ch=1-k.t-k.b,vis=o.ar*cw/ch,w=o.w*W;c.drawImage(im,k.l*im.width,k.t*im.height,cw*im.width,ch*im.height,o.x*W,o.y*W,w,w/vis)}
async function nbRenderPage(b,n){const f=nbF(b,n),lh=Math.round(f.fs*1.9),H=lh*17,W=b.pw||330,sc=2,pp=nbPP(b,n),dk=pp.pc&&lum(pp.pc)<.4,fg=pp.pc?(dk?'#eceff1':'#222'):'#222',ln=pp.pc?(dk?'rgba(255,255,255,.22)':'rgba(0,0,0,.16)'):'#cfd8d2';
 const cv=document.createElement('canvas');cv.width=W*sc;cv.height=H*sc;const c=cv.getContext('2d');c.scale(sc,sc);c.fillStyle=pp.pc||'#ffffff';c.fillRect(0,0,W,H);nbRule(c,pp.paper,W,H,lh,ln);
 const hs=(n.sk||[]).filter(s=>s.k=='h');if(hs.length){const t=document.createElement('canvas');t.width=W*sc;t.height=H*sc;const g=t.getContext('2d');g.scale(sc,sc);hs.forEach(s=>nbStroke(g,s,W));c.globalAlpha=.42;c.drawImage(t,0,0,W,H);c.globalAlpha=1}
 await nbDrawText(c,b,n,f,lh,W,H,fg);for(const o of(n.im||[]))await nbDrawObj(c,o,W);(n.sk||[]).filter(s=>s.k!='h').forEach(s=>nbStroke(c,s,W));
 c.strokeStyle='#b7c2ba';c.lineWidth=1;c.strokeRect(.5,.5,W-1,H-1);return cv}
async function nbExport(kind){const b=nbK();toast('جارٍ تجهيز الملف...');try{await document.fonts.ready}catch(e){dbg(e)}
 const cvs=[];for(const n of b.notes)cvs.push(await nbRenderPage(b,n));
 if(kind=='pdf'){const v=$('#pv');v.innerHTML=`<div dir="${S.lang=='en'?'ltr':'rtl'}" style="font-family:system-ui,Tahoma,sans-serif"><div style="page-break-after:always;display:flex;flex-direction:column;align-items:center;padding-top:70px"><div style="width:300px">${cover(b,'')}</div><div style="font-size:22px;font-weight:700;margin-top:24px">${esc(b.name)}</div><div style="color:#666;margin-top:6px">${esc(b.desc||'')} • ${ymd(new Date())}</div></div>${cvs.map((c,i)=>`<div style="${i?'page-break-before:always;':''}text-align:center;padding-top:10px"><img alt="" src="${c.toDataURL('image/png')}" style="width:100%;max-width:720px;border-radius:4px"><div style="font-size:11px;color:#777;margin-top:6px">صفحة ${i+1} / ${cvs.length}</div></div>`).join('')}</div>`;
  window.addEventListener('afterprint',()=>{v.innerHTML=''},{once:true});setTimeout(()=>window.print(),120);return}
 const imgs=[];let body=dxP(dxRun(b.name,{b:1,sz:44}),{al:'center',sp:[200,100]})+(b.desc?dxP(dxRun(b.desc,{c:'666666',sz:22}),{al:'center'}):'');
 cvs.forEach((c,i)=>{const d=c.toDataURL('image/png').split(',')[1],bin=atob(d),by=new Uint8Array(bin.length);for(let q=0;q<bin.length;q++)by[q]=bin.charCodeAt(q);const cx=5900000,cy=Math.round(cx*c.height/c.width),name='p'+(i+1)+'.png';imgs.push({rid:'rIdI'+(i+1),name,data:by});body+=dxP(dxImg('rIdI'+(i+1),cx,cy,i+1),{al:'center',pb:true})});
 dlBlob(docxFiles(body,imgs),'notebook-'+ymd(new Date())+'.docx',DOCX_MIME);toast('تم حفظ ملف Word (docx)')}
function printReport(k){const v=$('#pv');v.innerHTML=repHtml(k);window.addEventListener('afterprint',()=>{v.innerHTML=''},{once:true});setTimeout(()=>window.print(),80)}

/* ---------- متتبع الصلاة ---------- */
const PN=['الفجر','الظهر','العصر','المغرب','العشاء'],PK=['f','d','a','m','i'];let prY=0,prM=0,prD=1;
const prP=()=>S.pr||(S.pr={start:'',days:{}});
const dkey=(y,m,d)=>y+'-'+String(m+1).padStart(2,'0')+'-'+String(d).padStart(2,'0');
const prQ=k=>{const d=prP().days[k]||{};return PK.every(p=>!d[p]||!d[p].s)};
function prSum(P,today){const tdr=P.days[today]||{},ok=r=>r&&r.s&&r.s!='x',dn=PK.filter(p=>ok(tdr[p])).length;let fs=0;for(let i=0;i<90;i++){const k=ymd(new Date(Date.now()-i*864e5)),r=P.days[k]||{};if(PK.every(p=>ok(r[p])))fs++;else if(i>0)break;else continue}
 return `<section class="hero"><div class="hr-t"><div><div class="hr-g">صلوات اليوم</div><div class="hr-d">${dn} من ${PK.length}</div><div class="hr-m">${fs} يوم متتالٍ بصلوات كاملة</div></div><div class="dots">${PK.map(p=>`<i class="${ok(tdr[p])?'on':''}"></i>`).join('')}</div></div></section>`}
function prayer(){if(!prY){const n=new Date();prY=n.getFullYear();prM=n.getMonth();prD=n.getDate()}
 const P=prP(),dim=new Date(prY,prM+1,0).getDate(),fd=new Date(prY,prM,1).getDay(),today=ymd(new Date()),cur=new Date().getFullYear();if(prD>dim)prD=dim;
 const en=S.lang=='en',MN=[...Array(12)].map((_,i)=>new Date(2000,i,1).toLocaleDateString(en?'en-US':'ar-SY',{month:'long'})),WD=D.map(x=>x.replace('ال','').slice(0,3)),ys=[];for(let y=Math.min(cur-10,prY);y<=Math.max(cur+30,prY);y++)ys.push(y);
 let cells='<div></div>'.repeat(fd),c={m:0,h:0,x:0,u:0,ot:0,ft:0};
 for(let d=1;d<=dim;d++){const k=dkey(prY,prM,d),rec=P.days[k]||{},tr=P.start&&k>=P.start&&k<=today,q=tr&&prQ(k),full=PK.every(p=>rec[p]&&rec[p].s&&rec[p].s!='x');
  if(tr)PK.forEach(p=>{const e=rec[p];if(!e||!e.s)c.u++;else{c[e.s]++;if(e.s!='x'){if(e.t==1)c.ot++;if(e.t==2)c.ft++}}});
  cells+=`<div class="pd${P.start===k?' st':''}${rec.note?' pn':''}${d===prD?' sel':''}${k>today?' fu':''}" onclick="prD=${d};draw()">${d}${q?'<span class="pq">?</span>':''}${(tr&&full&&!q)?'<span class="pk"></span>':''}</div>`}
 const dd=P.days[dkey(prY,prM,prD)]||{},ks=dkey(prY,prM,prD);
 return `<div class="row sp ptl"><b>متتبع الصلاة</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>
 ${prSum(P,today)}${prRemCard()} <div class="c"><div class="row sp" style="flex-wrap:nowrap"><button type="button" class="pbtn bk" onclick="prNav(-1)">${svg('chev')}</button><div class="row" style="flex-wrap:nowrap;gap:6px"><select onchange="prM=+this.value;draw()" style="margin:0">${MN.map((n,i)=>`<option value="${i}" ${i==prM?'selected':''}>${n}</option>`).join('')}</select><select onchange="prY=+this.value;draw()" style="margin:0">${ys.map(y=>`<option ${y==prY?'selected':''}>${y}</option>`).join('')}</select></div><button type="button" class="pbtn" onclick="prNav(1)">${svg('chev')}</button></div>
 <div class="row sp" style="margin-top:10px;cursor:pointer" onclick="prOpen=!prOpen;draw()"><span class="m">${prOpen?'▴':'▾'} الأيام</span><span class="m">اليوم المحدد: ${prD}</span></div>${prOpen?`<div class="pcal m" style="margin:6px 0 4px">${WD.map(x=>`<div>${x}</div>`).join('')}</div><div class="pcal">${cells}</div>`:''}
 <div class="row" style="margin-top:10px"><button type="button" style="flex:1" onclick="prStart()">${P.start===ks?'هذا يوم البداية':'تعيين هذا اليوم كيوم بداية'}</button></div><div class="m" style="margin-top:6px">${P.start?'يوم البداية: '+P.start+' (يظهر باللون الأخضر). الأيام التي لم يُسجَّل فيها أي شيء تظهر عليها علامة ؟':'اختر يوماً ثم اضغط «تعيين هذا اليوم كيوم بداية» ليبدأ التتبع.'}</div></div>
 <div class="c"><b>${D[new Date(prY,prM,prD).getDay()]} • ${ks}</b><table class="pt" style="margin-top:6px"><tr><th>الصلاة</th><th>في الجامع</th><th>في البيت</th><th>لم أصلها</th><th>بوقتها؟</th></tr>${PK.map((p,i)=>{const e=dd[p]||{},s=e.s||'';return `<tr><td><b>${PN[i]}</b></td><td class="pc ${s=='m'?'g':''}" onclick="prSet('${p}','m')">${s=='m'?svg('check'):''}</td><td class="pc ${s=='h'?'y':''}" onclick="prSet('${p}','h')">${s=='h'?svg('check'):''}</td><td class="pc ${s=='x'?'r':''}" onclick="prSet('${p}','x')">${s=='x'?svg('check'):''}</td><td>${s&&s!='x'?mk2(e.t||0,`prT('${p}',1)`,`prT('${p}',2)`):'—'}</td></tr>`}).join('')}</table><div class="m" style="margin-top:6px">في الجامع = أخضر • في البيت = أصفر • لم أصلها = أحمر • ✓ بوقتها / ✗ خارج الوقت</div>
 <div class="m" style="margin-top:12px">📝 ملاحظة هذا اليوم</div><textarea id="prn" class="prn" placeholder="اكتب ملاحظتك عن هذا اليوم (مثلاً: صليت الفجر متأخراً بسبب...)" oninput="prNote(this.value)">${esc(dd.note||'')}</textarea></div>
 <div class="c"><b>ملخص ${MN[prM]} ${prY}</b><div class="row" style="margin-top:6px"><span class="chip" style="background:#2e7d32;color:#fff">جامع ${c.m}</span><span class="chip" style="background:#f9a825">بيت ${c.h}</span><span class="chip" style="background:#e53935;color:#fff">لم تُصلَّ ${c.x}</span><span class="chip">غير مسجّل ${c.u}</span></div><div class="m" style="margin-top:6px">بوقتها ${c.ot} • خارج الوقت ${c.ft}</div></div>
 <div class="c"><button type="button" onclick="printReport('prw')" style="width:100%">${svg('file')} تقرير الأسبوع PDF</button><button type="button" class="g" onclick="printReport('pr')" style="width:100%;margin-top:6px">تقرير الشهر PDF</button><button type="button" class="g" onclick="printReport('pry')" style="width:100%;margin-top:6px">تقرير السنة PDF</button></div>`}
function prNav(d){prM+=d;if(prM<0){prM=11;prY--}else if(prM>11){prM=0;prY++}prD=1;draw()}
let prOpen=false;
function prStart(){const P=prP(),k=dkey(prY,prM,prD);if(P.start===k)return;if(!P.start){P.start=k;save();draw();return}
 $('#sh').innerHTML=shW(`<b>تغيير يوم البداية</b><div class="m" style="margin:6px 0">يوم البداية الحالي ${P.start} وسيصبح ${k}. هل تريد التغيير؟ اكتب (تأكيد) للتغيير.</div><input id="prc" placeholder="تأكيد" autocomplete="off"><div id="prm" class="m" style="color:var(--bad)"></div><button type="button" onclick="prStartDo('${k}')">تغيير</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
const isConf=v=>{v=String(v).trim().toLowerCase();return v==='تأكيد'||v==='confirm'};
function prStartDo(k){if(!isConf($('#prc').value)){$('#prm').textContent='اكتب كلمة: تأكيد';return}prP().start=k;save();$('#sh').innerHTML='';draw()}
function prSet(p,s){const P=prP(),k=dkey(prY,prM,prD),d=P.days[k]=P.days[k]||{},old=(d[p]||{}).s;chg(old,()=>{const e=d[p]=d[p]||{};e.s=e.s==s?'':s;if(e.s=='x')e.t=0;if(!e.s)delete d[p];save();draw()})}
function prNote(v){const P=prP(),k=dkey(prY,prM,prD),d=P.days[k]=P.days[k]||{};if(String(v).trim())d.note=String(v).slice(0,2000);else{delete d.note;if(!Object.keys(d).length)delete P.days[k]}
 try{const el=document.querySelector('.pd.sel');if(el&&el.classList)el.classList.toggle('pn',!!d.note)}catch(e){dbg(e)}nbSv()}
const prNoteTbl=(T,H,title,days)=>{const P=prP(),rows=days.map(k=>[k,D[new Date(k+'T00:00:00').getDay()],esc((P.days[k]||{}).note||'').replace(/\n/g,'<br>')]).filter(r=>r[2]);return rows.length?H(title)+T(['التاريخ','اليوم','الملاحظة'],rows):''};
function prT(p,v){const e=((prP().days[dkey(prY,prM,prD)])||{})[p];if(!e||!e.s||e.s=='x')return;chg(e.t,()=>{e.t=e.t==v?0:v;save();draw()})}
const PSL={m:'<span style="display:block;background:#c8e6c9">جامع</span>',h:'<span style="display:block;background:#fff59d">بيت</span>',x:'<span style="display:block;background:#ffcdd2">لم تُصلَّ</span>'};
function prRepM(T,H){const P=prP(),dim=new Date(prY,prM+1,0).getDate(),today=ymd(new Date()),MN=new Date(prY,prM,1).toLocaleDateString(S.lang=='en'?'en-US':'ar-SY',{month:'long'});
 const rows=[...Array(dim)].map((_,i)=>{const d=i+1,k=dkey(prY,prM,d),rec=P.days[k]||{},tr=P.start&&k>=P.start&&k<=today;return[d+(tr&&prQ(k)?' ؟':''),D[new Date(prY,prM,d).getDay()],...PK.map(p=>{const e=rec[p];return e&&e.s?PSL[e.s]+(e.s!='x'&&e.t?(e.t==1?'✓':'✗'):''):'—'})]});
 return H('تقرير الصلاة — '+MN+' '+prY)+T(['اليوم','','الفجر','الظهر','العصر','المغرب','العشاء'],rows)+'<div style="font-size:12px;color:#555">✓ بوقتها • ✗ خارج الوقت • ؟ يوم لم يُسجَّل فيه شيء</div>'+prNoteTbl(T,H,'ملاحظات الشهر',[...Array(dim)].map((_,i)=>dkey(prY,prM,i+1)))}
function prRepW(T,H,K){const P=prP(),today=ymd(new Date()),b=new Date(prY,prM,prD),ws=new Date(b.getFullYear(),b.getMonth(),b.getDate()-b.getDay()),we=new Date(ws.getFullYear(),ws.getMonth(),ws.getDate()+6),c={m:0,h:0,x:0,u:0,ot:0,ft:0};
 const rows=[...Array(7)].map((_,i)=>{const d=new Date(ws.getFullYear(),ws.getMonth(),ws.getDate()+i),k=dkey(d.getFullYear(),d.getMonth(),d.getDate()),rec=P.days[k]||{},tr=P.start&&k>=P.start&&k<=today;
  return[ymd(d)+(tr&&prQ(k)?' ؟':''),D[d.getDay()],...PK.map(p=>{const e=rec[p];if(tr){if(!e||!e.s)c.u++;else{c[e.s]++;if(e.s!='x'){if(e.t==1)c.ot++;if(e.t==2)c.ft++}}}return e&&e.s?PSL[e.s]+(e.s!='x'&&e.t?(e.t==1?'✓':'✗'):''):'—'})]});
 return H('تقرير الصلاة — الأسبوع من '+ymd(ws)+' إلى '+ymd(we))+K([['في الجامع',c.m],['في البيت',c.h],['لم تُصلَّ',c.x],['غير مسجّل',c.u],['بوقتها',c.ot],['خارج الوقت',c.ft]])+T(['التاريخ','اليوم','الفجر','الظهر','العصر','المغرب','العشاء'],rows)+'<div style="font-size:12px;color:#555">✓ بوقتها • ✗ خارج الوقت • ؟ يوم لم يُسجَّل فيه شيء</div>'+prNoteTbl(T,H,'ملاحظات الأسبوع',[...Array(7)].map((_,i)=>{const d=new Date(ws.getFullYear(),ws.getMonth(),ws.getDate()+i);return dkey(d.getFullYear(),d.getMonth(),d.getDate())}))}
function prRepY(T,H){const P=prP(),today=ymd(new Date());
 const rows=[...Array(12)].map((_,m)=>{const dim=new Date(prY,m+1,0).getDate(),c={m:0,h:0,x:0,u:0,ot:0,ft:0};for(let d=1;d<=dim;d++){const k=dkey(prY,m,d),rec=P.days[k]||{};if(!(P.start&&k>=P.start&&k<=today))continue;PK.forEach(p=>{const e=rec[p];if(!e||!e.s)c.u++;else{c[e.s]++;if(e.s!='x'){if(e.t==1)c.ot++;if(e.t==2)c.ft++}}})}return[new Date(prY,m,1).toLocaleDateString(S.lang=='en'?'en-US':'ar-SY',{month:'long'}),c.m,c.h,c.x,c.u,c.ot,c.ft]});
 const sm=rows.reduce((a,r)=>a.map((x,i)=>i?x+r[i]:x),['المجموع',0,0,0,0,0,0]);
 return H('تقرير الصلاة السنوي — '+prY)+T(['الشهر','في الجامع','في البيت','لم تُصلَّ','غير مسجّل','بوقتها','خارج الوقت'],[...rows,sm.map(x=>'<b>'+x+'</b>')])}
/* ---------- القائمة الجانبية ---------- */
const prof=()=>S.profile||(S.profile={name:'',age:'',gender:''});
function menu(){const P=prof(),R=(f,i,t,x)=>`<a onclick="${f}"><span class="di">${svg(i)}</span><div><b>${t}</b><small>${x}</small></div><span class="ch">${svg('chev')}</span></a>`;
 $('#sh').innerHTML=`<div class="sh dr" onclick="if(event.target==this)$('#sh').innerHTML=''"><aside><div class="dh"><div class="av">${avatar()}</div><b style="font-size:18px">${esc(P.name||(fu&&fu.displayName)||'ضيف')}</b><div style="font-size:13px;opacity:.85;margin-top:3px" dir="ltr">${fu?esc(fu.email||''):'غير مسجّل الدخول'}</div></div>${accBar()}
 <div class="dsec">الدفتر</div>${R("go2('nb')",'notebook','الدفتر','دفاترك وصفحاتك')}
 <div class="dsec">الحساب</div>${R("go2('se')",'user','معلومات الحساب','الملف الشخصي وتسجيل الدخول')}${R("go2('re')",'bell','الإشعارات','تذكيرات بمهامك وأوقاتها')}${R("go2('bk')",'download','النسخ الاحتياطي والتقارير','ملف على جهازك وتصدير PDF')}
 <div class="dsec">الحفظ</div>${R("go2('wr')",'book','الورد اليومي','كم تحفظ كل يوم')}${R("go2('kh')",'moon','ختمة رمضان','ختم القرآن بكمية يومية')}${R("go2('hp')",'pin','الصفحات الصعبة','صفحات تُراجَع أكثر')}
 <div class="dsec">المراجعة والمتابعة</div>${R("go2('rv')",'repeat','جدول المراجعة','ما تراجعه اليوم وغداً')}${R("go2('jz')",'grid','الجداول','مراجعات كل جزء')}${R("go2('jm')",'mapfold','خريطة الأجزاء','حالة كل جزء بلون')}${R("go2('st')",'chart','الإحصائيات','تقدّمك وجلساتك')}
 <div class="dsec">المسابقات</div>${R("go2('ct')",'users','المتسابقون','الأجزاء والتايمر والإحصائيات')}${R("go2('ex')",'clipcheck','الاختبارات','سحب المواضع وتقييم الأخطاء')}
 <div class="dsec">اللغة والمظهر</div>${R("go2('ap')",'palette','اللغة والمظهر','الوضع الليلي والألوان واللغة')}</aside></div>`}
function go2(t){$('#sh').innerHTML='';if(t=='nb')nbCur=0;go(t)}

/* ====================== EXAM-NOTES: دليل قسم «الاختبارات» ======================
 الغرض: قسم تدريبي مستقل (بلا حساب ولا سيرفر): أضف متسابقاً ← سحب مواضع من القرآن ← تقييم الأخطاء ← اعتماد العلامة.
 بعد الاعتماد تبقى المواضع والأخطاء محفوظة، ويمكن مراجعتها (وضع القراءة فقط exRO) أو إعادة فتحها للتعديل (exEdit).

 [1] الملفات والاستضافة
 - التطبيق ملف واحد: index.html (هذا الملف) على Firebase Hosting، ومرتبط بمستودع GitHub باسم quran-app.
 - صور المصحف (604 صورة WebP باسم 001.webp ... 604.webp، عرض كل صورة 600px) في مستودع GitHub منفصل اسمه quran-pages،
   ومنشورة بـ GitHub Pages. الرابط الأساسي هو الثابت EXIMG أدناه، ويقرأ التطبيق كل صفحة عند الحاجة فقط.
 - هذا المستودع غير موجود داخل الملف، لا يلزم معرفته: يكفي أن يبقى الرابط في EXIMG صحيحاً. إن نُقلت الصور غيّر EXIMG فقط.
   (إن تُرك EXIMG فارغاً يبحث التطبيق عن مجلد quran-pages بجانب الملف).
 - الصور مأخوذة من PDF مصحف المدينة (نسخة 604 صفحة): الصفحتان 1 و2 مزخرفتان (8 أسطر)، وباقي الصفحات 15 سطراً.

 [2] مصدر البيانات
 - نص الآيات وحدودها وأرقام الأسطر من واجهة quran.com المجانية: GET https://api.quran.com/api/v4/verses/by_page/{page}?words=true&word_fields=text_uthmani,line_number,page_number
   تحتاج إنترنت وقت السحب فقط. لا تعتمد على أي مفتاح.
 - مهم: لا نثق بأرقام الأسطر الخام من الواجهة (ترقيمها يختلف في العناوين والبسملة). دالة exSlots تعيد حسابها من ترتيب الأسطر الفعلي،
   وتضيف سطر العنوان وسطر البسملة عند بداية كل سورة (سورة التوبة والفاتحة: سطر العنوان فقط). لا تُبسّط هذه الدالة.

 [3] نموذج البيانات (يُحفظ في S.ex عبر save())
 S.ex={list:[...], seat:رقم الجلوس التالي, draws:عداد السحوبات}
 متسابق={id,name,seat,level,pos?,cur?,draw?,done?,score?}
 موضع={j:رقم الجزء, segs:[{p:رقم الصفحة,l1:أول سطر,l2:آخر سطر}] (واحدة أو اثنتان), fc,fv:من سورة/آية, tc,tv:إلى سورة/آية,
        words,lines, m:{h,l,t,r,c}:عدّاد الأخطاء, n:ملاحظة, d:1 إن انتهى الموضع}
 - مواضع قديمة بلا segs تُحوَّل تلقائياً عبر exN.
 - الخصم: حفظ 2 · لغة 2 · تجويد 1 · تردد 0.2 · تغيير موضع 10 (الثابت EXT). العلامة = 100 - مجموع الخصم (لا تقل عن 0).

 [4] خوارزمية السحب (exMake ← exBuild)
 - يُختار جزء ثم صفحة عشوائية منه بلا تكرار (exPick) بمولّد Web Crypto (exRnd)، ثم أول آية تبدأ في الصفحة عشوائياً.
 - يتوسع الموضع آية بآية حتى يبلغ 8 أسطر فأكثر وينتهي عند نهاية آية، وقد يمتد للصفحة التالية فيصير segs من عنصرين.
 - عنوان السورة والبسملة يدخلان في التظليل إذا بدأ الموضع من الآية 1.

 [5] هندسة المربع الأصفر (exGeo) — قياسات حقيقية من الصور
 - الصور بعرض أصلي 750: الصفحات 3 إلى 61 ارتفاعها 1177، والباقي 1072. الأسطر الخمسة عشر متساوية الارتفاع.
 - إطار بعض الصفحات مزاح أفقياً (زخرفة الحزب)، والسلسلة EXGC فيها حرف لكل صفحة (0 عادي · 1 مزاح يميناً · 2 مزاح يساراً)
   تقابل الإزاحات EXGX. الصفحتان 1 و2 لهما قياسات خاصة داخل exGeo. إن استُبدلت الصور بنسخة أخرى يجب إعادة قياس هذه القيم.

 [6] الواجهة
 - قائمة المتسابقين: exList. ورقة المواضع بعد السحب: exPaper (فيها طباعة/PDF). شاشة الاختبار: طبقة fixed واحدة #exOv
   (شريط علوي #exTop، دوائر المواضع #exStrip، المحتوى #exBody، شريط سفلي #exFoot) تُرسم مرة واحدة ثم تُحدَّث في مكانها
   (exUpd, exViewer, exTmUI) دون draw() كي لا تقفز الصفحة. لا تستدعِ draw() أثناء الاختبار.
 - لا تستخدم confirm() أو prompt(): تعرضان اسم الموقع. استخدم exDlg (نافذة من التطبيق، ترجع Promise).
 - زر الرجوع في الجوال مضبوط في bbStep: يغلق النافذة ثم الورقة ثم الاختبار.
 - الألوان من متغيرات الثيم (--pri و--card و--bd ...) فتعمل مع الوضع الليلي. تنسيقات القسم كلها تبدأ بـ .ex أو #ex قرب @media print.

 [7] ما اختُبر وما لم يُختبر
 - اختُبر في Chromium مع بيانات مقلَّدة: السحب، الامتداد لصفحتين، حساب الأسطر بثلاث طرق ترقيم، التحديث في المكان، التراجع،
   تغيير الموضع، المراجعة والاعتماد، الوضع الليلي، زر الرجوع.
 - لم يُختبر مع واجهة quran.com الحية، ولا طباعة PDF على جوال. عند أي تظليل منزاح راجع exSlots أولاً ثم exGeo.
 ================================================================================= */
/* ---------- الاختبارات: سحب المواضع وتقييم الأخطاء ---------- */
const EXJ=[1,22,42,62,82,102,122,142,162,182,202,222,242,262,282,302,322,342,362,382,402,422,442,462,482,502,522,542,562,582];
const EXS=[1,2,50,77,106,128,151,177,187,208,221,235,249,255,262,267,282,293,305,312,322,332,342,350,359,367,377,385,396,404,411,415,418,428,434,440,446,453,458,467,477,483,489,496,499,502,507,511,515,518,520,523,526,528,531,534,537,542,545,549,551,553,554,556,558,560,562,564,566,568,570,572,574,575,577,578,580,582,583,585,586,587,587,589,590,591,591,592,593,594,595,595,596,596,597,597,598,598,599,599,600,600,601,601,601,602,602,603,603,603,604,604,604,604];
const EXT=[['h','خطأ الحفظ',2,'#2e7d32'],['l','خطأ اللغة',2,'#1565c0'],['t','خطأ التجويد',1,'#f9a825'],['r','التردد',.2,'#6a1b9a'],['c','تغيير الموضع',10,'#c62828']];
/* رابط مجلد صور المصحف (GitHub Pages) */
const EXIMG='https://ammar078aleid.github.io/quran-pages/';
const exSrc=n=>(EXIMG?EXIMG.replace(/\/?$/,'/'):'quran-pages/')+String(n).padStart(3,'0')+'.webp';
/* إزاحة إطار كل صفحة (0: عادي · 1: مزاح يميناً · 2: مزاح يساراً) — مقاسة من صور المصحف نفسها */
const EXGC='??00202020200100202001010020200101002020010101002020010100200101002020010100202001010020200101002001010101002001010020202001010020010100200101010101002001010100010100200100202120200101002020010101002020010100200101002020010101010020200101000101002020210101002001010020010100202001010100202001202020200101010020010020202001010100200101010020210100200101010100200101202020200100202001010100200101010020010100200100202101010100210020202001002001210100202001010020010100202001010020210101010100202001002001002020010020202020010101012020010100200101002001002100010101010120200100202120010020212020010101010000';
const EXGX=[125,164,85];
let exCur=0,exDid=0,exSel={},exTm=null,exLeft=20,exRun=false,exDur=20,exZoom=100,exCrop=0,exSeg=0,exSnd=1,exHist=[],exBusy=0;
const exRnd=n=>{const b=new Uint32Array(1),lim=4294967296-4294967296%n;do crypto.getRandomValues(b);while(b[0]>=lim);return b[0]%n};
const exRound=x=>Math.round(x*100)/100;
const exLo=j=>EXJ[j-1],exHi=j=>j<30?EXJ[j]-1:604,exPages=j=>exHi(j)-exLo(j)+1;
const exSur=p=>{let k=0;for(let i=0;i<114;i++)if(EXS[i]<=p)k=i;return SUR[k]};
function exPick(j,used){const lo=exLo(j),n=exPages(j);let p,g=0;do{p=lo+exRnd(n)}while(used.has(p)&&used.size<n&&++g<500);used.add(p);return p}
function exShuf(a){for(let i=a.length-1;i>0;i--){const k=exRnd(i+1);[a[i],a[k]]=[a[k],a[i]]}return a}
const exDed=m=>exRound(m.h*2+m.l*2+m.t*1+m.r*.2+m.c*10);
const exTot=e=>exRound((e.pos||[]).reduce((s,x)=>s+exDed(x.m),0));
const exMark=e=>Math.max(0,exRound(100-exTot(e)));
const exD=()=>S.ex=S.ex||{list:[],seat:1,draws:0};
const exGet=id=>exD().list.find(x=>x.id==id);
const exN=p=>{if(!p.segs)p.segs=[{p:p.p||1,l1:p.l1||1,l2:p.l2||15}];return p};
const exRng=p=>!p.fc?'سورة '+exSur(exN(p).segs[0].p):p.fc==p.tc?`${SUR[p.fc-1]} (${p.fv} - ${p.tv})`:`${SUR[p.fc-1]} (${p.fv}) إلى ${SUR[p.tc-1]} (${p.tv})`;
const exPgs=p=>{const s=exN(p).segs;return s.length>1?s[0].p+'–'+s[s.length-1].p:''+s[0].p};
const exLast=p=>p<=2?8:15;

/* ---- بيانات الصفحة من quran.com، مع حساب موضع كل سطر من ترتيبه الفعلي (لا من أرقام الواجهة) ---- */
const exCache=new Map();
function exSlots(vs,p){
 const raw=[...new Set(vs.flatMap(v=>v.w.map(w=>w.l)))].sort((a,b)=>a-b),slot=new Map();let off=0;
 raw.forEach((l,i)=>{vs.forEach(v=>{if(v.st&&v.n===1&&v.w[0].l===l)off+=1+(v.c!=1&&v.c!=9?1:0)});slot.set(l,i+1+off)});
 let k=(p<=2?8:15)-(raw.length+off);if(k<=0||(vs[0].st&&vs[0].n===1))k=0;
 vs.forEach(v=>v.w.forEach(w=>w.l=slot.get(w.l)+k))}
async function exPage(p){
 if(exCache.has(p))return exCache.get(p);
 const r=await fetch('https://api.quran.com/api/v4/verses/by_page/'+p+'?words=true&word_fields=text_uthmani,line_number,page_number&per_page=50');
 if(!r.ok)throw new Error('net');const j=await r.json();
 const vs=(j.verses||[]).map(v=>{const k=String(v.verse_key).split(':'),all=v.words||[],f=all[0],l=all[all.length-1];
  return{c:+k[0],n:+k[1],st:!f||f.page_number==null||f.page_number==p,en:!l||l.page_number==null||l.page_number==p,
   w:all.filter(w=>w.page_number==null||w.page_number==p).map(w=>({t:w.text_uthmani,l:w.line_number,e:w.char_type_name==='end'}))}}).filter(v=>v.w.length);
 if(!vs.length||vs.some(v=>v.w.some(w=>w.l==null)))throw new Error('empty');
 exSlots(vs,p);exCache.set(p,vs);return vs}
/* موضع دقيق: يبدأ من أول آية تبدأ في الصفحة، وينتهي عند نهاية آية، بطول 8 أسطر فأكثر، وقد يمتد لصفحتين */
async function exBuild(p){
 const A=await exPage(p),cand=A.map((v,i)=>i).filter(i=>A[i].st);if(!cand.length)return null;
 const a=cand[exRnd(cand.length)],first=A[a],segs=[];let last=first,total=0,words=0,page=p,vs=A,i=a,done=false;
 for(let g=0;g<3&&!done;g++){
  const seg={p:page,l1:g?1:null,l2:null};
  for(;i<vs.length;i++){const v=vs[i],ws=v.w;
   if(seg.l1===null)seg.l1=(v.st&&v.n===1)?Math.max(1,ws[0].l-(1+(v.c!=1&&v.c!=9?1:0))):ws[0].l;
   seg.l2=ws[ws.length-1].l;words+=ws.filter(w=>!w.e).length;last=v;
   if(v.en&&total+seg.l2-seg.l1+1>=8){done=true;i++;break}}
  if(seg.l1===null)break;
  if(!done&&page<604)seg.l2=exLast(page);
  segs.push(seg);total+=seg.l2-seg.l1+1;
  if(done||page>=604)break;
  page++;vs=await exPage(page);i=0}
 return{segs,fc:first.c,fv:first.n,tc:last.c,tv:last.n,words,lines:total}}
async function exMake(j,used,tries){let best=null;for(let k=0;k<(tries||8);k++){const p=exPick(j,used),r=await exBuild(p);
 if(r){const o={j,...r,m:{h:0,l:0,t:0,r:0,c:0},n:'',d:0};if(r.lines>=7)return o;if(!best||r.lines>best.lines)best=o}}return best}

/* ---- مكان المربع على صورة الصفحة (بكسل الصورة الأصلية، عرضها 750) ---- */
function exGeo(n,l1,l2){
 if(n<=2){const c=k=>k<=1?350:470+(k-2)*42.2,h=k=>k<=1?70:42.2,x=n==1?[105,545]:[245,645];return{H:1177,x0:x[0],x1:x[1],y0:c(l1)-h(l1)/2,y1:c(l2)+h(l2)/2}}
 const H=n<=61?1177:1072,top=n<=61?192:146,pt=n<=61?52.85:52.4,xl=EXGX[+EXGC[n-1]||0];
 return{H,x0:xl+3,x1:xl+498,y0:top+(l1-1)*pt,y1:top+l2*pt}}

/* ---- نوافذ حوار خاصة بالتطبيق (بدل نوافذ المتصفح التي تعرض اسم الموقع) ---- */
function exDlg(o){return new Promise(ok=>{const d=document.createElement('div');d.className='exdg';
 d.innerHTML=`<div class="exdb"><b class="exdt">${o.t||''}</b><div class="exdm">${o.m||''}</div>${o.inp?`<input id="exdi" type="number" inputmode="numeric" min="1" value="${o.v||''}">`:''}<div class="exda"><button type="button" class="g" data-k="0">${o.no||'إلغاء'}</button><button type="button" data-k="1" class="${o.bad?'r':''}">${o.ok||'تأكيد'}</button></div></div>`;
 const fin=v=>{d.remove();ok(v)};
 d.onclick=ev=>{const b=ev.target.closest('button');if(b)fin(b.dataset.k==='1'?(o.inp?d.querySelector('#exdi').value:true):false);else if(ev.target===d)fin(false)};
 document.body.appendChild(d);const i=d.querySelector('#exdi');if(i){i.focus();i.select()}})}

/* ---- قائمة المتسابقين ---- */
function examPage(){return exList()}
function exList(){const D=exD();
 return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">الاختبارات</b><button type="button" class="g" onclick="go('home')">رجوع</button></div>
 <div class="m" style="padding:0 16px 8px;line-height:1.7">أضف متسابقاً، اختر أجزاءه وعدد المواضع، ثم قيّمه واعتمد علامته. ويمكنك مراجعة أخطائه بعد الاعتماد.</div>
 <div style="padding:0 14px"><button type="button" style="width:100%" onclick="exAddOpen()">${svg('plus')} متسابق جديد</button></div>
 ${D.list.length?D.list.map(exCard).join(''):'<div class="m" style="text-align:center;padding:30px">لا يوجد متسابقون بعد</div>'}`}
function exCard(e){const st=e.done?`<span class="exb ok">العلامة ${exRound(e.score)}</span>`:e.pos?`<span class="exb">قيد الاختبار · ${e.pos.length} مواضع</span>`:`<span class="exb mu">لم يُسحب بعد</span>`;
 return `<div class="c exlc"><div class="row sp"><b style="font-size:17px">${esc(e.name)}</b>${st}</div><div class="m">رقم الجلوس ${esc(e.seat)}${e.level?' · المستوى: '+esc(e.level):''}${e.cnt?' · المواضع: '+e.cnt:''}</div>
 <div class="row" style="margin-top:10px;gap:6px">${e.done?`${e.pos?`<button type="button" onclick="exOpen(${e.id},0,1)">مراجعة الأخطاء</button><button type="button" class="g" onclick="exPaper(${e.id})">ورقة المواضع</button>`:''}<button type="button" class="g" onclick="exRedo(${e.id})">↺ إعادة اختبار</button>`:e.pos?`<button type="button" onclick="exOpen(${e.id})">متابعة الاختبار</button><button type="button" class="g" onclick="exPaper(${e.id})">ورقة المواضع</button><button type="button" class="g" onclick="exDrawOpen(${e.id})">سحب جديد</button>`:`<button type="button" onclick="exDrawOpen(${e.id})">${svg('target')} سحب الأجزاء والمواضع</button>`}<button type="button" class="g" style="color:var(--bad);border-color:var(--bad)" onclick="exDel(${e.id})">حذف</button></div></div>`}
const exNextSeat=()=>{const D=exD();let m=0;D.list.forEach(x=>{const n=parseInt(String(x.seat).replace(/\D/g,''),10);if(n>m)m=n});return String(m+1).padStart(3,'0')};
function exAddOpen(){const D=exD();$('#sh').innerHTML=shW(`<b>إضافة متسابق</b><div class="m" style="margin-top:8px">اسم المتسابق</div><input id="exN" autocomplete="off"><div class="m">رقم الجلوس</div><input id="exSt" value="${exNextSeat()}" autocomplete="off"><div class="m">المستوى</div><input id="exLv" placeholder="مثال: 10 أجزاء" autocomplete="off"><div class="m">عدد المواضع</div><input id="exCn" type="number" inputmode="numeric" min="1" placeholder="مثال: 10"><div class="row" style="margin-top:10px;gap:6px"><button type="button" class="g" style="flex:1" onclick="$('#sh').innerHTML=''">إلغاء</button><button type="button" style="flex:1" onclick="exAdd()">حفظ المتسابق</button></div>`);setTimeout(()=>{const i=$('#exN');i&&i.focus()},60)}
function exAdd(){const n=$('#exN').value.trim();if(!n){toast('اكتب اسم المتسابق');return}const D=exD();D.list.unshift({id:S.id++,name:n,seat:$('#exSt').value.trim()||exNextSeat(),level:$('#exLv').value.trim(),cnt:Math.max(0,Math.floor(+$('#exCn').value)||0)});D.seat++;save();$('#sh').innerHTML='';draw()}
async function exDel(id){if(!await exDlg({t:'حذف المتسابق',m:'سيُحذف هذا المتسابق وكل ما يخصه. هل تريد المتابعة؟',ok:'حذف',bad:1}))return;const D=exD();D.list=D.list.filter(x=>x.id!=id);save();draw()}
async function exRedo(id){if(!await exDlg({t:'إعادة الاختبار',m:'ستُمسح العلامة وأخطاء المتسابق ويبدأ الاختبار من جديد.',ok:'إعادة',bad:1}))return;const e=exGet(id);delete e.done;delete e.score;delete e.pos;delete e.cur;delete e.draw;save();draw()}

/* ---- السحب ---- */
async function exDrawOpen(id){const e=exGet(id);if(e.pos&&!await exDlg({t:'سحب جديد',m:'سيحلّ السحب الجديد محلّ المواضع الحالية وتقييمها.',ok:'متابعة',bad:1}))return;
 exDid=id;exSel={};exLim=exLevelMax(e);exWant=e.cnt||0;$('#sh').innerHTML=shW(`<b>إعداد السحب — ${esc(e.name)}</b><div class="m" style="margin:8px 0">${exWant?`اختر الأجزاء${exLim?' (حتى '+exLim+' أجزاء حسب المستوى)':''}، وتُوزَّع المواضع عليها عشوائياً، وقد لا يظهر موضع من كل جزء مختار.`:`اختر الأجزاء${exLim?' (حتى '+exLim+' أجزاء حسب المستوى)':''} وحدّد عدد المواضع داخل كل جزء.`}</div><div id="exDw"></div>`);exDw()}
let exLim=0,exWant=0;
const exLevelMax=e=>{const m=String(e.level||'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).match(/\d+/);return m?Math.min(30,+m[0]):0};
function exDw(){const ks=Object.keys(exSel).map(Number),tot=ks.reduce((s,k)=>s+exSel[k],0);
 $('#exDw').innerHTML=`<div class="exg">${[...Array(30)].map((_,i)=>{const j=i+1,c=exSel[j];if(exWant)return `<div class="exj${c?' on':''}" style="cursor:pointer" onclick="exTog(${j})">${j}</div>`;return c?`<div class="exj on"><b>${j}</b><div class="exs"><button type="button" onclick="exAdj(${j},1)">+</button><span>${c}</span><button type="button" onclick="exAdj(${j},-1)">−</button></div></div>`:`<div class="exj" onclick="exTog(${j})">${j}</div>`}).join('')}</div>
 ${exWant?`<div style="margin:10px 0;padding:10px;border:1px dashed var(--bd);border-radius:12px"><b>عدد المواضع</b><input id="exWn" type="number" inputmode="numeric" min="1" value="${exWant}" oninput="exWant=Math.max(0,Math.floor(+this.value)||0)" style="margin:6px 0 0"></div><div class="m">${ks.length}${exLim?' من '+exLim:''} جزء مختار · ${exWant} موضعاً توزَّع عشوائياً</div>`:`<div style="margin:10px 0;padding:10px;border:1px dashed var(--bd);border-radius:12px"><b>توحيد عدد المواضع لكل الأجزاء المختارة</b><div class="row" style="flex-wrap:nowrap;gap:6px;margin-top:6px"><input id="exU" type="number" min="1" placeholder="مثال: 3" style="margin:0"><button type="button" class="g" onclick="exUni()">تطبيق</button></div></div>
 <div class="m">${ks.length}${exLim?' من '+exLim:''} جزء مختار · ${tot} موضعاً بالمجموع</div>`}
 <div class="row" style="margin-top:10px;gap:6px"><button type="button" class="g" style="flex:1" onclick="$('#sh').innerHTML=''">إلغاء</button><button type="button" style="flex:1" onclick="exRun_()">✨ تنفيذ السحب</button></div>`}
function exTog(j){if(exSel[j]){if(exWant){delete exSel[j];exDw()}return}if(exLim&&Object.keys(exSel).length>=exLim){toast('المستوى يسمح باختيار '+exLim+' أجزاء فقط');return}exSel[j]=1;exDw()}
function exAdj(j,d){const n=(exSel[j]||1)+d;if(n<1)delete exSel[j];else exSel[j]=Math.min(n,exPages(j));exDw()}
function exUni(){const v=Math.floor(+$('#exU').value);if(!v||v<1){toast('اكتب رقماً صحيحاً');return}Object.keys(exSel).forEach(j=>exSel[j]=Math.min(v,exPages(+j)));exDw()}
async function exRun_(){const ks=Object.keys(exSel).map(Number).sort((a,b)=>a-b);if(!ks.length){toast('اختر جزءاً واحداً على الأقل');return}if(exBusy)return;if(exWant&&!(exWant>0)){toast('اكتب عدد المواضع');return}exBusy=1;
 let plan=exSel;
 if(exWant){const cap=ks.reduce((a,j)=>a+exPages(j),0);if(exWant>cap){exBusy=0;toast('الأجزاء المختارة تتسع لـ '+cap+' موضعاً فقط');return}
  plan={};ks.forEach(j=>plan[j]=0);for(let i=0;i<exWant;i++){const el=ks.filter(j=>plan[j]<exPages(j));plan[el[exRnd(el.length)]]++}}
 const tasks=[];ks.forEach(j=>{const u=new Set();for(let i=0;i<plan[j];i++)tasks.push({j,u})});
 let done=0;const out=[],prog=()=>{const b=$('#exDw');if(b)b.innerHTML=`<div style="text-align:center;padding:26px 6px"><div class="exspin"></div><b>جارٍ السحب العشوائي…</b><div class="m" style="margin-top:6px">${done} / ${tasks.length}</div></div>`};
 prog();
 try{for(let i=0;i<tasks.length;i+=4){const part=await Promise.all(tasks.slice(i,i+4).map(t=>exMake(t.j,t.u)));part.forEach(r=>{if(r)out.push(r)});done=Math.min(tasks.length,i+4);prog()}}
 catch(er){exBusy=0;toast('تعذّر تحميل بيانات المصحف — تأكد من الإنترنت وأعد المحاولة');exDw();return}
 exBusy=0;if(!out.length){toast('تعذّر السحب، أعد المحاولة');exDw();return}
 exShuf(out);const e=exGet(exDid),D=exD(),b=new Uint8Array(6);crypto.getRandomValues(b);
 e.pos=out;e.cur=0;delete e.done;delete e.score;e.draw={no:String(++D.draws).padStart(4,'0'),code:[...b].map(x=>x.toString(16).padStart(2,'0')).join('').toUpperCase(),at:Date.now()};
 save();$('#sh').innerHTML='';draw();exPaper(e.id)}

/* ---- ورقة مواضع الاختبار ---- */
function exPaper(id){const e=exGet(id);if(!e||!e.pos)return;e.pos.forEach(exN);const juz=[...new Set(e.pos.map(p=>p.j))].sort((a,b)=>a-b),dr=e.draw||{no:'—',code:'—'};
 const row=(i,p)=>`<div class="exrw"><div class="exrn">${i+1}</div><div class="exri"><b>${esc(exRng(p))}</b><div class="m">الجزء ${p.j} · ${p.lines||''} أسطر${p.words?' · '+p.words+' كلمة':''}${p.fc?' · '+p.fc+':'+p.fv+' إلى '+p.tc+':'+p.tv:''}</div></div><div class="exrp"><small>الصفحة</small><b>${exPgs(p)}</b></div></div>`;
 const o=document.createElement('div');o.className='exov2';o.id='exPp';
 o.innerHTML=`<div class="expaper"><div id="expp"><div class="expph"><div class="row sp" style="align-items:flex-start"><div><small>الاختبارات</small><h3>ورقة مواضع الاختبار</h3></div><div style="text-align:left"><small>رقم السحب</small><b style="display:block;font-size:20px">${dr.no}</b><small dir="ltr">${dr.code}</small></div></div></div>
 <div class="exfl"><div><small>اسم المتسابق</small><b>${esc(e.name)}</b></div><div><small>رقم الجلوس</small><b>${esc(e.seat)}</b></div><div><small>المستوى</small><b>${esc(e.level||'—')}</b></div><div><small>أرقام الأجزاء المشاركة</small><b>${juz.join('، ')}</b></div></div>
 <div class="exrh"><span>الرقم</span><span>الموضع المختار</span><span>الصفحة</span></div>${e.pos.map((p,i)=>row(i,p)).join('')}
 <div class="exnote">تم تثبيت هذه المواضع لهذا السحب.</div></div>
 <div class="exac"><div class="row" style="gap:8px"><button type="button" class="g" style="flex:1" onclick="exPaperX()">إغلاق</button><button type="button" style="flex:2" onclick="exPaperX();exOpen(${e.id})">بدء التقييم الإلكتروني</button></div><button type="button" class="g" style="width:100%;margin-top:8px" onclick="exPrint()">🖨 طباعة / حفظ PDF</button></div></div>`;
 document.body.appendChild(o);document.body.classList.add('exlock')}
function exPaperX(){const o=$('#exPp');if(o)o.remove();if(!$('#exOv'))document.body.classList.remove('exlock')}
function exPrint(){const el=$('#expp');if(!el)return;const f=document.createElement('iframe');f.style.cssText='position:fixed;width:0;height:0;border:0';document.body.appendChild(f);const d=f.contentWindow.document;d.open();
 d.write('<html dir="rtl"><head><meta charset="utf-8"><style>body{font-family:sans-serif;margin:18px;color:#111}.expph{background:#1a237e;color:#fff;padding:14px;border-radius:10px}h3{margin:4px 0}small{opacity:.75;font-size:12px}.exfl{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:14px 0}.exfl small,.exfl b{display:block}.exrh{display:flex;justify-content:space-between;border-bottom:2px solid #ccc;padding:6px 0;font-size:12px;color:#666}.exrw{display:flex;gap:10px;align-items:center;border-bottom:1px solid #ddd;padding:8px 0}.exrn{background:#e8eaf6;border-radius:8px;padding:4px 10px;font-weight:700}.exri{flex:1}.m{color:#666;font-size:12px}.exrp{text-align:center}.exrp b{display:block;font-size:18px}.exnote{margin-top:12px;background:#fff8e1;padding:8px;border-radius:8px;font-size:13px}</style></head><body>'+el.innerHTML+'</body></html>');d.close();
 setTimeout(()=>{try{f.contentWindow.focus();f.contentWindow.print()}catch(er){dbg(er)}setTimeout(()=>f.remove(),2000)},300)}

/* ---- شاشة الاختبار: شريط علوي وسفلي ثابتان، والتحديث في مكانه دون إعادة رسم ---- */
let exPh=0,exRO=0,exRz=null;try{exPh=+(localStorage.getItem('qmrm_exph')||0)}catch(er){dbg(er)}
const exLand=()=>innerWidth>innerHeight&&innerHeight<600;
const exPin=()=>{const o=$('#exOv');return !!o&&(o.classList.contains('ls')||o.classList.contains('ph'))};
const exScr=()=>exPin()?document.querySelector('#exBody .exrest'):$('#exBody');
function exCls(){const o=$('#exOv');if(!o)return;const l=exLand();o.classList.toggle('ls',l);o.classList.toggle('ph',!l&&!!exPh);o.classList.toggle('ro',!!exRO)}
function exOpen(id,pi,ro){const e=exGet(id);if(!e||!e.pos)return;exCur=id;exRO=ro?1:0;e.pos.forEach(exN);exHist=[];exSeg=0;exZoom=100;exStop();exLeft=exDur;
 e.cur=Math.min(pi!=null?pi:(e.cur||0),e.pos.length-1);
 let ov=$('#exOv');if(!ov){ov=document.createElement('div');ov.id='exOv';document.body.appendChild(ov)}
 ov.innerHTML='<div id="exTop"></div><div id="exStrip"></div><div id="exBody"></div><div id="exFoot"></div>';document.body.classList.add('exlock');
 if(exLand()||exPh)exCrop=1;
 exCls();exTopR();exStripR();exBodyR();exFootR()}
function exClose(){exStop();exLockOri(0);exCur=0;exRO=0;const ov=$('#exOv');if(ov)ov.remove();document.body.classList.remove('exlock');draw()}
const exE=()=>exGet(exCur),exP=()=>{const e=exE();return e.pos[e.cur||0]};
let exLk=0;
function exLockOri(on){try{
 if(!on){if(exLk){exLk=0;try{screen.orientation.unlock()}catch(er){dbg(er)}try{if(document.fullscreenElement)document.exitFullscreen()}catch(er){dbg(er)}}return}
 const t=(screen.orientation&&screen.orientation.type)||(innerWidth>innerHeight?'landscape-primary':'portrait-primary'),fail=()=>{exLk=0;toast('لم يسمح الجهاز بتثبيت الاتجاه من المتصفح، استعمل قفل التدوير في الهاتف')};
 exLk=1;const r=screen.orientation.lock(t);
 if(r&&r.catch)r.catch(()=>{const el=document.documentElement;(el.requestFullscreen?el.requestFullscreen():Promise.reject()).then(()=>screen.orientation.lock(t)).catch(fail)})
}catch(er){exLk=0;try{toast('لم يسمح الجهاز بتثبيت الاتجاه من المتصفح، استعمل قفل التدوير في الهاتف')}catch(x){dbg(x)}}}
function exPhone(){exPh=exPh?0:1;try{localStorage.setItem('qmrm_exph',exPh)}catch(er){dbg(er)}if(exPh)exCrop=1;exLockOri(exPh);exCls();exTopR();exViewer()}
function exTopR(){const e=exE();$('#exTop').innerHTML=`<div class="exh"><button type="button" class="exx" onclick="exClose()" aria-label="إغلاق">✕</button><div class="exw"><b>${esc(e.name)}</b><small>${exRO?'مراجعة الأخطاء · ':''}رقم الجلوس ${esc(e.seat)} · ${e.pos.length} مواضع</small><button type="button" class="exphb${exPh?' on':''}" onclick="exPhone()">${exPh?'🔒':'📱'} وضع الهاتف${exPh?' · مثبّت':''}</button></div><div class="exmk"><small>العلامة</small><b id="exMk">${exMark(e)}</b></div></div>`}
function exStripR(){const e=exE(),s=$('#exStrip');s.innerHTML=e.pos.map((p,i)=>`<button type="button" class="exc${i==(e.cur||0)?' on':''}${p.d?' dn':''}${exDed(p.m)>0?' er':''}" onclick="exGoTo(${i})">${i+1}</button>`).join('');
 const on=s.querySelector('.on');if(on){const x=on.offsetLeft-(s.clientWidth-on.clientWidth)/2;try{s.scrollTo({left:x,behavior:'smooth'})}catch(er){s.scrollLeft=x}}}
function exFootR(){const e=exE(),i=e.cur||0,nav=`<button type="button" class="g" onclick="exGoTo(${i-1})" ${i<1?'disabled':''}>→ السابق</button><button type="button" class="g" onclick="exGoTo(${i+1})" ${i>=e.pos.length-1?'disabled':''}>التالي ←</button>`;
 $('#exFoot').innerHTML=exRO
  ?`<div class="row sp" style="margin-bottom:8px"><div><small class="m">إجمالي الخصم</small><b id="exTd" class="extd">${exTot(e)}</b></div><button type="button" class="g" onclick="exEdit()">✎<span class="exlbl"> تعديل التقييم</span></button></div><div class="exbt">${nav}<button type="button" onclick="exClose()">إغلاق</button></div>`
  :`<div class="row sp" style="margin-bottom:8px"><div><small class="m">إجمالي الخصم</small><b id="exTd" class="extd">${exTot(e)}</b></div><button type="button" class="g" id="exUn" onclick="exUndo()" ${exHist.length?'':'disabled'}>↶<span class="exlbl"> تراجع عن آخر تسجيل</span></button></div><div class="exbt">${nav}<button type="button" onclick="exReview()">مراجعة واعتماد</button></div>`}
function exBodyR(fade){const e=exE(),i=e.cur||0,p=e.pos[i],f=fade?' exfade':'',ro=exRO?' disabled':'';
 $('#exBody').innerHTML=`<div class="c exc1 exvc${f}"><div class="row sp exhd"><b>الموضع ${i+1} من ${e.pos.length}</b><span class="m" id="exPD">خصم الموضع: ${exDed(p.m)}</span></div>
 <div class="exttl">${esc(exRng(p))}</div><div class="m exsub" style="text-align:center">الجزء ${p.j} · الصفحة ${exPgs(p)}${p.lines?' · '+p.lines+' أسطر':''}</div><div id="exVw"></div></div>
 <div class="exrest${f}"><div class="exgr">${EXT.map(([k,n,w,c])=>`<div class="exr" style="--ec:${c}"><div class="exrr"><div class="exrl"><b>${n}</b><div class="m">الواحدة: ${w} · الخصم: <span id="exd${k}">${exRound(p.m[k]*w)}</span></div></div><b class="exn" id="exn${k}">${p.m[k]}</b>${k=='c'?`<button type="button" class="exq pl" onclick="exChange()" aria-label="تغيير الموضع"${ro}>${svg('refresh')}</button>`:`<button type="button" class="exq pl" onclick="exBump('${k}',1)"${ro}>+</button>`}<button type="button" class="g exq mn" onclick="exBump('${k}',-1)"${ro}>−</button></div></div>`).join('')}</div>
 ${exRO?'':`<div class="c"><div class="row sp" style="flex-wrap:nowrap"><div class="extm"><b id="exT">${exLeft}</b><span class="m">ثانية</span></div><div class="row" style="gap:6px;flex-wrap:nowrap"><button type="button" id="exTb" onclick="exTimer()">${svg('play')} تشغيل</button><button type="button" class="g" onclick="exReset()" aria-label="تصفير">${svg('reset')}</button><button type="button" class="g" id="exBl" onclick="exSound()" aria-label="تجربة الصوت">${svg('bell')}</button><button type="button" class="g" onclick="exDurSet()" aria-label="المدة">${svg('timer')}</button></div></div></div>`}
 ${(!exRO||p.n)?`<div class="c"><b>ملاحظات الموضع</b><textarea rows="3" placeholder="ملاحظة اختيارية عن أداء المتسابق" oninput="exNote(this.value)" style="margin-top:6px"${exRO?' readonly':''}>${esc(p.n||'')}</textarea>${exRO?'':`<button type="button" class="g" id="exFp" style="width:100%;margin-top:8px" onclick="exFinPos()">${p.d?'✅ تم إنهاء الموضع':'○ إنهاء هذا الموضع'}</button>`}</div>`:''}</div>`;
 exViewer();exPre()}
function exPre(){try{const e=exE(),i=e.cur||0,p=e.pos[i],list=[];p.segs.forEach(s=>list.push(s.p));[e.pos[i+1],e.pos[i-1]].forEach(q=>{if(q)list.push(exN(q).segs[0].p)});list.forEach(n=>{const im=new Image();im.src=exSrc(n)})}catch(er){dbg(er)}}
function exViewer(){const p=exP(),k=Math.min(exSeg,p.segs.length-1),s=p.segs[k],g=exGeo(s.p,s.l1,s.l2),src=exSrc(s.p),pc=v=>(Math.round(v*1000)/1000)+'%',many=p.segs.length>1,pin=exPin();
 const ctl=`<div class="exct"><button type="button" class="g" onclick="exZm(-25)" aria-label="تصغير">−</button><b>${exZoom}%</b><button type="button" class="g" onclick="exZm(25)" aria-label="تكبير">+</button><button type="button" class="g" onclick="exZm(0)">إعادة</button><button type="button" class="${exCrop?'':'g'}" onclick="exCropT()">قص الأسطر فقط</button></div>`;
 const err=`onerror="this.closest('#exVw').classList.add('bad')" onload="this.classList.add('ok')"`;
 let box;
 if(exCrop){const cw=g.x1-g.x0+40,ch=g.y1-g.y0+20;box=`<div class="exim crop" data-r="${cw/ch}" style="aspect-ratio:${cw}/${ch};${pin?'':'width:'+exZoom+'%'}"><img ${err} src="${src}" alt="صفحة ${s.p}" style="width:${pc(750/cw*100)};left:${pc(-(g.x0-20)/cw*100)};top:${pc(-(g.y0-10)/ch*100)}"></div>`}
 else box=`<div class="exim" data-r="${750/g.H}" style="${pin?'':'width:'+exZoom+'%;'}aspect-ratio:750/${g.H}"><img ${err} src="${src}" alt="صفحة ${s.p}"><div class="exhl" style="left:${pc(g.x0/750*100)};width:${pc((g.x1-g.x0)/750*100)};top:${pc(g.y0/g.H*100)};height:${pc((g.y1-g.y0)/g.H*100)}"></div></div>`;
 const nav=`<div class="exsn2"><button type="button" class="g" onclick="exSg(-1)" ${k<1?'disabled':''} aria-label="الصفحة السابقة">›</button><div style="flex:1;text-align:center"><b>صفحة ${s.p}</b><div class="m">${s.l1===s.l2?'السطر '+s.l1:'الأسطر '+s.l1+'–'+s.l2}${many?' · صفحة '+(k+1)+' من '+p.segs.length+' لهذا الموضع':''}</div></div><button type="button" class="g" onclick="exSg(1)" ${k>=p.segs.length-1?'disabled':''} aria-label="الصفحة التالية">‹</button></div>`;
 $('#exVw').classList.remove('bad');
 const side=`<div class="exside"><button type="button" class="g" onclick="exZm(25)" aria-label="تكبير">+</button><b>${exZoom}%</b><button type="button" class="g" onclick="exZm(-25)" aria-label="تصغير">−</button><button type="button" class="g" onclick="exZm(0)" aria-label="إعادة الحجم">↺</button><button type="button" class="${exCrop?'':'g'}" onclick="exCropT()" aria-label="قص الأسطر فقط">✂</button></div>`;
 $('#exVw').innerHTML=(pin?`<div class="exvr"><div class="exfit">${box}</div>${side}</div>`:ctl+`<div class="exfit">${box}</div>`)+nav+`<div class="exbadm m">تعذّر تحميل صورة الصفحة — تأكد من الاتصال بالإنترنت.<br><button type="button" class="g" style="margin-top:8px" onclick="exViewer()">إعادة المحاولة</button></div>`;
 if(pin)exFit()}
/* في وضع الهاتف والعرض الأفقي: تُقاس الصورة لتناسب المساحة المتاحة فتظهر الصفحة كاملة مع الأزرار */
function exFit(){const f=document.querySelector('#exVw .exfit'),m=f&&f.querySelector('.exim');if(!m)return;const bw=f.clientWidth,bh=f.clientHeight,r=+m.dataset.r;if(!bw||!bh)return;let w=Math.min(bw,bh*r);w*=exZoom/100;m.style.width=Math.floor(w)+'px'}
/* يحفظ مكان التمرير (الصفحة والحاوية) ويعيده بعد أي تحديث، فلا ينزل الموقع ولا يقفز */
function exKeep(fn){const a=exScr(),b=$('#exBody'),y=window.scrollY,sa=a?a.scrollTop:0,sb=b?b.scrollTop:0;
 const back=()=>{const a2=exScr(),b2=$('#exBody');if(a2)a2.scrollTop=sa;if(b2)b2.scrollTop=sb;if(Math.abs(window.scrollY-y)>1){try{window.scrollTo({top:y,behavior:'instant'})}catch(er){window.scrollTo(0,y)}}};
 fn();back();requestAnimationFrame(back);setTimeout(back,80)}
function exZm(d){exKeep(()=>{exZoom=d?Math.max(100,Math.min(300,exZoom+d)):100;exViewer()})}
function exCropT(){exKeep(()=>{exCrop=exCrop?0:1;exViewer()})}
function exSg(d){const p=exP();exKeep(()=>{exSeg=Math.max(0,Math.min(p.segs.length-1,exSeg+d));exViewer()})}
/* التنقل بين المواضع: لا يتحرك التمرير ولا يقفز المحتوى */
function exGoTo(i){const e=exE();if(i<0||i>=e.pos.length)return;exStop();exKeep(()=>{e.cur=i;exSeg=0;exLeft=exDur;save();exStripR();exBodyR(1);exFootR()});const sc=null,st=0,s2=null;if(s2)s2.scrollTop=st}
/* تسجيل الأخطاء: تحديث الأرقام في مكانها فقط، بلا إعادة رسم ولا قفز */
function exBump(k,d){if(exRO)return;const e=exE(),p=exP(),n=p.m[k]+d;if(n<0)return;p.m[k]=n;if(d>0)exHist.push([e.cur||0,k]);save();exUpd(k)}
function exUpd(k){const e=exE(),p=exP(),w=EXT.find(x=>x[0]==k);
 if(k){const n=$('#exn'+k);n.textContent=p.m[k];n.classList.remove('bmp');void n.offsetWidth;n.classList.add('bmp');$('#exd'+k).textContent=exRound(p.m[k]*w[2])}
 $('#exPD').textContent='خصم الموضع: '+exDed(p.m);$('#exMk').textContent=exMark(e);$('#exTd').textContent=exTot(e);const u=$('#exUn');if(u)u.disabled=!exHist.length;
 const c=$('#exStrip').children[e.cur||0];if(c)c.classList.toggle('er',exDed(p.m)>0)}
function exUndo(){if(exRO||!exHist.length)return;const[pi,k]=exHist.pop(),e=exE();if(pi!==(e.cur||0)){exGoTo(pi)}const p=exP();if(p.m[k]>0){p.m[k]--;save();exUpd(k)}const u=$('#exUn');if(u)u.disabled=!exHist.length}
async function exChange(){if(exRO)return;const e=exE(),p=exP();if(!await exDlg({t:'تغيير الموضع',m:'سيُسحب موضع جديد من الجزء نفسه، وتُخصم 10 علامات.',ok:'تغيير الموضع'}))return;
 try{const u=new Set();e.pos.forEach(x=>{if(x.j==p.j)exN(x).segs.forEach(s=>u.add(s.p))});const n=await exMake(p.j,u,12);if(!n){toast('تعذّر اختيار موضع جديد');return}n.m={...p.m,c:p.m.c+1};n.n=p.n;e.pos[e.cur||0]=n;exHist.push([e.cur||0,'c']);save();exSeg=0;exStripR();exBodyR(1);exFootR();exTopR()}
 catch(er){toast('تعذّر تحميل بيانات المصحف — تأكد من الإنترنت')}}
function exNote(v){if(exRO)return;exP().n=v;save()}
function exFinPos(){if(exRO)return;const p=exP();p.d=p.d?0:1;save();$('#exFp').textContent=p.d?'✅ تم إنهاء الموضع':'○ إنهاء هذا الموضع';const c=$('#exStrip').children[exE().cur||0];if(c)c.classList.toggle('dn',!!p.d)}
try{if(screen.orientation&&screen.orientation.unlock)screen.orientation.unlock()}catch(er){dbg(er)}
addEventListener('orientationchange',()=>{setTimeout(()=>{try{window.dispatchEvent(new Event('resize'))}catch(er){dbg(er)}},250)});
addEventListener('resize',()=>{if(!$('#exOv'))return;clearTimeout(exRz);exRz=setTimeout(()=>{exCls();const e=exCur&&exGet(exCur);if(e&&e.pos){if(exLand()&&!$('#exOv').dataset.ls){$('#exOv').dataset.ls=1;exCrop=1}exKeep(()=>exViewer())}},120)});
/* المؤقت */
function exStop(){clearInterval(exTm);exTm=null;exRun=false}
function exTmUI(){const t=$('#exT');if(t){t.textContent=exLeft;t.classList.toggle('over',exLeft<0)}const b=$('#exTb');if(b)b.innerHTML=exRun?svg('pause')+' إيقاف':svg('play')+' تشغيل'}
function exTimer(){if(exRun){exStop();exTmUI();return}exRun=true;exTm=setInterval(()=>{exLeft--;exTmUI();if(exLeft===0)exBeep()},1000);exTmUI()}
function exReset(){exStop();exLeft=exDur;exTmUI()}
function exSound(){exSnd=1;exBeep()}
async function exDurSet(){const v=parseInt(await exDlg({t:'مدة المؤقت',m:'اكتب المدة بالثواني',inp:1,v:exDur,ok:'حفظ'}));if(v>0){exDur=v;exStop();exLeft=v;exTmUI()}}
function exBeep(){if(!exSnd)return;try{const a=new(window.AudioContext||window.webkitAudioContext)(),o=a.createOscillator(),g=a.createGain();o.connect(g);g.connect(a.destination);o.frequency.value=880;g.gain.value=.25;o.start();setTimeout(()=>{o.stop();a.close()},500)}catch(er){dbg(er)}try{navigator.vibrate&&navigator.vibrate([200,100,200])}catch(er){dbg(er)}}
/* مراجعة واعتماد: تبقى التفاصيل محفوظة ويمكن مراجعتها لاحقاً */
async function exReview(){const e=exE(),rows=e.pos.map((p,i)=>`<div class="row sp exrv"><span>الموضع ${i+1} · ${esc(exRng(p))}</span><b>${exDed(p.m)}</b></div>`).join('');
 const ok=await exDlg({t:'مراجعة واعتماد العلامة',m:`<div class="exrvl">${rows}</div><div class="row sp" style="margin-top:10px"><span>إجمالي الخصم</span><b>${exTot(e)}</b></div><div class="row sp"><span>العلامة النهائية</span><b style="font-size:24px;color:var(--pri)">${exMark(e)}</b></div>`,ok:'اعتماد العلامة',no:'رجوع'});
 if(!ok)return;e.score=exMark(e);e.done=Date.now();save();exStop();exLockOri(0);exCur=0;exRO=0;const ov=$('#exOv');if(ov)ov.remove();document.body.classList.remove('exlock');draw();toast('تم اعتماد العلامة')}
async function exEdit(){const e=exE();if(!await exDlg({t:'تعديل التقييم',m:'سيُعاد فتح الاختبار لتعديل الأخطاء، ثم تعتمد العلامة من جديد.',ok:'تعديل'}))return;delete e.done;delete e.score;save();exOpen(e.id,e.cur||0)}

/* ---------- الإعدادات ---------- */
const CC="AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS XK YE YT ZA ZM ZW".split(' ');
const ARAB='DZ BH KM DJ EG IQ JO KW LB LY MR MA OM PS QA SA SO SD SY TN AE YE'.split(' '),ISL='AF AL AZ BD BF BN BA TD GM GN ID IR KZ XK KG MY MV ML NE NG PK SN SL TJ TR TM UZ'.split(' '),GN=['الدول العربية','الدول الإسلامية','دول أخرى'];
const _cn={};function cntries(){const l=S.lang=='en'?'en':'ar';if(!_cn[l]){let dn,de;try{dn=new Intl.DisplayNames([l],{type:'region'});de=new Intl.DisplayNames(['en'],{type:'region'})}catch(e){dbg(e)}
 _cn[l]=CC.map(c=>[c,c=='PS'?(l=='en'?'Palestine':'فلسطين'):(dn?(dn.of(c)||c):c),String.fromCodePoint(...[...c].map(x=>127397+x.charCodeAt(0))),ARAB.includes(c)?0:ISL.includes(c)?1:2,c=='PS'?'Palestine':(de?(de.of(c)||c):c)]).sort((a,b)=>a[3]-b[3]||a[1].localeCompare(b[1],l))}return _cn[l]}
const nrm=x=>(x||'').toLowerCase().replace(/[\u064B-\u0652\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').trim();
function ctryList(q){q=nrm(q);let g=-1,o='';cntries().forEach(([c,n,f,gp,en])=>{if(q&&!(nrm(n).includes(q)||en.toLowerCase().includes(q)||c.toLowerCase()==q))return;if(gp!==g){g=gp;o+=`<div class="dsec" style="padding:10px 4px 4px">${GN[gp]}</div>`}o+=`<div onclick="setCountry('${c}')" style="padding:10px 6px;border-bottom:1px solid var(--bd);display:flex;justify-content:space-between"><span>${f} ${n}</span><b style="color:var(--pri)">${prof().country==c?'✓':''}</b></div>`});return o||'<div class="m" style="padding:10px">لا نتائج</div>'}
function ctrySheet(){$('#sh').innerHTML=shW(`<b>${svg('globe')} اختر بلد الإقامة</b><input id="cq" placeholder="ابحث عن دولة..." autocomplete="off" oninput="$('#cql').innerHTML=ctryList(this.value)" style="margin-top:8px"><div id="cql" style="max-height:55vh;overflow-y:auto">${ctryList('')}</div>`)}
const pgNorm=x=>typeof x!='string'?x:x.replace(/صفحات: ([\d–]+(?:\s*[،و]\s*[\d–]+)*)/g,(m,l)=>{const p=l.split(/\s*[،و]\s*/).filter(Boolean);return p.length==1&&!p[0].includes('–')?'صفحة '+p[0]:'صفحات: '+p.join(' و ')});
function migPg(){(S.tasks||[]).forEach(t=>{t.s=pgNorm(t.s)});(S.logs||[]).forEach(l=>{l.s=pgNorm(l.s)});(S.arc||[]).forEach(a=>{a.name=pgNorm(a.name);a.sub=pgNorm(a.sub);if(a.tk)a.tk.s=pgNorm(a.tk.s)})}
function migrate(){migPg();if(!S.tdm){S.td=S.td||[];(S.nbs||[]).forEach(b=>{(b.todos||[]).forEach(x=>S.td.push({...x,s:x.s===undefined?(x.d?1:0):x.s}));delete b.todos});S.tdm=1}
 (S.cont||[]).forEach(c=>{c.juz=(c.juz||[]).map(x=>typeof x=='number'?'ج'+x:x);c.heard=(c.heard||[]).map(x=>typeof x=='number'?'ج'+x:x)});
 S.td=S.td||[];S.td.filter(x=>x.s).forEach(x=>(S.tda=S.tda||[]).push(x));S.td=S.td.filter(x=>!x.s);
 const P=S.pv;if(P&&P.items){P.arc=P.arc||[];P.items.filter(x=>x.s).forEach(x=>P.arc.push(x));P.items=P.items.filter(x=>!x.s)}
 if(S.cont){S.cont.filter(c=>c.fin).forEach(c=>(S.carc=S.carc||[]).push(c));S.cont=S.cont.filter(c=>!c.fin)}}
function setCountry(c){prof().country=c;save();$('#sh').innerHTML='';draw()}
const cName=c=>{const x=cntries().find(y=>y[0]==c);return x?x[2]+' '+x[1]:(c||'—')};
const ageOf=P=>{if(P.bd){const b=new Date(P.bd),n=new Date();let a=n.getFullYear()-b.getFullYear();if(n<new Date(n.getFullYear(),b.getMonth(),b.getDate()))a--;return a>=0?a:''}return P.age||''};
let pe={on:false};
const avatar=()=>{const P=prof(),src=P.photo||(fu&&fu.photoURL)||'';return src?`<img src="${esc(src)}" referrerpolicy="no-referrer" alt="">`:svg('user')};
const handle=()=>prof().user?'@'+prof().user:(fu&&fu.email?'@'+fu.email.split('@')[0]:'@guest');
function toast(m){const d=document.createElement('div');d.textContent=m;d.setAttribute('role','status');d.style.cssText='position:fixed;bottom:calc(104px + env(safe-area-inset-bottom,0px));left:50%;transform:translateX(-50%);background:#1d2036;color:#fff;padding:11px 20px;border-radius:16px;z-index:90;font-size:14px;font-weight:600;box-shadow:0 12px 30px -8px #0008;border:1px solid #ffffff22;max-width:88vw;text-align:center';document.body.appendChild(d);setTimeout(()=>d.remove(),1400)}
function cp(v){try{navigator.clipboard.writeText(v)}catch(e){dbg(e)}toast('تم النسخ')}
function pickPhoto(inp){const f=inp.files[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas'),z=256,m=Math.min(im.width,im.height);c.width=c.height=z;c.getContext('2d').drawImage(im,(im.width-m)/2,(im.height-m)/2,m,m,0,0,z,z);prof().photo=c.toDataURL('image/jpeg',.82);save();draw()};im.src=rd.result};rd.readAsDataURL(f)}
function chPass(){if(!fu)return;const has=(fu.providerData||[]).some(x=>x.providerId==='password');
 $('#sh').innerHTML=shW(`<b>${has?'تغيير كلمة المرور':'إنشاء كلمة مرور'}</b><div class="m" style="margin:6px 0">${has?'اكتب كلمة المرور الجديدة.':'يبقى حسابك مرتبطاً بـ Google، وتضيف كلمة مرور ليصبح الدخول ممكناً أيضاً بالبريد أو اسم المستخدم.'}</div><input id="cpw" type="password" dir="ltr" placeholder="كلمة المرور الجديدة (6 أحرف على الأقل)" autocomplete="new-password"><input id="cpw2" type="password" dir="ltr" placeholder="تأكيد كلمة المرور" autocomplete="new-password"><div id="cpm" class="m" style="color:var(--bad)"></div><button type="button" onclick="chPassDo()">حفظ</button><button type="button" class="g" onclick="chPassMail()">أو أرسل لي رابطاً على بريدي</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
function chPassMail(){if(!fu)return;fa.sendPasswordResetEmail(fu.email).then(()=>{$('#sh').innerHTML='';sync('✅ أرسلنا رابط تغيير كلمة المرور إلى بريدك')}).catch(er)}
async function chPassDo(){const a=$('#cpw').value,b=$('#cpw2').value,m=$('#cpm');if(a.length<6){m.textContent='⚠️ كلمة المرور 6 أحرف على الأقل';return}if(a!==b){m.textContent='⚠️ كلمتا المرور غير متطابقتين';return}
 const pv=(fu.providerData||[]).map(x=>x.providerId),has=pv.includes('password');
 const run=async h=>{if(h)await fu.updatePassword(a);else await fu.linkWithCredential(firebase.auth.EmailAuthProvider.credential(fu.email,a))};
 try{await run(has)}catch(e){
  if(e.code==='auth/provider-already-linked'){try{await run(true)}catch(e3){m.textContent='⚠️ '+(ERR[e3.code]||e3.message||'تعذّر الحفظ');return}}
  else if(e.code==='auth/requires-recent-login'){if(!pv.includes('google.com')){m.textContent='⚠️ سجّل الخروج ثم ادخل من جديد وأعد المحاولة';return}
   try{await fu.reauthenticateWithPopup(new firebase.auth.GoogleAuthProvider());await run(has)}catch(e2){m.textContent='⚠️ '+(ERR[e2.code]||e2.message||'تعذّر الحفظ');return}}
  else{m.textContent='⚠️ '+(ERR[e.code]||e.message||'تعذّر الحفظ');return}}
 $('#sh').innerHTML='';sync(has?'✅ تم تغيير كلمة المرور':'✅ أُضيفت كلمة مرور لحسابك، يمكنك الدخول بـ Google أو بالبريد/اسم المستخدم');draw()}
/* ===== شاشة المزامنة واسترجاع البيانات ===== */
function dtF(t){if(!t)return'—';try{return new Date(t).toLocaleString(S.lang=='en'?'en-GB':'ar-JO',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}catch(e){return'—'}}
const dStat=o=>({nb:(o.nbs||[]).length,td:(o.td||[]).length,lg:(o.logs||[]).length});
async function syncSheet(){
 if(!fu)return;
 const L=dStat(S),kb=Math.max(1,Math.round(JSON.stringify(S).length/1024)),fmtKb=v=>v>=1024?(v/1024).toFixed(1)+' م.ب':v+' ك.ب';
 const cell=(l,a,id)=>`<div style="display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:8px;padding:10px 0;border-bottom:1px solid var(--bd);align-items:center;font-size:14.5px"><span class="m">${l}</span><b style="text-align:center">${a}</b><b id="sc-${id}" style="text-align:center;color:var(--mut)">…</b></div>`;
 $('#sh').innerHTML=shW(`<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px"><span style="width:46px;height:46px;border-radius:15px;background:color-mix(in srgb,var(--pri) 14%,transparent);color:var(--pri);display:flex;align-items:center;justify-content:center;flex:none"><span style="width:26px;height:26px;display:block">${svg('cloud')}</span></span><div style="min-width:0"><b style="font-size:18px;display:block">المزامنة واسترجاع البيانات</b><div class="m" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;text-align:right">${esc(fu.email||prof().name||'')}</div></div></div>
 <div id="sc-st" style="display:flex;align-items:center;gap:8px;padding:10px 12px;border-radius:14px;background:color-mix(in srgb,#2e7d32 12%,transparent);color:#2e7d32;font-size:14px;font-weight:600"><span style="width:9px;height:9px;border-radius:50%;background:#2e7d32;flex:none"></span><span>المزامنة التلقائية مفعّلة</span></div>
 <div style="margin-top:14px;border:1px solid var(--bd);border-radius:16px;padding:4px 14px 0;background:var(--bg)">
  <div style="display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:8px;padding:10px 0;border-bottom:1px solid var(--bd);font-size:13px;color:var(--mut);font-weight:700"><span></span><span style="text-align:center">هذا الجهاز</span><span style="text-align:center">حسابك</span></div>
  ${cell('الدفاتر',L.nb,'nb')}${cell('المهمات',L.td,'td')}${cell('سجل المراجعة',L.lg,'lg')}${cell('الحجم',fmtKb(kb),'kb')}
  <div style="display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:8px;padding:10px 0;align-items:center;font-size:13px"><span class="m">آخر تحديث</span><b style="text-align:center;font-size:12.5px;line-height:1.5">${dtF(S._u)}</b><b id="sc-up" style="text-align:center;color:var(--mut);font-size:12.5px;line-height:1.5">…</b></div>
 </div>
 <div class="m" style="margin:12px 2px;line-height:1.7">تُرفع تغييراتك إلى حسابك تلقائياً وتتحدّث الأجهزة الأخرى من تلقاء نفسها. استخدم الاسترجاع إذا لم تجد بياناتك على هذا الجهاز.</div>
 <button type="button" id="sc-rs" disabled style="opacity:.5;width:100%" onclick="syncRestore()">استرجاع بيانات الحساب</button>
 ${prevGet()?'<button type="button" class="g" style="width:100%" onclick="restorePrev()">استعادة بيانات الجهاز السابقة</button>':''}
 <button type="button" class="g" style="width:100%" onclick="$('#sh').innerHTML=''">إغلاق</button>`);
 const set=(id,t)=>{const e=document.getElementById('sc-'+id);if(e){e.textContent=t;e.style.color='var(--tx)'}};
 try{const c=await readCloud(fu.uid);
  if(!c){set('nb','—');set('td','—');set('lg','—');set('kb','—');set('up','—');const st=document.getElementById('sc-st');if(st)st.lastElementChild.textContent='لا توجد نسخة في حسابك بعد، ستُرفع تلقائياً';return}
  const o=JSON.parse(c.d),C=dStat(o);
  set('nb',C.nb);set('td',C.td);set('lg',C.lg);set('kb',fmtKb(Math.max(1,Math.round(c.d.length/1024))));set('up',dtF(c.u));
  const st=document.getElementById('sc-st');if(st){st.lastElementChild.textContent=c.u>(S._u||0)?'حسابك يحتوي على نسخة أحدث':c.u<(S._u||0)?'تعديلاتك الأخيرة قيد الرفع':'البيانات محدّثة ومتطابقة'}
  const b=document.getElementById('sc-rs');if(b){b.disabled=false;b.style.opacity=1}
 }catch(e){['nb','td','lg','kb','up'].forEach(i=>set(i,'؟'));const st=document.getElementById('sc-st');if(st)st.lastElementChild.textContent='تعذّر الاتصال بحسابك، حاول لاحقاً'}}
function syncRestore(){
 ask('سيتم استبدال بيانات هذا الجهاز ببيانات حسابك المحفوظة في السحابة. نحتفظ بنسخة من بيانات الجهاز الحالية لتتمكن من استعادتها لاحقاً.',async()=>{
  try{const c=await readCloud(fu.uid);if(!c){toast('لا توجد نسخة في حسابك');return}
   const cl=JSON.parse(c.d);let saved=false;
   try{localStorage.setItem('qmrm_prev_'+fu.uid,JSON.stringify({at:Date.now(),s:S}));saved=true}catch(e){dbg(e)}
   if(!saved&&localExtra(cl)){synBar('تعذّر حفظ نسخة احتياطية من بيانات الجهاز بسبب امتلاء المساحة، لذلك لم يتم الاسترجاع.',1);setTimeout(()=>synBar(''),9000);return}
   adopt(cl,0);toast('تم استرجاع بيانات حسابك')
  }catch(e){toast('تعذّر الاسترجاع، تأكد من الاتصال')}},'نعم، استرجع','إلغاء')}
function settings(){const P=prof(),E=pe.on,u=fu;
 const row=(i,l,v,x)=>`<div class="prow"><span class="pi">${svg(i)}</span><span class="pl">${l}</span><span class="pv">${v}</span>${x||''}</div>`;
 const act=(i,l,f,bad)=>`<div class="prow act" onclick="${f}"><span class="pi" ${bad?'style="background:#e5393522;color:var(--bad)"':''}>${svg(i)}</span><span class="pl" ${bad?'style="color:var(--bad)"':''}>${l}</span><span class="ch">${svg('chev')}</span></div>`;
 const copy=v=>v?`<a class="cpb" data-v="${esc(v)}" onclick="cp(this.dataset.v)">${svg('copy')}</a>`:'';
 const inp=(k,ph,t)=>`<input type="${t||'text'}" placeholder="${ph}" value="${esc(P[k]||'')}" oninput="prof().${k}=this.value;save()" style="margin:0;max-width:150px;padding:6px 8px">`;
 return `<div class="pg"><div class="row sp" style="padding:14px 16px"><button type="button" class="pbtn bk" onclick="go('home')">${svg('chev')}</button><b style="font-size:19px">الملف الشخصي</b><button type="button" class="pbtn" onclick="pe.on=!pe.on;draw()">${svg(E?'check':'edit')}</button></div>
 <div style="text-align:center;padding:4px 0 14px"><div style="position:relative;width:112px;margin:0 auto"><div class="pav">${avatar()}</div>${E?`<label class="pbtn" style="position:absolute;bottom:-2px;inset-inline-end:-2px;width:36px;height:36px;background:var(--pri);color:#fff;cursor:pointer">${svg('camera')}<input type="file" accept="image/*" style="display:none" onchange="pickPhoto(this)"></label>`:''}</div>
 ${E?`<input value="${esc(P.name||'')}" placeholder="الاسم" oninput="prof().name=this.value;save()" style="text-align:center;max-width:240px;margin:12px auto 0;font-weight:700">`:`<div style="font-size:24px;font-weight:700;margin-top:12px">${esc(P.name||(u&&u.displayName)||'ضيف')}</div>`}
 <div class="m" dir="ltr" style="margin-top:2px">${esc(handle())}</div></div>
 <div class="ph">معلومات الحساب</div><div class="pcard">
 ${row('idcard','اسم المستخدم',(E&&u)?`<input id="unin" value="${esc(P.user||'')}" placeholder="اسم المستخدم" dir="ltr" style="margin:0;max-width:120px;padding:6px 8px"><button type="button" class="g" style="padding:6px 10px" onclick="unSave()">حفظ</button>`:`<span dir="ltr">${esc(P.user||'—')}</span>`,copy(P.user))}
 ${row('mail','البريد الإلكتروني',u?`<span dir="ltr">${esc(u.email||'')}</span>`:'غير مسجّل',copy(u&&u.email))}
 ${row('hourglass',E?'تاريخ الميلاد':'العمر',E?`<input type="date" value="${esc(P.bd||'')}" max="${ymd(new Date())}" onchange="prof().bd=this.value;save()" style="margin:0;padding:6px 8px">`:(ageOf(P)!==''?ageOf(P)+' سنة':'—'))}
 ${row('users','الجنس',E?`<select onchange="prof().gender=this.value;save()" style="margin:0;padding:6px 8px"><option value="">—</option><option ${P.gender=='ذكر'?'selected':''}>ذكر</option><option ${P.gender=='أنثى'?'selected':''}>أنثى</option></select>`:(P.gender||'—'))}
 ${row('globe','بلد الإقامة',E?`<button type="button" class="g" onclick="ctrySheet()" style="padding:6px 10px">${cName(P.country)} ▾</button>`:cName(P.country))}
 ${row('calendar','عضو منذ',esc(S.since||'—'))}</div>
 ${accCard()}<div class="ph">إعدادات الحساب</div><div class="pcard">
 ${u?act('users','المعلّم والطلاب',"go('tc')")+act('lock',((u&&u.providerData||[]).some(x=>x.providerId==='password'))?'تغيير كلمة المرور':'إنشاء كلمة مرور','chPass()')+act('cloud','المزامنة واسترجاع البيانات','syncSheet()')+act('logout','تسجيل الخروج',"ask('تسجيل الخروج يمسح البيانات من هذا الهاتف وتبقى محفوظة في حسابك. متابعة؟',out,'نعم، اخرج')"):''}
 ${u?act('userx','حذف الحساب نهائياً',"typedAsk('حذف الحساب نهائياً','سيُحذف حسابك واسم المستخدم وكل بياناتك السحابية نهائياً ولا يمكن التراجع.','delAcc')",1):act('trash','حذف بياناتي من الجهاز',"typedAsk('حذف بيانات الجهاز','ستُحذف كل بياناتك المحفوظة في هذا الجهاز ولا يمكن التراجع.','wipe')",1)}</div>
 <div id="sm" aria-live="polite" style="padding:10px 24px;min-height:24px;font-size:14px">${esc(sm)}</div></div>`}

/* ===== جودة الكود: تسجيل الأخطاء بدل إخفائها ===== */
const QERR=[];function dbg(e,w){try{QERR.push({t:Date.now(),w:w||'',m:String(e&&e.message||e)});if(QERR.length>30)QERR.shift();console.warn('[مثبّت]',w||'',e&&e.message||e)}catch(_){}}
window.addEventListener('error',e=>dbg(e.error||e.message,'window'));window.addEventListener('unhandledrejection',e=>dbg(e.reason,'promise'));
/* ===== إمكانية الوصول: أسماء للأزرار الأيقونية وتنقّل بالكيبورد ===== */
(function(){const N={chev:'رجوع',edit:'تعديل',check:'تم',camera:'تغيير الصورة',copy:'نسخ',plus:'إضافة',trash:'حذف',bell:'التنبيهات',dots:'المزيد',refresh:'تحديث',download:'تنزيل',play:'تشغيل',pause:'إيقاف مؤقت',reset:'إعادة',volume:'الصوت',sun:'الوضع النهاري',moon:'الوضع الليلي',lock:'قفل',unlock:'فتح',lines:'القائمة',grid:'الأقسام',cloud:'المزامنة',user:'الحساب',users:'المعلّم والطلاب',logout:'تسجيل الخروج',mail:'البريد'};
let q=0;function fix(){q=0;document.querySelectorAll('button,[onclick]').forEach(b=>{if(b.tagName!='BUTTON'){if(!b.getAttribute('role'))b.setAttribute('role','button');if(!b.hasAttribute('tabindex'))b.tabIndex=0}
if(!b.getAttribute('aria-label')&&!(b.textContent||'').trim()){const i=b.querySelector('.ic'),l=N[i&&i.dataset.k]||b.title;if(l)b.setAttribute('aria-label',l)}});
document.querySelectorAll('input,select,textarea').forEach(i=>{if(!i.getAttribute('aria-label')&&!i.id.startsWith('x')){const l=i.placeholder||i.title;if(l)i.setAttribute('aria-label',l)}});
const nv=document.getElementById('nav');if(nv){nv.setAttribute('role','navigation');nv.setAttribute('aria-label','التنقل الرئيسي');nv.querySelectorAll('button').forEach(b=>b.classList.contains('on')?b.setAttribute('aria-current','page'):b.removeAttribute('aria-current'))}}
new MutationObserver(()=>{if(!q){q=1;requestAnimationFrame(fix)}}).observe(document.body,{childList:true,subtree:true});
document.addEventListener('keydown',e=>{const x=e.target;if((e.key=='Enter'||e.key==' ')&&x.getAttribute&&x.getAttribute('role')=='button'&&x.tagName!='BUTTON'){e.preventDefault();x.click()}});fix()})();

/* ===== TEACH: وضع المعلّم والطالب =====
 invites/{CODE}: {uid,name,exp}  — كود الطالب الدائم (يُنشأ مرة واحدة فقط)
 links/{studentUid_teacherUid}: {s,t,sn,tn,code,as:[{id,t,d,c}],dn:{id:{v:1|0|null,n,t}},sum}
   sum = ملخص + تفاصيل إنجازات الطالب (للقراءة فقط عند المعلّم): st,wk,n,m,last,ps,pr,lg,jz
   الطالب يكتب: sum,dn,sn   —   المعلّم يكتب: as,tn   (القواعد كما هي) */
let tcM='s',tcSel=null,tcL=[],tcBusy=0,tcLast=0,tcAt=0,tcOp=null,tcTb='pr',tcEns=0,tcPd=0;
const TCFAR=4102444800000;
let tcChWant=null,tcMsgs={},tcChU=null,tcChId=null,tcChE=0;
(function(){const s=document.createElement('style');s.textContent=`
.tcT{overflow-x:auto}.tcT div{flex:1 0 auto;padding:9px 10px}
.tcMs{display:flex;flex-direction:column;gap:6px;max-height:340px;min-height:90px;overflow-y:auto;padding:8px 2px;margin-top:6px}
.tcMg{max-width:82%;padding:8px 12px;border-radius:16px;white-space:pre-wrap;word-break:break-word;line-height:1.5}
.tcMg small{display:block;font-size:10px;opacity:.7;margin-top:2px}
.tcMg.me{align-self:flex-start;background:var(--pri);color:var(--on);border-end-start-radius:4px}
.tcMg.ot{align-self:flex-end;background:color-mix(in srgb,var(--pri) 10%,var(--card));border:1px solid var(--bd);border-end-end-radius:4px}
`;document.head.appendChild(s)})();
(function(){const s=document.createElement('style');s.textContent=`
.tcT{display:flex;gap:4px;margin:10px 12px 0;padding:4px;background:color-mix(in srgb,var(--pri) 8%,transparent);border-radius:14px}
.tcT div{flex:1;text-align:center;padding:9px 2px;border-radius:11px;font-size:13px;color:var(--mut);cursor:pointer;white-space:nowrap}
.tcT div.on{background:var(--card);color:var(--pri);font-weight:700;box-shadow:0 1px 6px rgba(0,0,0,.14)}
.tcH{display:flex;align-items:center;gap:12px;cursor:pointer}
.tcH>div:nth-child(2){flex:1;min-width:0}
.tcAv{width:44px;height:44px;border-radius:50%;background:var(--pri);color:var(--on);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:19px;flex:none}
.tcCd{font-size:34px;font-weight:800;letter-spacing:8px;text-align:center;direction:ltr;padding:16px 8px;margin:10px 0 4px;border:2px dashed var(--gold);border-radius:16px;cursor:pointer;color:var(--pri);user-select:all}
.tcK{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:12px 0 4px}
.tcK div{background:color-mix(in srgb,var(--pri) 7%,transparent);border-radius:12px;padding:10px 4px;text-align:center}
.tcK b{display:block;font-size:20px}.tcK span{font-size:11px;color:var(--mut)}
.tcDot{width:20px;height:20px;border-radius:50%;display:inline-block;background:var(--bd);vertical-align:middle}
.tcDot.m{background:#2e7d32}.tcDot.h{background:#f9a825}.tcDot.x{background:#c62828}
.tcP{width:100%;border-collapse:collapse;text-align:center;font-size:12px}
.tcP th{color:var(--mut);font-weight:600;padding:4px 0}.tcP td{padding:5px 0;border-top:1px solid var(--bd)}
.tcP td:first-child{text-align:start;font-weight:600;white-space:nowrap}.tcP small{display:block;font-size:10px;line-height:1;margin-top:2px;color:var(--mut)}
.tcA{border:1px solid var(--bd);border-inline-start:4px solid var(--bd);border-radius:14px;padding:12px;margin:8px 0;background:var(--card)}
.tcA.ok{border-inline-start-color:#2e7d32}.tcA.no{border-inline-start-color:#c62828}
.tcB{display:flex;gap:8px;margin:10px 0 8px}
.tcB button{flex:1;padding:10px 6px;border-radius:12px;border:1.5px solid var(--bd);background:var(--card);color:var(--tx);font-weight:700;font-size:15px}
.tcB button.y.on{background:#2e7d32;border-color:#2e7d32;color:#fff}.tcB button.n.on{background:#c62828;border-color:#c62828;color:#fff}
.tcNote{background:color-mix(in srgb,var(--gold) 14%,transparent);border-radius:10px;padding:8px 10px;margin-top:8px;font-size:13px}
.tcS{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:700;background:var(--bd);color:var(--mut)}
.tcS.ok{background:#2e7d32;color:#fff}.tcS.no{background:#c62828;color:#fff}
.tcIm{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.tcTh{width:72px;height:72px;border-radius:10px;overflow:hidden;background:var(--bd);display:flex;align-items:center;justify-content:center;cursor:pointer}.tcTh img{width:100%;height:100%;object-fit:cover}
#tcLb{position:fixed;inset:0;z-index:30;background:#000e;display:flex;align-items:center;justify-content:center}#tcLb img{max-width:96%;max-height:92%}
.tcCol{display:flex;align-items:center;gap:8px;padding:10px 12px;cursor:pointer;opacity:.85}.tcCol b{flex:1;font-weight:600;font-size:15px}.tcDot{width:10px;height:10px;border-radius:50%;background:#e53935;animation:tcP 1s infinite}@keyframes tcP{50%{opacity:.3}}#tcRb .ic{color:#fff}
.tcTh{position:relative}.tcC{display:flex;align-items:center;justify-content:center;width:100%;height:100%}.tcX{position:absolute;top:2px;left:2px;background:#000a;color:#fff;border-radius:50%;width:20px;height:20px;font-size:12px;display:flex;align-items:center;justify-content:center;z-index:2}
.tcTh.tcAu{width:100%;height:auto;background:none;overflow:visible;cursor:default}.tcAu audio{width:100%}
#tcRb{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:40;background:#222;color:#fff;padding:10px 14px;border-radius:30px;display:flex;gap:10px;align-items:center;box-shadow:0 4px 20px #0006}#tcRb button{padding:6px 12px;margin:0}
.tcBadge{min-width:22px;height:22px;border-radius:11px;background:var(--gold);color:#fff;font-size:12px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;padding:0 6px}
`;document.head.appendChild(s)})();
const tcMe=()=>prof().name||(fu&&fu.displayName)||'';
const TCE={'tc-bad':'الكود غير صحيح','tc-self':'لا يمكنك ربط نفسك','tc-dup':'هذا الطالب مرتبط بك مسبقاً','permission-denied':'لا توجد صلاحية: حدّث قواعد Firestore (انظر الملف المرفق)'};
const tcErr=e=>{dbg(e,'tc');toast('⚠️ '+(TCE[e.code]||'حدث خطأ، حاول لاحقاً'))};
const tcSt=(l,a)=>{const d=(l.dn||{})[a];return typeof d=='number'?{v:1,t:d,n:''}:(d||{})};
const tcIn=n=>(String(n||'').trim()[0]||'؟');
function tcSum(){const ds=new Set(S.logs.map(l=>l.date));let st=0,d=new Date();if(!ds.has(ymd(d)))d=new Date(d-864e5);while(ds.has(ymd(d))){st++;d=new Date(d-864e5)}
 const P=S.pr||{days:{}},pr={};
 for(let i=0;i<30;i++){const k=ymd(new Date(Date.now()-i*864e5)),r=(P.days||{})[k];if(!r)continue;const a=PK.map(p=>r[p]&&r[p].s||'-').join('');if(a=='-----')continue;pr[k]=a+PK.map(p=>r[p]&&r[p].s&&r[p].s!='x'?(r[p].t||0):0).join('')}
 let jz=[];try{jz=[...Array(30)].map((_,i)=>{const j=i+1,a=jmAge(j);return jmSt(j)+','+(a===null?'':a)+','+(((S.juz||{})[j]||{}).n||0)})}catch(e){dbg(e,'tcSum')}
 const lg=S.logs.slice(-40).reverse().map(l=>({d:l.date||'',s:String(l.s||'').slice(0,40),r:l.r||'',tm:l.time||'',m:l.dur||0}));
 return{st,wk:[...Array(7)].map((_,i)=>S.logs.filter(l=>l.date==ymd(new Date(Date.now()-(6-i)*864e5))).length),n:S.logs.length,m:S.logs.filter(l=>l.r=='mastered').length,last:S.logs.reduce((a,l)=>l.date>a?l.date:a,''),ps:P.start||'',pr,lg,jz,u:Date.now()}}
async function tcLoad(){if(!fbOK||!fu)return;try{const[a,b]=await Promise.all([fs.collection('links').where('s','==',fu.uid).get(),fs.collection('links').where('t','==',fu.uid).get()]);tcL=[...a.docs.map(d=>Object.assign({id:d.id,r:'s'},d.data())),...b.docs.map(d=>Object.assign({id:d.id,r:'t'},d.data()))]}catch(e){tcErr(e)}}
async function tcPub(force){if(!fbOK||!fu||(!force&&Date.now()-tcLast<6e5))return;tcLast=Date.now();try{const q=await fs.collection('links').where('s','==',fu.uid).get();if(q.empty)return;const sm=tcSum(),sn=tcMe();await Promise.all(q.docs.map(d=>{const v=d.data();return v.off?(v.sum?d.ref.update({sum:null}):0):d.ref.update({sum:sm,sn})}))}catch(e){dbg(e,'tcPub')}}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')tcPub()});
/* كود الطالب: يُنشأ مرة واحدة ويبقى ثابتاً */
const tcCode=()=>(S.tcCode&&S.tcCode.c)||'';
async function tcEnsure(){if(tcBusy||!fbOK||!fu)return;tcBusy=1;
 try{const col=fs.collection('invites'),val=()=>({uid:fu.uid,name:tcMe(),exp:TCFAR});let c=tcCode(),ok=false;
  await tcLoad();
  if(c){const used=tcL.some(l=>l.r=='s'&&l.code==c),r=col.doc(c),d=await r.get(),mine=d.exists&&d.data().uid==fu.uid;
   if(used){if(mine)await r.delete().catch(dbg)}else if(mine)ok=true}
  if(!ok){const A='ABCDEFGHJKMNPQRSTUVWXYZ23456789';
   for(let t=0;t<8&&!ok;t++){c='';for(let i=0;i<6;i++)c+=A[Math.floor(Math.random()*A.length)];const r=col.doc(c);if((await r.get()).exists)continue;
    try{await r.set(val());ok=true}catch(e){if(e.code!='permission-denied'||t==7)throw e}}
   if(ok){S.tcCode={c};save()}}
 }catch(e){if(Date.now()-tcEE>6e4){tcEE=Date.now();tcErr(e)}tcEns=1;setTimeout(()=>{tcEns=0},6e4)}tcBusy=0}
async function tcRegen(){const c=tcCode();try{if(c)await fs.collection('invites').doc(c).delete()}catch(e){dbg(e)}S.tcCode=null;save();tcEns=0;draw()}
async function tcJoin(){const c=($('#tcc').value||'').trim().toUpperCase();if(!/^[A-Z0-9]{6}$/.test(c)){toast('الكود 6 خانات');return}if(tcBusy)return;tcBusy=1;
 try{const inv=fs.collection('invites').doc(c),d=await inv.get();if(!d.exists||d.data().exp<Date.now())throw{code:'tc-bad'};const v=d.data();if(v.uid==fu.uid)throw{code:'tc-self'};
  const ref=fs.collection('links').doc(v.uid+'_'+fu.uid),sn=await ref.get(),old=sn.exists?sn.data():null;if(old&&!old.off)throw{code:'tc-dup'};
  const run=async del=>{const bt=fs.batch();if(old)bt.update(ref,{off:false,code:c,tn:tcMe()});else bt.set(ref,{s:v.uid,t:fu.uid,sn:v.name||'',tn:tcMe(),code:c,as:[],dn:{},sum:null,c:Date.now(),off:false});if(del)bt.delete(inv);await bt.commit()};
  try{await run(true)}catch(e){if(e.code=='permission-denied')await run(false);else throw e}
  await tcLoad();toast(old?'أُعيد ربط الطالب وعادت واجباته السابقة ✅':'تم ربط الطالب ✅')}catch(e){tcErr(e)}tcBusy=0;draw()}
/* ---- الصور: تُضغط ثم تُحفظ في links/{id}/files/{fid} ---- */
let tcPend=[],tcDraft={t:'',d:'',all:false,sel:[]},tcUnId='';const tcImC={};
const tcOkU=u=>/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(u||'');
const tcCmp=f=>new Promise((ok,no)=>{const r=new FileReader();r.onerror=no;r.onload=()=>{const im=new Image();im.onerror=no;im.onload=()=>{let k=Math.min(1,1280/Math.max(im.width,im.height)),q=.72,u;const c=document.createElement('canvas');for(let n=0;n<5;n++){c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);u=c.toDataURL('image/jpeg',q);if(u.length<600000)break;k*=.75;q-=.08}ok(u)};im.src=r.result};r.readAsDataURL(f)});
const tcPick=cb=>{const x=document.createElement('input');x.type='file';x.accept='image/*';x.multiple=true;x.onchange=async()=>{const fl=[...x.files].slice(0,4);if(!fl.length)return;toast('جارٍ تجهيز الصور…');try{cb(await Promise.all(fl.map(tcCmp)))}catch(e){dbg(e,'img');toast('⚠️ تعذّر قراءة الصورة')}};x.click()};
async function tcUp(i,u,o){const id=Date.now().toString(36)+Math.random().toString(36).slice(2,6);await fs.collection('links').doc(i).collection('files').doc(id).set({d:u,u:fu.uid,o,c:Date.now()});tcImC[id]=u;return id}
function tcSelTg(i){const s=tcDraft.sel||[];tcDraft={t:($('#tct')||{}).value||'',d:($('#tcd')||{}).value||'',all:!!($('#tcall')||{}).checked,sel:s.includes(i)?s.filter(x=>x!=i):[...s,i]};draw()}
(function(){const st=document.createElement('style');st.textContent='.tqPk{display:flex;flex-wrap:wrap;gap:8px;margin:6px 0 10px}.tqPkB{background:transparent;color:var(--tx);border:1.5px solid var(--bd);border-radius:20px;padding:8px 14px;width:auto;margin:0}.tqPkB.on{background:var(--pri);color:var(--on);border-color:var(--pri)}.tqMx{display:inline-flex;vertical-align:middle;margin-inline-start:10px;opacity:.8;cursor:pointer;padding:2px}.tqMx .ic{width:15px;height:15px}';document.head.appendChild(st)})();
const tcAddPend=us=>{tcDraft={t:($('#tct')||{}).value||'',d:($('#tcd')||{}).value||'',all:!!($('#tcall')||{}).checked,sel:tcDraft.sel||[]};tcPend=[...tcPend,...us].slice(0,4);draw()};
const tcOkA=u=>/^data:audio\/(webm|ogg|mp4|mpeg|aac|x-m4a)(;codecs=[\w.,-]+)?;base64,[A-Za-z0-9+\/=]+$/.test(u||'');
let tcEE=0;
const tcIn1=f=>{const u=tcImC[f];return tcOkU(u)?`<img alt="" src="${u}">`:tcOkA(u)?`<audio controls preload="none" src="${u}"></audio>`:u=='-'?'—':'⏳'};
const tcCl=f=>tcOkA(tcImC[f])?' tcAu':'',tcOk=f=>tcImC[f]?' data-ok="1"':'';
const tcThs=(i,ids,rm)=>(ids&&ids.length)?`<div class="tcIm">${ids.map(f=>`<div class="tcTh${tcCl(f)}"${tcOk(f)} data-l="${esc(i)}" data-f="${esc(f)}" onclick="tcView(this)"><span class="tcC">${tcIn1(f)}</span>${rm?`<span class="tcX" data-i="${esc(i)}" data-a="${esc(rm)}" data-f="${esc(f)}" onclick="event.stopPropagation();tcRmAsk(this.dataset.i,this.dataset.a,this.dataset.f)">✕</span>`:''}</div>`).join('')}</div>`:'';
async function tcHyd(){for(const e of document.querySelectorAll('.tcTh[data-f]:not([data-ok])')){e.dataset.ok=1;const f=e.dataset.f,c=e.querySelector('.tcC');try{let u=tcImC[f];if(!u){const d=await fs.collection('links').doc(e.dataset.l).collection('files').doc(f).get();u=d.exists?d.data().d:'-';tcImC[f]=u}c.textContent='';if(tcOkU(u)){const im=new Image();im.src=u;c.appendChild(im)}else if(tcOkA(u)){e.classList.add('tcAu');const au=document.createElement('audio');au.controls=true;au.preload='none';au.src=u;c.appendChild(au)}else c.textContent='—'}catch(er){dbg(er);c.textContent='⚠️'}}}
function tcView(e){const u=tcImC[e.dataset.f];if(!tcOkU(u))return;const o=document.createElement('div'),im=new Image();o.id='tcLb';o.onclick=()=>o.remove();im.src=u;o.appendChild(im);document.body.appendChild(o)}
/* تسجيل صوتي (حتى 60 ثانية) */
let tcRc=null;
async function tcRecord(cb){if(tcRc)return;try{const st=await navigator.mediaDevices.getUserMedia({audio:true}),mr=new MediaRecorder(st,{audioBitsPerSecond:24000}),ch=[];let n=0,cancel=false;
 const bar=document.createElement('div');bar.id='tcRb';bar.innerHTML='<span class="tcDot"></span><span id="tcRt">0:00</span><button type="button" id="tcRs">'+svg('stop')+' إرسال</button><button type="button" id="tcRx">'+svg('xmark')+'</button>';document.body.appendChild(bar);
 const end=()=>{clearInterval(iv);st.getTracks().forEach(t=>t.stop());bar.remove();tcRc=null};
 mr.ondataavailable=e=>{if(e.data.size)ch.push(e.data)};
 mr.onstop=()=>{end();if(cancel)return;const r=new FileReader();r.onload=()=>{if(r.result.length>780000){toast('⚠️ التسجيل طويل، اجعله أقصر');return}cb(r.result)};r.readAsDataURL(new Blob(ch,{type:mr.mimeType||'audio/webm'}))};
 const iv=setInterval(()=>{n++;const t=$('#tcRt');if(t)t.textContent=Math.floor(n/60)+':'+String(n%60).padStart(2,'0');if(n>=60)mr.stop()},1000);
 $('#tcRs').onclick=()=>mr.stop();$('#tcRx').onclick=()=>{cancel=true;mr.stop()};tcRc=mr;mr.start()}catch(e){dbg(e);toast('⚠️ لا يمكن الوصول للميكروفون')}}
async function tcPush(i,a,us){const l=tcG(i);if(!l)return;const o=tcSt(l,a),cur=o.im||[];if(cur.length+us.length>5){toast('الحد الأقصى 5 مرفقات للواجب');return}
 try{toast('جارٍ الرفع…');const ids=[];for(const u of us)ids.push(await tcUp(i,u,'s'));const e={v:o.v==null?null:o.v,t:Date.now(),n:o.n||'',im:[...cur,...ids],...tcSK(o)};await fs.collection('links').doc(i).update({['dn.'+a]:e});(l.dn=l.dn||{})[a]=e;toast('تم الإرسال ✅');draw()}catch(er){tcErr(er);draw()}}
const tcSend=(i,a)=>tcPick(us=>tcPush(i,a,us)),tcSendA=(i,a)=>tcRecord(u=>tcPush(i,a,[u]));
const tcSK=o=>o.sent===undefined?(o.v==null?{sent:0}:{}):{sent:o.sent};
const tcSent=(l,id)=>{const o=tcSt(l,id);return o.v!=null&&(o.sent===undefined||o.sent>0)};
function tcSendHw(i,a){const l=tcG(i);if(!l)return;const o=tcSt(l,a);if(o.v==null){toast('اختر صح أو غلط أولاً');return}
 ask('إرسال الواجب للمعلّم ونقله إلى الأرشيف؟',async()=>{const e={v:o.v,t:Date.now(),n:o.n||'',im:o.im||[],sent:Date.now()};try{await fs.collection('links').doc(i).update({['dn.'+a]:e});(l.dn=l.dn||{})[a]=e;toast('تم إرسال الواجب ✅');draw()}catch(er){tcErr(er)}},'نعم، أرسل')}
const tcReopenAsk=(i,a)=>ask('إعادة الواجب إلى القائمة لتعديله؟',async()=>{const l=tcG(i);if(!l)return;const o=tcSt(l,a),e={v:o.v,t:Date.now(),n:o.n||'',im:o.im||[],sent:0};try{await fs.collection('links').doc(i).update({['dn.'+a]:e});l.dn[a]=e;draw()}catch(er){tcErr(er)}});
/* قسم «الواجبات» في الأرشيف */
let tcArT=0;
function tcArc(){setTimeout(tcHyd,80);
 if(!fbOK||!fu)return '<div class="c m">سجّل الدخول لعرض الواجبات.</div>';
 if(Date.now()-tcArT>3e4){tcArT=Date.now();const sg=JSON.stringify(tcL);tcLoad().then(()=>{if(sg!==JSON.stringify(tcL)&&tab=='ar'&&arSec=='w'){const a=document.activeElement;if(!(a&&/INPUT|TEXTAREA/.test(a.tagName)))draw()}})}
 const dtf=ms=>ms?dt(new Date(ms).toISOString()):'—';
 const row=(l,a,x,stu)=>{const nm=stu?(l.tn||'معلّم'):(l.sn||'طالب'),d=`data-i="${esc(l.id)}" data-a="${esc(a.id)}"`,w=x.sent||x.t||0;
  const det=`${a.d?'<div>موعد التسليم: '+esc(a.d)+'</div>':''}<div>أُرسل: ${dtf(w)}</div>${tcThs(l.id,a.im)}${x.n?`<div class="tcNote">${esc(x.n)}</div>`:''}${(x.im||[]).length?'<div>مرفقات الحل</div>'+tcThs(l.id,x.im):''}${stu?tcFbH(a):''}`;
  const btn=stu?`<button type="button" class="g" style="padding:5px 12px" ${d} onclick="tcReopenAsk(this.dataset.i,this.dataset.a)">إعادة للقائمة</button>`:tcFbT(l,a)+`<button type="button" class="r" style="padding:5px 12px;margin-top:8px" ${d} onclick="tcAsAsk(this.dataset.i,this.dataset.a)">حذف الواجب</button>`;
  return{t:w,h:arCard('w'+l.id+a.id,esc(a.t),x.v===1?'✓ صح':'✗ غلط',esc(nm)+' • '+dtf(w),det,btn)}};
 const mk=role=>{const out=[];tcL.filter(l=>l.r==role&&!l.off).forEach(l=>(l.as||[]).forEach(a=>{if(tcSent(l,a.id))out.push(row(l,a,tcSt(l,a.id),role=='s'))}));return out.sort((x,y)=>y.t-x.t).map(x=>x.h).join('')};
 const st=mk('s'),tc=mk('t');
 return (tc?'<div class="ph">واجبات طلابي المُرسَلة</div>'+tc:'')+(st?'<div class="ph">واجباتي المُرسَلة</div>'+st:'')||'<div class="c m">لا واجبات مُرسَلة بعد. تظهر هنا الواجبات بعد أن يضغط الطالب «إرسال الواجب».</div>'}
Object.assign(EN,{"إرسال الواجب ونقله للأرشيف":"Send homework & archive","الواجبات":"Homework","إعادة للقائمة":"Move back to list","واجبات طلابي المُرسَلة":"Homework sent by my students","واجباتي المُرسَلة":"My sent homework"});
const tcEx={};const tcTog=k=>{tcEx[k]=!tcEx[k];draw()};
const tcFDel=(i,ids)=>Promise.all((ids||[]).map(f=>fs.collection('links').doc(i).collection('files').doc(f).delete().catch(dbg)));
const tcFileIds=l=>[...(l.as||[]).flatMap(a=>a.im||[]),...Object.values(l.dn||{}).flatMap(x=>(x&&x.im)||[])];
async function tcRm(i,a,f){const l=tcG(i);if(!l)return;const o=tcSt(l,a),e={v:o.v==null?null:o.v,t:Date.now(),n:o.n||'',im:(o.im||[]).filter(x=>x!=f),...tcSK(o)};try{await fs.collection('links').doc(i).update({['dn.'+a]:e});l.dn[a]=e;tcFDel(i,[f]);draw()}catch(er){tcErr(er)}}
const tcRmAsk=(i,a,f)=>ask('حذف هذا المرفق؟',()=>tcRm(i,a,f));
const tcPendRm=k=>{tcDraft={t:($('#tct')||{}).value||'',d:($('#tcd')||{}).value||'',all:!!($('#tcall')||{}).checked,sel:tcDraft.sel||[]};tcPend=tcPend.filter((_,j)=>j!=k);draw()};
/* ردّ المعلّم على الواجب */
async function tcFb(i,a,v,txt){const l=tcG(i);if(!l)return;const as=(l.as||[]).map(x=>{if(x.id!=a)return x;const f=x.fb||{};return{...x,fb:{v:v===undefined?(f.v||null):(f.v===v?null:v),n:txt===undefined?(f.n||''):String(txt).trim().slice(0,300),t:Date.now()}}});
 try{await fs.collection('links').doc(i).update({as});l.as=as;draw()}catch(e){tcErr(e)}}
const tcFbH=a=>{const f=a.fb;return f&&(f.v||f.n)?`<div class="tcNote" style="margin:6px 0">${svg('grad')} ${f.v=='ok'?'⭐ ممتاز ':f.v=='redo'?'🔁 يُعاد ':''}${esc(f.n||'')}</div>`:''};
const tcFbT=(l,a)=>{const f=a.fb||{},d=`data-i="${esc(l.id)}" data-a="${esc(a.id)}"`;return `<div class="tcB" style="margin-top:8px"><button type="button" class="y ${f.v=='ok'?'on':''}" ${d} onclick="tcFb(this.dataset.i,this.dataset.a,'ok')">⭐ ممتاز</button><button type="button" class="n ${f.v=='redo'?'on':''}" ${d} onclick="tcFb(this.dataset.i,this.dataset.a,'redo')">🔁 يُعاد</button></div><input placeholder="ردّ على الطالب (اختياري)" maxlength="300" value="${esc(f.n||'')}" ${d} onchange="tcFb(this.dataset.i,this.dataset.a,undefined,this.value)" style="margin:6px 0 0">`};
/* علامة «جديد» (محفوظة على الجهاز) */
const tcSnG=()=>{try{return JSON.parse(localStorage.getItem('tcSeen')||'{}')}catch(e){return{}}};
const tcSnS=i=>{try{const o=tcSnG();o[i]=Date.now();localStorage.setItem('tcSeen',JSON.stringify(o))}catch(e){}};
const tcNew=l=>{const o=tcSnG();if(!(l.id in o)){tcSnS(l.id);return 0}const sn=o[l.id];return l.r=='s'?(l.as||[]).filter(a=>(a.c||0)>sn||((a.fb||{}).t||0)>sn).length:Object.values(l.dn||{}).filter(x=>x&&typeof x=='object'&&(x.sent===undefined||x.sent>0)&&(x.sent||x.t||0)>sn).length};
Object.assign(EN,{"حذف المعلّم":"Remove teacher","🔄 كود جديد":"🔄 New code","📷 إرسال صورة الواجب":"📷 Send a photo","🎙️ تسجيل صوتي":"🎙️ Voice recording","⭐ ممتاز":"⭐ Excellent","🔁 يُعاد":"🔁 Redo","جديد":"New","📎 صور الطالب":"📎 Student attachments","إرسال لجميع طلابي":"Send to all my students","📷 إرفاق صورة":"📷 Attach photo","🎙️ تسجيل":"🎙️ Record","⏹ إرسال":"⏹ Send","ملاحظة لمعلّمك (اختياري)":"Note to your teacher (optional)","ردّ على الطالب (اختياري)":"Reply to student (optional)","اضغط على الكود لنسخه":"Tap the code to copy it","كودك يُستعمل مرة واحدة فقط، وبعد أن يضيفك المعلّم يتغيّر تلقائياً. أعطه لمعلّمك ليضيفك ويرسل لك الواجبات.":"Your code works once only and changes automatically after your teacher adds you. Give it to your teacher so they can add you and send you assignments."});
const tcG=i=>tcL.find(x=>x.id==i);
/* المعلّم: إضافة/حذف واجب وفصل الطالب */
async function tcAs(i){const l=tcG(i),t=($('#tct').value||'').trim(),d=$('#tcd').value,all=!!($('#tcall')||{}).checked;if(!l||(!t&&!tcPend.length))return;
 const sel=tcDraft.sel||[],tg=all?tcL.filter(x=>x.r=='t'&&!x.off):[l,...tcL.filter(x=>x.r=='t'&&!x.off&&x.id!=l.id&&sel.includes(x.id))];
 try{toast('جارٍ الإرسال…');for(const x of tg){const im=[];for(const u of tcPend)im.push(await tcUp(x.id,u,'t'));const as=[...(x.as||[]),{id:Date.now().toString(36)+Math.random().toString(36).slice(2,4),t:(t||'واجب بصورة').slice(0,200),d,c:Date.now(),im}];await fs.collection('links').doc(x.id).update({as,tn:tcMe()});x.as=as}
  tcPend=[];tcDraft={t:'',d:'',all:false,sel:[]};toast('أُضيف الواجب ✅'+(tg.length>1?' لـ '+tg.length+' طلاب':''));draw()}catch(e){tcErr(e)}}
async function tcAsDel(i,a){const l=tcG(i);if(!l)return;const x=(l.as||[]).find(y=>y.id==a),ids=[...((x&&x.im)||[]),...(tcSt(l,a).im||[])],as=(l.as||[]).filter(y=>y.id!=a);try{await fs.collection('links').doc(i).update({as});l.as=as;tcFDel(i,ids);draw()}catch(e){tcErr(e)}}
const tcAsAsk=(i,a)=>ask('حذف هذا الواجب؟',()=>tcAsDel(i,a));
function tcUnAsk(i){const l=tcG(i);if(!l||l.r!='t')return;ask('فصل هذا الطالب؟ تبقى واجباته محفوظة وتظهر من جديد إذا أعاد ربطك بكود جديد.',async()=>{try{await fs.collection('links').doc(i).update({off:true});l.off=true;tcSel=null;draw()}catch(e){tcErr(e)}},'نعم، افصل')}
function tcUnAskS(i){tcUnId=i;const l=tcG(i);typedAsk('حذف المعلّم','سيُفصل '+esc((l&&l.tn)||'المعلّم')+' ولن يرى إنجازاتك. تبقى الواجبات السابقة محفوظة وتظهر من جديد إذا أعدتَ ربطه بكود جديد.','tcUnS')}
async function tcUnS(){const i=tcUnId,l=tcG(i);if(!l)return;try{await fs.collection('links').doc(i).update({off:true,sum:null});l.off=true;tcOp=null;toast('تم حذف المعلّم');draw()}catch(e){tcErr(e)}}
/* الطالب: صح / غلط + ملاحظة */
async function tcMark(i,a,v){const l=tcG(i);if(!l)return;const o=tcSt(l,a),e={v:o.v===v?null:v,t:Date.now(),n:o.n||'',im:o.im||[],...tcSK(o)};try{await fs.collection('links').doc(i).update({['dn.'+a]:e});(l.dn=l.dn||{})[a]=e;draw()}catch(er){tcErr(er);draw()}}
async function tcNote(i,a,txt){const l=tcG(i);if(!l)return;const o=tcSt(l,a),e={v:o.v==null?null:o.v,t:Date.now(),n:String(txt||'').trim().slice(0,300),im:o.im||[],...tcSK(o)};try{await fs.collection('links').doc(i).update({['dn.'+a]:e});(l.dn=l.dn||{})[a]=e;toast('حُفظت الملاحظة ✅');draw()}catch(er){tcErr(er);draw()}}
async function tcCleanup(){if(!fu)return;const c=tcCode();if(c)await fs.collection('invites').doc(c).delete().catch(dbg);await tcLoad();await Promise.all(tcL.map(async l=>{await tcFDel(l.id,tcFileIds(l));await tcChDel(l.id);await fs.collection('links').doc(l.id).delete().catch(dbg)}))}

/* ---- واجهة الطالب ---- */


/* ---- واجهة المعلّم ---- */



function tcJzT(s){const J=s.jz||[];if(J.length<30)return '<div class="c m">لا توجد بيانات أجزاء بعد (تظهر عند فتح الطالب للتطبيق).</div>';
 const P=J.map(x=>x.split(',')),cnt=ks=>P.filter(p=>ks.includes(p[0])).length;
 const tile=(p,i)=>{const k0=p[0],k=(k0&&'yr'.includes(k0))?'g':k0,c=(JMC[k]||JMC['0'])[0],a=p[1]===''?null:+p[1],sm=k=='0'||k=='1'?JMC[k][1]:a===null?'لم تُراجع':a==0?'اليوم':'قبل '+a+' ي';return `<div class="exj" style="border-color:${c};background:color-mix(in srgb,${c} 18%,transparent);cursor:default;min-height:62px;padding:8px 0"><b style="font-size:18px">${i+1}</b><small style="font-size:10px;opacity:.85">${sm}</small></div>`};
 return `<div class="c"><div class="tcK"><div><b>${cnt('gyr')}</b><span>محفوظ من 30</span></div><div><b>${cnt('1')}</b><span>قيد الحفظ</span></div><div><b>${cnt('0')}</b><span>لم يُحفظ</span></div></div></div><div class="c"><div class="exg">${P.map(tile).join('')}</div><div style="margin-top:10px">${['0','1','g'].map(k=>`<div class="m" style="padding:2px 0"><span style="display:inline-block;width:12px;height:12px;border-radius:4px;background:${JMC[k][0]};vertical-align:middle;margin-inline-end:6px"></span>${JMC[k][1]}</div>`).join('')}</div></div>`}




(function(){const s=document.createElement('style');s.textContent=`
:root{--ok:#1e8e5a;--no:#d33f49;--wa:#e0a100}
.tqHd{display:flex;align-items:center;gap:12px;padding:14px 16px 6px}.tqHd b{font-size:21px;flex:1}
.tqSeg{display:flex;gap:4px;margin:8px 14px;padding:4px;border-radius:16px;background:color-mix(in srgb,var(--pri) 11%,var(--card))}
.tqSeg>div{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;padding:12px 6px;border-radius:12px;font-weight:600;color:var(--mut);cursor:pointer}
.tqSeg>div.on{background:var(--pri);color:var(--on);box-shadow:0 4px 14px color-mix(in srgb,var(--pri) 38%,transparent)}
.tqCard{background:var(--card);border-radius:20px;margin:12px 14px;padding:16px;box-shadow:0 2px 14px color-mix(in srgb,var(--pri) 12%,transparent)}
.tqCard>b{font-size:16px}
.tqKp{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 14px}.tqKp.tq3{grid-template-columns:repeat(3,1fr)}
.tqKp>div{background:var(--card);border-radius:18px;padding:14px 8px;text-align:center;box-shadow:0 2px 14px color-mix(in srgb,var(--pri) 10%,transparent)}
.tqKp b{display:block;font-size:28px;line-height:1.25;font-weight:800}.tqKp span{font-size:12.5px;color:var(--mut)}
.tqSec{display:flex;align-items:center;gap:8px;margin:18px 18px 4px;font-weight:700;font-size:16px}
.tqSec em,.tqTabs em{font-style:normal;min-width:22px;height:22px;padding:0 7px;border-radius:11px;background:var(--gold);color:#fff;font-size:12px;display:inline-flex;align-items:center;justify-content:center}
.tqPf{display:flex;align-items:center;gap:14px;margin:8px 14px;padding:16px;border-radius:22px;color:#fff;background:linear-gradient(135deg,var(--h1),var(--h2));box-shadow:0 8px 22px color-mix(in srgb,var(--h1) 30%,transparent)}
.tqPf b{font-size:19px}.tqPf button{background:#ffffff22;color:#fff;border:1px solid #ffffff55;padding:8px 14px}
.tqSub{display:flex;align-items:center;gap:6px;font-size:13px;opacity:.92}
.tqAv{width:52px;height:52px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:22px;background:color-mix(in srgb,var(--pri) 14%,var(--card));color:var(--pri);border:3px solid color-mix(in srgb,var(--pri) 30%,transparent)}
.tqPf .tqAv{background:#ffffff26;color:#fff;border-color:var(--gold)}
.tqAv.ok{border-color:var(--ok)}.tqAv.wa{border-color:var(--wa)}.tqAv.no{border-color:var(--no)}.tqAv.sm{width:38px;height:38px;font-size:16px;border-width:2px}
.tqDot{width:10px;height:10px;border-radius:50%;flex:none;display:inline-block;background:var(--bd)}.tqDot.ok{background:var(--ok)}.tqDot.wa{background:var(--wa)}.tqDot.no{background:var(--no)}
.tqPf .tqDot{box-shadow:0 0 0 2px #fff6}
.tqTabs{display:flex;gap:8px;overflow-x:auto;padding:8px 14px;position:sticky;top:0;z-index:4;background:var(--bg);scrollbar-width:none}.tqTabs::-webkit-scrollbar{display:none}
.tqTabs button{display:flex;align-items:center;gap:6px;white-space:nowrap;background:var(--card);color:var(--mut);border:1px solid var(--bd);border-radius:20px;padding:9px 14px;font-weight:600}.tqTabs button.on{background:var(--pri);color:var(--on);border-color:var(--pri)}
.tqSt{display:flex;align-items:center;gap:12px;background:var(--card);border-radius:20px;margin:10px 14px;padding:14px;cursor:pointer;box-shadow:0 2px 14px color-mix(in srgb,var(--pri) 12%,transparent)}
.tqSt b{font-size:16.5px}.tqTg2{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
.tqSp{display:flex;align-items:flex-end;gap:3px;height:24px}.tqSp i{width:6px;border-radius:3px;background:var(--pri);opacity:.75}
.tqPl{display:inline-block;padding:3px 11px;border-radius:14px;font-size:12px;font-weight:700;--c:var(--mut);background:color-mix(in srgb,var(--c) 15%,transparent);color:var(--c)}
.tqPl.ok{--c:var(--ok)}.tqPl.wa{--c:var(--wa)}.tqPl.no{--c:var(--no)}
.tqCh{display:flex;flex-direction:column;height:calc(100dvh - 330px);min-height:440px;margin:10px 14px;background:var(--card);border-radius:24px;overflow:hidden;box-shadow:0 2px 14px color-mix(in srgb,var(--pri) 14%,transparent)}
.tqChH{display:flex;align-items:center;gap:10px;padding:12px 16px;border-bottom:1px solid var(--bd);font-size:16px}
.tqMs{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:8px;background:color-mix(in srgb,var(--pri) 4%,var(--bg))}
.tqMg{max-width:82%;padding:10px 14px;border-radius:20px;font-size:16px;line-height:1.65;white-space:pre-wrap;word-break:break-word}
.tqMg small{display:block;font-size:11px;opacity:.7;margin-top:3px}
.tqMg.me{align-self:flex-start;background:linear-gradient(135deg,var(--h1),var(--h2));color:#fff;border-end-start-radius:6px}
.tqMg.ot{align-self:flex-end;background:var(--card);border:1px solid var(--bd);border-end-end-radius:6px}
.tqDs{align-self:center;font-size:12px;color:var(--mut);background:color-mix(in srgb,var(--pri) 9%,transparent);padding:3px 12px;border-radius:12px;margin:6px 0}
.tqCp{display:flex;gap:8px;align-items:flex-end;padding:10px;border-top:1px solid var(--bd);background:var(--card)}
.tqCp textarea{flex:1;min-height:48px;max-height:120px;border-radius:24px;padding:12px 18px;margin:0;resize:none;font-size:16px}
.tqSnd{width:48px;height:48px;border-radius:50%;padding:0;display:flex;align-items:center;justify-content:center;flex:none}.tqSnd .ic{width:22px;height:22px;transform:scaleX(-1)}
.tqHw{background:var(--card);border-radius:20px;margin:10px 14px;padding:16px;border-inline-start:5px solid var(--bd);box-shadow:0 2px 14px color-mix(in srgb,var(--pri) 12%,transparent)}
.tqHw.ok{border-inline-start-color:var(--ok)}.tqHw.no{border-inline-start-color:var(--no)}
.tqHwT{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.tqHwT b{font-size:17px;line-height:1.5}
.tqDue{display:inline-flex;align-items:center;gap:5px;white-space:nowrap;font-size:12.5px;padding:4px 10px;border-radius:14px;background:color-mix(in srgb,var(--pri) 10%,transparent);color:var(--mut)}.tqDue.late{background:color-mix(in srgb,var(--no) 14%,transparent);color:var(--no);font-weight:700}
.tqLb{font-size:13px;color:var(--mut);margin-top:10px}
.tqYN{display:flex;gap:10px;margin:6px 0}.tqYN button{flex:1;padding:14px;font-size:17px;font-weight:700;background:var(--card);color:var(--tx);border:2px solid var(--bd);border-radius:14px}
.tqYN button.y.on{background:var(--ok);border-color:var(--ok);color:#fff}.tqYN button.n.on{background:var(--no);border-color:var(--no);color:#fff}
.tqAt{display:flex;gap:8px;margin:8px 0}.tqAt button{flex:1;display:flex;gap:6px;align-items:center;justify-content:center;padding:11px 6px}
.tqGo{width:100%;margin-top:10px;padding:14px;font-weight:700;font-size:16px;border-radius:14px}
.tqTg{display:flex;gap:10px;align-items:center;margin:8px 0}.tqTg input{width:22px;height:22px;margin:0}
.tqCode{display:flex;gap:8px;margin-top:8px}.tqCode input{margin:0;text-align:center;letter-spacing:5px;font-weight:700;font-size:18px}.tqCode button{padding:0 24px}
.tqEmp{display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center;color:var(--mut);padding:36px 20px}.tqEmp .ic{width:40px;height:40px;opacity:.5}.tqEmp b{color:var(--tx)}
.tqWk{display:flex;align-items:flex-end;justify-content:space-between;gap:6px;height:130px;margin-top:12px}.tqWk>div{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:4px;height:100%}
.tqWk i{width:70%;max-width:30px;border-radius:8px 8px 3px 3px;background:linear-gradient(var(--pri),color-mix(in srgb,var(--pri) 55%,var(--gold)))}.tqWk i.z{background:var(--bd)}.tqWk span{font-size:12px;font-weight:700}.tqWk small{font-size:11px;color:var(--mut)}
.tqAl,.tqLr{display:flex;gap:10px;align-items:center;padding:11px 0;border-top:1px solid var(--bd)}.tqCard>b+.tqAl{border:0}
.tqDt{width:22px;height:22px;border-radius:50%;display:inline-block;background:var(--bd)}.tqDt.m{background:var(--ok)}.tqDt.h{background:var(--wa)}.tqDt.x{background:var(--no)}
.tcCd{background:linear-gradient(135deg,color-mix(in srgb,var(--pri) 8%,var(--card)),var(--card));margin:14px 0 10px}
.tcNote{border-radius:12px;font-size:14px;padding:10px 12px}.tcTh{width:84px;height:84px;border-radius:14px}
`;document.head.appendChild(s)})();
Object.assign(IC,{send:'<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4z"/>',chat:'<path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-5.4A8 8 0 1 1 21 12z"/>'});
let tqSTb='hw';
const tqTd=()=>ymd(new Date());
const tqDiff=s=>s?Math.round((new Date(tqTd()+'T12:00:00')-new Date(s+'T12:00:00'))/864e5):99;
const tqAgo=s=>{const d=tqDiff(s);return d>=99?'لم يبدأ':d<=0?'اليوم':d==1?'أمس':'قبل '+d+' أيام'};
const tqSt=l=>{const d=tqDiff(l.sum&&l.sum.last);return d<=1?'ok':d<=4?'wa':'no'};
const tqOpen=l=>(l.as||[]).filter(a=>!tcSent(l,a.id));
const tqLate=l=>tqOpen(l).filter(a=>a.d&&a.d<tqTd()&&tcSt(l,a.id).v==null).length;
const tqRev=l=>(l.as||[]).filter(a=>tcSent(l,a.id)&&!(a.fb&&(a.fb.v||a.fb.n))).length;
const tqHd=(t,back)=>`<div class="tqHd"><button type="button" class="pbtn bk" aria-label="رجوع" onclick="${back}">${svg('chev')}</button><b>${t}</b></div>`;
const tqSeg=(it,cur,fn)=>`<div class="tqSeg">${it.map(([k,t,ic,b])=>`<div class="${cur==k?'on':''}" role="button" onclick="${fn}('${k}')">${svg(ic)}${t}${b||''}</div>`).join('')}</div>`;
const tqSetM=k=>{tcM=k;tcSel=null;tcOp=null;draw()},tqSetTb=k=>{tcTb=k;draw()},tqSetSt=k=>{tqSTb=k;draw()};
const tqEmp=(ic,t,s)=>`<div class="tqEmp">${svg(ic)}<b>${t}</b>${s?'<span>'+s+'</span>':''}</div>`;
Object.assign(EN,{"المعلّم والطلاب":"Teacher & students","أنا طالب":"I'm a student","أنا معلّم":"I'm a teacher","نظرة عامة":"Overview","المحادثة":"Chat","يحتاج انتباهك":"Needs attention","نسخ الكود":"Copy code","بانتظار الإجابة":"Awaiting answer","جاهزة للإرسال":"Ready to send","ابدأ المحادثة":"Start the chat"});
function tqPr(s){const pr=s.pr||{},td=tqTd(),ps=s.ps||'';let m=0,h=0,x=0,ot=0,ft=0,tr=0;for(let i=0;i<30;i++){const k=ymd(new Date(Date.now()-i*864e5)),r=pr[k];if(ps&&k>=ps&&k<=td)tr++;if(!r)continue;for(let j=0;j<5;j++){const c=r[j];if(c=='m')m++;else if(c=='h')h++;else if(c=='x')x++;if(c=='m'||c=='h'){if(r[5+j]=='1')ot++;if(r[5+j]=='2')ft++}}}return{m,h,x,ot,ft,tr}}
function tcPrT(s){const pr=s.pr||{},P=tqPr(s),days=[...Array(7)].map((_,i)=>ymd(new Date(Date.now()-i*864e5)));
 const rows=days.map(k=>{const r=pr[k],wd=D[new Date(k+'T12:00:00').getDay()];return `<tr><td>${esc(wd)}<small>${esc(k.slice(5))}</small></td>${PK.map((p,j)=>{const c=r?r[j]:'-',t=r?r[5+j]:'0',cl='mhx'.includes(c)?c:'';return `<td><span class="tqDt ${cl}"></span>${(c=='m'||c=='h')&&t=='1'?'<small>✓</small>':(c=='m'||c=='h')&&t=='2'?'<small>✗</small>':'<small>&nbsp;</small>'}</td>`}).join('')}</tr>`}).join('');
 return `<div class="tqKp tq3"><div><b style="color:var(--ok)">${P.m}</b><span>في الجامع</span></div><div><b style="color:var(--wa)">${P.h}</b><span>في البيت</span></div><div><b style="color:var(--no)">${P.x}</b><span>لم تُصلَّ</span></div></div><div class="tqKp tq3" style="margin-top:0"><div><b>${P.ot}</b><span>بوقتها</span></div><div><b>${P.ft}</b><span>خارج الوقت</span></div><div><b>${P.tr?Math.max(0,P.tr*5-P.m-P.h-P.x):'—'}</b><span>غير مسجّل</span></div></div><div class="tqCard"><b>آخر 7 أيام</b><table class="tcP" style="margin-top:8px"><tr><th></th>${PN.map(n=>`<th>${n}</th>`).join('')}</tr>${rows}</table><div class="m" style="margin-top:10px">🟢 في الجامع • 🟡 في البيت • 🔴 لم تُصلَّ • ⚪ غير مسجّل — ✓ بوقتها / ✗ خارج الوقت</div>${s.ps?`<div class="m">بدأ التتبّع في ${esc(s.ps)}</div>`:'<div class="m">لم يحدّد الطالب يوم بداية بعد.</div>'}</div>`}
function tcLgT(s){const L=s.lg||[],RL={mastered:['ok','أتقن'],light:['wa','مراجعة خفيفة'],hard:['no','صعوبة']};if(!L.length)return tqEmp('book','لا توجد مراجعات مسجّلة بعد');
 const k={mastered:0,light:0,hard:0};L.forEach(l=>{if(k[l.r]!==undefined)k[l.r]++});
 return `<div class="tqKp tq3"><div><b style="color:var(--ok)">${k.mastered}</b><span>أتقن</span></div><div><b style="color:var(--wa)">${k.light}</b><span>مراجعة خفيفة</span></div><div><b style="color:var(--no)">${k.hard}</b><span>صعوبة</span></div></div><div class="tqCard" style="padding:6px 16px"><div class="m" style="padding:8px 0">آخر ${L.length} مراجعة</div>${L.map(l=>{const r=RL[l.r]||['',''];return `<div class="tqLr"><i class="tqDot ${r[0]}"></i><div style="flex:1;min-width:0"><b>${esc(l.s||'—')}</b><div class="m">${esc(l.d)} ${esc(l.tm)}${l.m?' • '+l.m+' د':''}</div></div><span class="tqPl ${r[0]}">${r[1]}</span></div>`}).join('')}</div>`}
function tqOv(l){const s=l.sum;if(!s)return tqEmp('hourglass','لم يبدأ التتبّع بعد','يظهر تقدّم الطالب بعد فتحه التطبيق');
 const mx=Math.max(1,...s.wk),P=tqPr(s),den=P.tr?P.tr*5:P.m+P.h+P.x,pc=den?Math.round((P.m+P.h)/den*100):0,mr=s.n?Math.round(s.m/s.n*100):0,d=tqDiff(s.last),late=tqLate(l),rev=tqRev(l),jl=(s.jz||[]).filter(x=>'yr'.includes(x[0]||'-')).length,al=[];
 if(d>=3&&d<99)al.push(['no','لم يسجّل نشاطاً منذ '+d+' أيام']);if(late)al.push(['no',late+' واجب متأخر عن موعده']);if(rev)al.push(['wa',rev+' واجب مُرسَل بانتظار ردّك']);if(jl)al.push(['wa',jl+' جزءاً متأخراً عن دورة المراجعة']);
 return `<div class="tqKp"><div><b>🔥 ${s.st}</b><span>أيام متتالية</span></div><div><b>${s.n}</b><span>مراجعة مسجّلة</span></div><div><b>${mr}%</b><span>نسبة الإتقان</span></div><div><b>${pc}%</b><span>الصلاة آخر 30 يوماً</span></div></div>
<div class="tqCard"><div class="row sp"><b>النشاط آخر 7 أيام</b><span class="m">المجموع ${s.wk.reduce((a,b)=>a+b,0)}</span></div><div class="tqWk">${s.wk.map((v,i)=>`<div><span>${v||''}</span><i class="${v?'':'z'}" style="height:${Math.max(4,v/mx*84)}px"></i><small>${esc(D[new Date(Date.now()-(6-i)*864e5).getDay()].replace('ال',''))}</small></div>`).join('')}</div></div>
<div class="tqCard"><b>يحتاج انتباهك</b>${al.length?al.map(a=>`<div class="tqAl"><i class="tqDot ${a[0]}"></i>${a[1]}</div>`).join(''):'<div class="tqAl"><i class="tqDot ok"></i>لا ملاحظات، التقدّم منتظم</div>'}</div>`}
function tcMine(l){const A=tqOpen(l).slice().reverse();if(!A.length)return tqEmp('clipcheck','لا توجد واجبات حالياً','الواجبات المُرسَلة تجدها في الأرشيف ← الواجبات');
 const P=A.filter(a=>tcSt(l,a.id).v==null),D2=A.filter(a=>tcSt(l,a.id).v!=null);
 const card=a=>{const s=tcSt(l,a.id),ov=a.d&&s.v==null&&a.d<ymd(new Date()),d=`data-i="${esc(l.id)}" data-a="${esc(a.id)}"`;
  return `<div class="tqHw ${s.v===1?'ok':s.v===0?'no':''}"><div class="tqHwT"><b>${esc(a.t)}</b>${a.d?`<span class="tqDue ${ov?'late':''}">${svg('calendar')}${esc(a.d)}${ov?' • متأخر':''}</span>`:''}</div>${tcThs(l.id,a.im)}${tcFbH(a)}<div class="tqLb">نتيجتك</div><div class="tqYN"><button type="button" class="y ${s.v===1?'on':''}" ${d} onclick="tcMark(this.dataset.i,this.dataset.a,1)">✓ صح</button><button type="button" class="n ${s.v===0?'on':''}" ${d} onclick="tcMark(this.dataset.i,this.dataset.a,0)">✗ غلط</button></div>${tcThs(l.id,s.im,a.id)}<div class="tqAt"><button type="button" class="g" ${d} onclick="tcSend(this.dataset.i,this.dataset.a)">${svg('camera')} إرسال صورة</button><button type="button" class="g" ${d} onclick="tcSendA(this.dataset.i,this.dataset.a)">${svg('mic')} تسجيل صوتي</button></div><input placeholder="ملاحظة لمعلّمك (اختياري)" maxlength="300" value="${esc(s.n||'')}" ${d} onchange="tcNote(this.dataset.i,this.dataset.a,this.value)" style="margin:0"><button type="button" class="tqGo ${s.v==null?'g':''}" ${d} onclick="tcSendHw(this.dataset.i,this.dataset.a)">إرسال الواجب ونقله للأرشيف</button></div>`};
 return (P.length?`<div class="tqSec">بانتظار الإجابة <em>${P.length}</em></div>`+P.map(card).join(''):'')+(D2.length?`<div class="tqSec">جاهزة للإرسال <em>${D2.length}</em></div>`+D2.map(card).join(''):'')}
function tqStDet(l){const pend=tqOpen(l).length,nm=l.tn||'معلّم',n=(l.as||[]).length;
 return `<div class="tqPf"><div class="tqAv">${esc(tcIn(nm))}</div><div style="flex:1;min-width:0"><b>${esc(nm)}</b><div class="tqSub">${n?n+' واجب • '+(pend?pend+' بانتظار إجابتك':'تمت الإجابة على الكل'):'لا توجد واجبات'}</div></div></div>${tqSeg([['hw','الواجبات','clipcheck',pend?`<em class="tqEm" style="background:var(--gold)">${pend}</em>`:''],['ch','المحادثة','chat',tqSTb!='ch'&&tqUn(l)?`<em class="tqEm">${tqUn(l)}</em>`:'']],tqSTb,'tqSetSt')}${tqSTb=='ch'?tcChatH(l):tcMine(l)}<div style="padding:8px 14px"><button type="button" class="g" style="width:100%;color:var(--bad);border-color:var(--bad)" data-i="${esc(l.id)}" onclick="tcUnAskS(this.dataset.i)">حذف المعلّم</button></div>`}
function tcStuPage(){const M=tcL.filter(x=>x.r=='s'&&!x.off),cd=tcCode();
 const code=`<div class="tqCard"><b>كود الربط الخاص بك</b><div class="m">أعطه لمعلّمك ليضيفك ويرسل لك الواجبات. يتغيّر تلقائياً بعد أن يضيفك.</div>${cd?`<div class="tcCd" role="button" onclick="cp('${cd}')">${cd}</div><div class="row" style="flex-wrap:nowrap"><button type="button" class="g" style="flex:1" onclick="cp('${cd}')">${svg('copy')} نسخ الكود</button><button type="button" class="g" style="flex:1" onclick="tcRegen()">${svg('refresh')} كود جديد</button></div>`:'<div class="m" style="text-align:center;padding:18px 0">جارٍ إنشاء كودك…</div>'}</div>`;
 const ms=M.map(l=>{const pend=tqOpen(l).length,nw=tcNew(l);return `<div class="tqSt" role="button" data-i="${esc(l.id)}" onclick="tcOpen(this.dataset.i)"><div class="tqAv">${esc(tcIn(l.tn))}</div><div style="flex:1;min-width:0"><b>${esc(l.tn||'معلّم')}</b><div class="m">${(l.as||[]).length?pend?pend+' واجب بانتظار إجابتك':'تمت الإجابة على الكل':'لا توجد واجبات بعد'}</div></div>${nw?'<span class="tcBadge">جديد</span>':''}${tqCnt(l)}${pend?`<span class="tcBadge">${pend}</span>`:''}<span class="m">‹</span></div>`}).join('');
 return code+`<div class="tqSec">معلّموني <em>${M.length}</em></div>`+(ms||tqEmp('users','لا يوجد معلّم مرتبط بعد','أعطِ كودك لمعلّمك ليضيفك'))}
const tcOpen=i=>{tqSTb='hw';if(tcOp==i)tcSnS(i);tcOp=tcOp==i?null:i;if(tcOp)tcSnS(i);draw()};
function tcAsT(l){const A=tqOpen(l).slice().reverse(),NS=(l.as||[]).length-A.length,rv=tqRev(l),bn=NS?`<button type="button" class="g" style="width:calc(100% - 28px);margin:8px 14px" onclick="arSec='w';go('ar')">الواجبات المُرسَلة في الأرشيف (${NS})${rv?' • '+rv+' بانتظار ردّك':''}</button>`:'';
 if(!A.length)return bn+tqEmp('clipcheck','لا توجد واجبات مفتوحة');
 return bn+A.map(a=>{const ov=a.d&&a.d<ymd(new Date());return `<div class="tqHw"><div class="tqHwT"><b>${esc(a.t)}</b><button type="button" class="g" style="padding:2px 10px" aria-label="حذف الواجب" data-i="${esc(l.id)}" data-a="${esc(a.id)}" onclick="tcAsAsk(this.dataset.i,this.dataset.a)">✕</button></div><div class="row" style="margin-top:6px"><span class="tqPl">⏳ بانتظار الطالب</span>${a.d?`<span class="tqDue ${ov?'late':''}">${svg('calendar')}${esc(a.d)}${ov?' • متأخر':''}</span>`:''}</div>${tcThs(l.id,a.im)}${tcFbT(l,a)}</div>`}).join('')}
function tcAsPanel(l){return `<div class="tqCard"><b>واجب جديد</b><input id="tct" placeholder="مثال: حفظ صفحة 50" maxlength="200" value="${esc(tcDraft.t)}"><div class="tqLb">موعد التسليم</div><input id="tcd" type="date" value="${esc(tcDraft.d)}"><div class="tqAt"><button type="button" class="g" onclick="tcPick(tcAddPend)">${svg('camera')} إرفاق صورة${tcPend.length?' ('+tcPend.length+')':''}</button><button type="button" class="g" onclick="tcRecord(u=>tcAddPend([u]))">${svg('mic')} تسجيل</button></div><label class="tqTg"><input type="checkbox" id="tcall" ${tcDraft.all?'checked':''}><span>إرسال لجميع طلابي</span></label>${(()=>{const o=tcL.filter(x=>x.r=='t'&&!x.off&&x.id!=l.id),sl=tcDraft.sel||[];return o.length?`<div class="tqLb">أو أرسله أيضاً لطلاب محددين</div><div class="tqPk">${o.map(x=>`<button type="button" class="tqPkB ${sl.includes(x.id)?'on':''}" data-i="${esc(x.id)}" onclick="tcSelTg(this.dataset.i)">${esc(x.sn||'طالب')}</button>`).join('')}</div>`:''})()}${tcPend.length?`<div class="tcIm">${tcPend.map((u,k)=>`<div class="tcTh"><span class="tcC">${u.startsWith('data:image')?`<img alt="" src="${u}">`:'🎙️'}</span><span class="tcX" onclick="tcPendRm(${k})">✕</span></div>`).join('')}</div>`:''}<button type="button" class="tqGo" data-i="${esc(l.id)}" onclick="tcAs(this.dataset.i)">إضافة واجب</button></div><div class="tqSec">الواجبات <em>${(l.as||[]).length}</em></div>${tcAsT(l)}`}

function tqTList(){const T=tcL.filter(x=>x.r=='t'&&!x.off),rk={no:0,wa:1,ok:2};T.sort((a,b)=>rk[tqSt(a)]-rk[tqSt(b)]);
 const act=T.filter(l=>tqSt(l)=='ok').length,need=T.reduce((a,l)=>a+tqRev(l)+tqLate(l),0);
 const kp=`<div class="tqKp tq3"><div><b>${T.length}</b><span>طلابي</span></div><div><b style="color:var(--ok)">${act}</b><span>نشطون</span></div><div><b style="color:var(--${need?'wa':'ok'})">${need}</b><span>تحتاج متابعتك</span></div></div>`;
 const add=`<div class="tqCard"><b>إضافة طالب</b><div class="m">اطلب من الطالب كود الربط من صفحته (أنا طالب).</div><div class="tqCode"><input id="tcc" placeholder="كود الطالب" maxlength="6" dir="ltr" autocapitalize="characters"><button type="button" onclick="tcJoin()">ربط</button></div></div>`;
 const rows=T.map(l=>{const nm=l.sn||'طالب',s=l.sum,st=tqSt(l),mx=s?Math.max(1,...s.wk):1,lt=tqLate(l),rv=tqRev(l),op=tqOpen(l).length;
  return `<div class="tqSt" role="button" data-i="${esc(l.id)}" onclick="tcSnS(this.dataset.i);tcSel=this.dataset.i;tcTb='pr';draw()"><div class="tqAv ${st}">${esc(tcIn(nm))}</div><div style="flex:1;min-width:0"><b>${esc(nm)}</b><div class="m">${s?'🔥 '+s.st+' • '+tqAgo(s.last):'لم يبدأ بعد'}</div><div class="tqTg2">${lt?`<span class="tqPl no">${lt} متأخر</span>`:''}${rv?`<span class="tqPl wa">${rv} بانتظار ردّك</span>`:''}${op&&!lt?`<span class="tqPl">${op} مفتوح</span>`:''}</div></div>${s?`<div class="tqSp">${s.wk.map(v=>`<i style="height:${Math.max(4,v/mx*24)}px"></i>`).join('')}</div>`:''}${tcNew(l)?'<span class="tcBadge">جديد</span>':''}${tqCnt(l)}<span class="m">‹</span></div>`}).join('');
 return kp+add+`<div class="tqSec">طلابي <em>${T.length}</em></div>`+(rows||tqEmp('users','لا يوجد طلاب بعد','أضف أول طالب بكوده'))}
function tcPage(){tcChWant=null;setTimeout(tcHyd,80);setTimeout(tcChSync,90);
 if(!fbOK||!fu)return tqHd('المعلّم والطلاب',"go('home')")+tqEmp('lock','سجّل الدخول أولاً','لاستخدام ميزة المعلّم والطلاب');
 if(Date.now()-tcAt>3e4){tcAt=Date.now();const sg=JSON.stringify(tcL);tcLoad().then(()=>{const ch=sg!==JSON.stringify(tcL);if(tcCode()&&tcL.some(l=>l.r=='s'&&l.code==tcCode()))tcEns=0;tcPub(tcPd?0:(tcPd=1));if((ch||!tcEns)&&tab=='tc'){const a=document.activeElement;if(!(a&&/INPUT|TEXTAREA/.test(a.tagName))&&![...document.querySelectorAll('audio')].some(x=>!x.paused))draw()}})}
 const seg=tqSeg([['s','أنا طالب','user'],['t','أنا معلّم','users']],tcM,'tqSetM');
 if(tcM=='t'){const sel=tcG(tcSel);if(sel&&sel.r=='t'&&!sel.off)return tqHd('ملف الطالب',"tqBack()")+tcStu(sel);return tqHd('المعلّم والطلاب',"go('home')")+seg+tqTList()}
 if(!tcEns&&tcM=='s'){tcEns=1;tcEnsure().then(()=>{if(tab=='tc')draw()})}
 const op=tcG(tcOp);if(op&&op.r=='s'&&!op.off)return tqHd('معلّمي',"tqBack()")+tqStDet(op);
 return tqHd('المعلّم والطلاب',"go('home')")+seg+tcStuPage()}




(function(){const s=document.createElement('style');s.textContent=`
nav button.hasdot{position:relative}nav button.hasdot::before{content:"";position:absolute;top:5px;left:calc(50% + 5px);width:12px;height:12px;border-radius:50%;background:#e53935;border:2px solid var(--card);z-index:1}
.tqEm{font-style:normal;min-width:22px;height:22px;padding:0 7px;border-radius:11px;background:var(--no);color:#fff;font-size:12px;font-weight:700;display:inline-flex;align-items:center;justify-content:center}
.tqTabs em.r{background:var(--no)}
.tqBd{display:inline-flex;align-items:center;gap:4px;background:var(--no);color:#fff;border-radius:14px;padding:3px 9px;font-size:12.5px;font-weight:700}.tqBd .ic{width:14px;height:14px}
.tqIb{width:44px;height:44px;border-radius:50%;padding:0;flex:none;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--pri) 12%,transparent);color:var(--pri)}.tqIb .ic{width:22px;height:22px}
.tqMg .tcIm{margin:2px 0 4px}.tqMg .tcTh{width:180px;height:180px;border-radius:14px}.tqMg .tcTh.tcAu{width:230px;max-width:100%;height:auto;background:none}.tqMg audio{width:100%}
`;document.head.appendChild(s)})();
const tqMW={};let tqLW=null,tqLs=[],tqLt=[],tqU='';
const tqCSG=()=>{try{return JSON.parse(localStorage.getItem('tcChSeen')||'{}')}catch(e){return{}}};
const tqCSS=(i,t)=>{try{const o=tqCSG();o[i]=Math.max(o[i]||0,t||0);localStorage.setItem('tcChSeen',JSON.stringify(o))}catch(e){}};
const tqUn=l=>{if(!fu||l.off)return 0;const sn=tqCSG()[l.id]||0;return(tcMsgs[l.id]||[]).filter(m=>m.u!=fu.uid&&(m.c||0)>sn).length};
const tqSeen=id=>{tqCSS(id,(tcMsgs[id]||[]).filter(m=>m.u!=fu.uid).reduce((a,m)=>Math.max(a,m.c||0),0));tqNavDots()};
const tqCnt=l=>{const n=tqUn(l);return n?`<span class="tqBd" aria-label="رسائل جديدة">${svg('chat')}${n}</span>`:''};
const tqBusy=()=>{const a=document.activeElement;return !!(a&&/INPUT|TEXTAREA/.test(a.tagName))||[...document.querySelectorAll('audio')].some(x=>!x.paused)};
function tqNote(){try{if(!fbOK||!fu)return 0;let n=0;tcL.forEach(l=>{if(l.off)return;n+=tqUn(l);if(!(tab=='tc'&&(tcOp==l.id||tcSel==l.id)))n+=tcNew(l)});return n}catch(e){return 0}}
function tqNavDots(){try{const b=[...document.querySelectorAll('#nav button')].find(x=>(x.getAttribute('onclick')||'').includes("'tc'"));if(b)b.classList.toggle('hasdot',tqNote()>0)}catch(e){}}
{const _d=draw;draw=function(){const r=_d.apply(this,arguments);tqNavDots();return r}}
const tqBack=()=>{const i=tcM=='t'?tcSel:tcOp;if(i)tcSnS(i);if(tcM=='t')tcSel=null;else tcOp=null;draw()};
function tqMsgUpd(id){tqNavDots();const b=document.getElementById('tcMsgs');if(tab=='tc'&&tcChId===id&&b){b.innerHTML=tcMsgsH(id);b.scrollTop=b.scrollHeight;tcHyd();tqSeen(id)}else if(tab=='tc'&&!tqBusy())draw()}
function tqMWatch(){const ids=new Set(tcL.filter(l=>!l.off).map(l=>l.id));
 Object.keys(tqMW).forEach(id=>{if(!ids.has(id)){try{tqMW[id]()}catch(e){}delete tqMW[id];delete tcMsgs[id]}});
 ids.forEach(id=>{if(tqMW[id])return;try{tqMW[id]=fs.collection('links').doc(id).collection('files').where('k','==','m').onSnapshot(sn=>{tcMsgs[id]=sn.docs.map(d=>Object.assign({id:d.id},d.data())).sort((a,b)=>(a.c||0)-(b.c||0));tcChE=0;tqMsgUpd(id)},e=>{dbg(e);tcChE=1;const b=document.getElementById('tcMsgs');if(b&&tcChId===id)b.innerHTML=tcMsgsH(id)})}catch(e){dbg(e)}})}
function tqStop(){(tqLW||[]).forEach(f=>{try{f()}catch(e){}});tqLW=null;Object.keys(tqMW).forEach(k=>{try{tqMW[k]()}catch(e){}delete tqMW[k]});tcMsgs={};tqLs=[];tqLt=[];tcL=[];tqU='';tqNavDots()}
function tqLinks(){tcL=[...tqLs,...tqLt];tqMWatch();tqNavDots();if(tab=='tc'&&!tqBusy())draw()}
function tqBoot(){try{if(!fbOK)return;if(!fu){if(tqLW)tqStop();return}if(tqLW&&tqU==fu.uid)return;if(tqLW)tqStop();tqU=fu.uid;
 const mk=(f,r)=>fs.collection('links').where(f,'==',fu.uid).onSnapshot(sn=>{const a=sn.docs.map(d=>Object.assign({id:d.id,r},d.data()));if(r=='s')tqLs=a;else tqLt=a;tqLinks()},e=>dbg(e,'tqL'));
 tqLW=[mk('s','s'),mk('t','t')]}catch(e){dbg(e)}}
setInterval(tqBoot,4000);setTimeout(tqBoot,1500);
const tcChClose=()=>{tcChId=null};
function tcChSync(){tcChId=(tab=='tc'&&tcChWant)?tcChWant:null;const b=document.getElementById('tcMsgs');if(tcChId&&b){b.scrollTop=b.scrollHeight;tqSeen(tcChId)}}
async function tqChFile(i,us){const l=tcG(i);if(!l)return;try{toast('جارٍ الإرسال…');for(const u of us){const f=await tcUp(i,u,l.r);const id='m'+Date.now().toString(36)+Math.random().toString(36).slice(2,5);await fs.collection('links').doc(i).collection('files').doc(id).set({k:'m',d:'@'+f,u:fu.uid,o:l.r,x:'',c:Date.now()})}}catch(e){tcErr(e)}}
const tqChPhoto=i=>tcPick(us=>tqChFile(i,us)),tqChVoice=i=>tcRecord(u=>tqChFile(i,[u]));
async function tcChDel(i){try{const c=fs.collection('links').doc(i).collection('files'),q=await c.where('k','==','m').get();await Promise.all(q.docs.map(async d=>{const v=d.data().d;if(typeof v=='string'&&v[0]=='@')await c.doc(v.slice(1)).delete().catch(dbg);return d.ref.delete().catch(dbg)}))}catch(e){dbg(e)}}
function tcMsgsH(id){const M=tcMsgs[id];if(tcChE)return tqEmp('alert','تعذّر تحميل المحادثة','تأكد من الاتصال وصلاحيات Firestore');if(!M)return tqEmp('hourglass','جارٍ التحميل…');if(!M.length)return tqEmp('chat','ابدأ المحادثة','اكتب رسالة أو أرسل صورة أو تسجيلاً صوتياً');
 let last='';return M.map(m=>{const dd=new Date(m.c||0),k=ymd(dd),sep=k!=last?(last=k,`<div class="tqDs">${k==tqTd()?'اليوم':esc(dd.toLocaleDateString('ar',{day:'numeric',month:'long'}))}</div>`):'',at=typeof m.d=='string'&&m.d[0]=='@'?tcThs(id,[m.d.slice(1)]):'';return sep+`<div class="tqMg ${m.u==fu.uid?'me':'ot'}">${at}${m.x?`<div>${esc(m.x)}</div>`:''}<small>${esc(dd.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}))}${m.u==fu.uid?`<span class="tqMx" role="button" aria-label="حذف الرسالة" data-i="${esc(id)}" data-m="${esc(m.id)}" onclick="tcMsgDelAsk(this.dataset.i,this.dataset.m)">${svg('trash')}</span>`:''}</small></div>`}).join('')}
function tcChatH(l){tcChWant=l.id;const nm=(l.r=='t'?l.sn:l.tn)||'',d=`data-i="${esc(l.id)}"`;return `<div class="tqCh"><div class="tqChH"><div class="tqAv sm">${esc(tcIn(nm))}</div><b>${esc(nm)}</b></div><div id="tcMsgs" class="tqMs">${tcMsgsH(l.id)}</div><div class="tqCp"><button type="button" class="tqIb" aria-label="إرسال صورة" ${d} onclick="tqChPhoto(this.dataset.i)">${svg('camera')}</button><button type="button" class="tqIb" aria-label="تسجيل صوتي" ${d} onclick="tqChVoice(this.dataset.i)">${svg('mic')}</button><textarea id="tcmi" rows="1" placeholder="اكتب رسالة…" maxlength="1000" autocomplete="off" ${d} oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,120)+'px'" onkeydown="if(event.key=='Enter'&&!event.shiftKey){event.preventDefault();tcChSend(this.dataset.i)}"></textarea><button type="button" class="tqSnd" aria-label="إرسال" ${d} onclick="tcChSend(this.dataset.i)">${svg('send')}</button></div></div>`}
function tcStu(l){const s=l.sum,nm=l.sn||'طالب',st=tqSt(l),nop=tqOpen(l).length,un=tqUn(l);
 const top=`<div class="tqPf"><div class="tqAv">${esc(tcIn(nm))}</div><div style="flex:1;min-width:0"><b>${esc(nm)}</b><div class="tqSub"><i class="tqDot ${st}"></i>${s?'آخر نشاط: '+tqAgo(s.last):'لم يرسل تقدمه بعد'}</div></div><button type="button" data-i="${esc(l.id)}" onclick="tcUnAsk(this.dataset.i)">فصل</button></div>`;
 const T=[['pr','الصلاة','moon'],['as','الواجبات','clipcheck'],['ch','المحادثة','chat'],['lg','المراجعة','book'],['jz','الأجزاء','grid'],['ov','نظرة عامة','chart']];
 const tabs=`<div class="tqTabs">${T.map(([k,t,ic])=>`<button type="button" class="${tcTb==k?'on':''}" onclick="tqSetTb('${k}')">${svg(ic)}${t}${k=='as'&&nop?`<em>${nop}</em>`:''}${k=='ch'&&un&&tcTb!='ch'?`<em class="r">${un}</em>`:''}</button>`).join('')}</div>`;
 let body;if(tcTb=='ch')body=tcChatH(l);else if(tcTb=='as')body=tcAsPanel(l);else if(!s)body=tqEmp('hourglass','لم يبدأ التتبّع بعد','يظهر تقدّم الطالب بعد فتحه التطبيق');else body=tcTb=='ov'?tqOv(l):tcTb=='pr'?tcPrT(s):tcTb=='lg'?tcLgT(s):tcJzT(s);
 return top+tabs+body}

const tcMsgDelAsk=(i,m)=>ask('حذف هذه الرسالة؟',()=>tcMsgDel(i,m));
async function tcMsgDel(i,mid){const m=(tcMsgs[i]||[]).find(x=>x.id==mid);if(!m||m.u!=fu.uid)return;try{await fs.collection('links').doc(i).collection('files').doc(mid).delete();if(typeof m.d=='string'&&m.d[0]=='@')tcFDel(i,[m.d.slice(1)]);tcMsgs[i]=(tcMsgs[i]||[]).filter(x=>x.id!=mid);const b=document.getElementById('tcMsgs');if(b)b.innerHTML=tcMsgsH(i);toast('حُذفت الرسالة')}catch(e){tcErr(e)}}
async function tcChSend(i){const l=tcG(i),el=document.getElementById('tcmi');if(!l||!el)return;const x=el.value.trim().slice(0,1000);if(!x)return;el.value='';el.style.height='';const id='m'+Date.now().toString(36)+Math.random().toString(36).slice(2,5);try{await fs.collection('links').doc(i).collection('files').doc(id).set({k:'m',d:'',u:fu.uid,o:l.r,x,c:Date.now()})}catch(e){el.value=x;tcErr(e)}}

function acct(){
 if(!fbOK)return '<b>الحساب والمزامنة</b><p class="m">المزامنة السحابية غير مفعّلة في هذه النسخة. تعمل فقط على نسخة GitHub.</p>';
 return `<button type="button" class="g" onclick="aGoogle()" style="width:100%;margin:0 0 8px"><b>G</b> الدخول بحساب Google</button><div class="m" style="text-align:center">أو بالبريد / اسم المستخدم وكلمة المرور</div><input id="ae" type="text" placeholder="البريد الإلكتروني أو اسم المستخدم" dir="ltr" autocapitalize="off"><input id="au" type="text" placeholder="اسم المستخدم (عند إنشاء حساب جديد)" dir="ltr" autocapitalize="off"><input id="ap" type="password" placeholder="كلمة المرور (6 أحرف على الأقل)" dir="ltr"><div class="row"><button type="button" onclick="aIn()" style="flex:1">دخول</button><button type="button" class="g" onclick="aUp()" style="flex:1">إنشاء حساب</button></div><button type="button" class="g" onclick="aRs()" style="width:100%;margin-top:6px">نسيت كلمة المرور</button>`}
function danger(){return fu?`<p class="m">يحذف حسابك وبياناتك السحابية نهائياً.</p><button type="button" class="r" style="width:100%" onclick="ask('حذف حسابك وكل بياناتك نهائياً؟ لا يمكن التراجع.',delAcc,'نعم، احذف حسابي')">حذف الحساب</button>`:`<p class="m">يحذف كل بياناتك المحفوظة في هذا الجهاز.</p><button type="button" class="r" style="width:100%" onclick="ask('حذف كل بياناتك من هذا الجهاز؟',wipe,'نعم، احذف')">حذف بياناتي من الجهاز</button>`}
function wipe(){S=EMPTY();clearTimeout(idbT);idb.del('S').catch(()=>{});try{localStorage.removeItem('qmrm')}catch(e){dbg(e)}go('home')}
async function delAcc(){const uid0=fu.uid;accQuiet=1;
 try{await tcCleanup()}catch(x){dbg(x)}try{const un=prof().user;if(un){try{await fs.collection('usernames').doc(un).delete()}catch(x){dbg(x)}}await fs.collection('users').doc(fu.uid).delete();await fu.delete()}
 catch(e){accQuiet=0;tab='se';draw();sync(e.code=='auth/requires-recent-login'?'⚠️ لأمانك: سجّل الخروج ثم ادخل من جديد وأعد حذف الحساب':'⚠️ تعذّر الحذف ('+(e.code||e.message)+')');return}
 accRemove(uid0);const o=accNext();
 if(o){accQuiet=0;await accSwitch(o.uid,true);return}
 fa=firebase.auth();fs=firebase.firestore();fu=null;wipe();accQuiet=0;if(!awG()){awMode='in';awShow()}}
const TA={tcUnS:()=>tcUnS(),delAcc:()=>delAcc(),wipe:()=>wipe(),nbDelB:()=>nbDelB()};
function typedAsk(t,m,fn){$('#sh').innerHTML=shW(`<b>${t}</b><div class="m" style="margin:6px 0">${m}</div><div class="m">اكتب كلمة (تأكيد) للمتابعة:</div><input id="tac" placeholder="تأكيد" autocomplete="off"><div id="tam" class="m" style="color:var(--bad)"></div><button type="button" class="r" onclick="typedDo('${fn}')">${t}</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
function typedDo(fn){if(!isConf($('#tac').value)){$('#tam').textContent='اكتب كلمة: تأكيد';return}$('#sh').innerHTML='';TA[fn]()}
let awMode='in';const awV={e:'',u:''};
const awG=()=>{try{return localStorage.getItem('qmrm_guest')==='1'}catch(e){return false}};
const awGv=id=>{const e=document.getElementById(id);return e?String(e.value||''):''};
const AWI={mail:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#3b3b55" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3 7 9 6 9-6"/></svg>',
 user:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#3b3b55" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>',
 lock:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#3b3b55" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.5" r="1.4" fill="#3b3b55"/></svg>',
 eye:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#3b3b55" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
 g:'<svg viewBox="0 0 48 48" width="22" height="22"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 7l7.2 5.6c4.3-4 6.8-9.9 6.8-17.1z"/><path fill="#FBBC05" d="M10.5 28.7c-.5-1.4-.8-2.9-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.4 0 20.1 0 24s.9 7.6 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.2-5.6c-2 1.4-4.6 2.2-8.7 2.2-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>'};
const awLogo='<svg viewBox="0 0 64 64" width="58" height="58"><path d="M32 18c-5-4-13-5-22-4v32c9-1 17 0 22 4 5-4 13-5 22-4V14c-9-1-17 0-22 4Z" style="fill:var(--gold)"/><path d="M32 18v32" stroke="currentColor" stroke-width="2.2" opacity=".55"/><g stroke="currentColor" stroke-width="2.4" stroke-linecap="round" opacity=".55"><path d="M38 24h10M38 30h10M38 36h10"/></g></svg>';
function awSplash(){const a=document.getElementById('aw');if(!a)return;a.style.display='block';a.innerHTML=`<div class="awb" style="justify-content:center"><div class="awlogo">${awLogo}</div><h1>مُثبِّت القرآن</h1><div class="awspin"></div></div>`}
function awHide(){const a=document.getElementById('aw');if(a){a.style.display='none';a.innerHTML=''}}
function awKeep(){awV.e=awGv('awe');awV.u=awGv('awu')}
function awShow(){const a=document.getElementById('aw');if(!a)return;const up=awMode=='up',en=S.lang=='en';a.style.display='block';
 a.innerHTML=`<div class="awb"><div class="awlogo">${awLogo}</div><h1>مُثبِّت القرآن</h1><div class="awcard"><h2>${up?'إنشاء حساب':'تسجيل الدخول'}</h2>
 <div class="awf"><input id="awe" type="text" dir="ltr" autocapitalize="off" autocomplete="username" placeholder="${up?'البريد الإلكتروني':'البريد الإلكتروني أو اسم المستخدم'}" value="${esc(awV.e)}" oninput="awV.e=this.value"><span class="awi">${AWI.mail}</span></div>
 ${up?`<div class="awf"><input id="awu" type="text" dir="ltr" autocapitalize="off" placeholder="اسم المستخدم (إنجليزي)" value="${esc(awV.u)}" oninput="awV.u=this.value"><span class="awi">${AWI.user}</span></div>`:''}
 <div class="awf"><input id="awp" type="password" dir="ltr" autocomplete="${up?'new-password':'current-password'}" placeholder="كلمة المرور" onkeydown="if(event.key==='Enter')${up?'awUp()':'awIn()'}"><span class="awi">${AWI.lock}</span><span class="awey" onclick="awEye()">${AWI.eye}</span></div>
 ${up?`<div class="awf"><input id="awp2" type="password" dir="ltr" autocomplete="new-password" placeholder="تأكيد كلمة المرور"><span class="awi">${AWI.lock}</span></div>`:''}
 <div id="awm" class="awm">${esc(sm||'')}</div>
 <button type="button" class="awbtn" onclick="${up?'awUp()':'awIn()'}">${up?'إنشاء حساب':'تسجيل الدخول'}</button>
 <div class="awor"><span>أو</span></div>
 <button type="button" class="awg" onclick="awGoogle()">${AWI.g}<span>الدخول بحساب Google</span></button>
 <div class="awl">${up?'<span></span>':'<a onclick="awRs()">نسيت كلمة المرور</a>'}<a onclick="awSet('${up?'in':'up'}')">${up?'لدي حساب':'إنشاء حساب'}</a></div></div>
 <div class="awfoot">${awAdd?'<a onclick="accCancelAdd()">إلغاء</a>':'<a onclick="awGuest()">المتابعة بدون حساب</a>'}<a onclick="setLang('${en?'ar':'en'}')">🌐 ${en?'العربية':'English'}</a></div></div>`}
function awSet(m){awKeep();awMode=m;sync('');awShow()}
function awEye(){const i=document.getElementById('awp');if(i)i.type=i.type==='password'?'text':'password'}
async function awIn(){await doIn(awGv('awe').trim(),awGv('awp'))}
async function awUp(){if(awGv('awp')!==awGv('awp2')){sync('⚠️ كلمتا المرور غير متطابقتين');return}await doUp(awGv('awe').trim(),awGv('awu').trim().toLowerCase(),awGv('awp'))}
async function awRs(){await doRs(awGv('awe').trim())}
async function awGoogle(){await aGoogle()}
function awGuest(){try{localStorage.setItem('qmrm_guest','1')}catch(e){dbg(e)}awHide();if(tab=='se')go('home')}
/* الصق هنا Web client ID من: Firebase > Authentication > Sign-in method > Google > Web SDK configuration */
const GCID='353485701859-rk57jeo543fsn0rs5sk9vjpildm1mta3.apps.googleusercontent.com';
let gsiP=null;
function gUnstick(){if(!busy)return;setTimeout(()=>{if(busy&&!fu){busy=0;sync('')}},1800)}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')gUnstick()});window.addEventListener('focus',gUnstick);
function gsiLoad(){return gsiP||(gsiP=new Promise((ok,no)=>{if(window.google&&google.accounts&&google.accounts.id)return ok();const s=document.createElement('script');s.src='https://accounts.google.com/gsi/client';s.async=true;s.onload=ok;s.onerror=()=>no(new Error('gsi'));document.head.appendChild(s)}))}
async function gPopup(){const p=new firebase.auth.GoogleAuthProvider();p.setCustomParameters({prompt:'select_account'});await fa.signInWithPopup(p)}
let got=0;
async function fedcmTry(){
 if(!('IdentityCredential' in window)||!navigator.credentials)return null;
 const t0=Date.now();
 try{const c=await navigator.credentials.get({mediation:'required',identity:{mode:'active',providers:[{configURL:'https://accounts.google.com/gsi/fedcm.json',clientId:GCID,params:{response_type:'id_token',scope:'email profile openid'}}]}});
  return c&&c.token?{token:c.token}:null}
 catch(e){return{cancel:Date.now()-t0>1500}}}
async function aGoogle(){if(busy)return;busy=1;got=0;sync('⏳ جارٍ فتح حسابات Google...');
 const fin=()=>{busy=0};
 try{
  if(!GCID){await gPopup();sync('✅ تم تسجيل الدخول');return fin()}
  /* الوضع المباشر (FedCM active) كان يفتح نافذة جوجل بخطأ response_type، لذلك نبدأ بنافذة اختيار الحساب العادية ثم نرجع للنافذة المنبثقة المجرّبة */
  await gsiLoad();
  google.accounts.id.initialize({client_id:GCID,use_fedcm_for_prompt:true,cancel_on_tap_outside:false,auto_select:false,itp_support:true,
   callback:async r=>{got=1;try{await fa.signInWithCredential(firebase.auth.GoogleAuthProvider.credential(r.credential));sync('✅ تم تسجيل الدخول')}catch(e){er(e)}fin()}});
  google.accounts.id.prompt(async n=>{try{
   if(n.isDismissedMoment&&n.isDismissedMoment()){if(n.getDismissedReason()!=='credential_returned'&&!got){sync('');fin()}return}
   if(n.isNotDisplayed()||n.isSkippedMoment()){
    const why=(n.isNotDisplayed()?n.getNotDisplayedReason():n.getSkippedReason())||'';
    if(/user_cancel|tap_outside|cancel_called|flow_restarted/.test(why)){sync('');fin();return}
    await new Promise(r=>setTimeout(r,1500));
    if(got||!busy)return;
    try{await gPopup();sync('✅ تم تسجيل الدخول')}catch(e){er(e)}fin()}
  }catch(e){fin()}});
  setTimeout(fin,20000)
 }catch(e){try{await gPopup();sync('✅ تم تسجيل الدخول')}catch(e2){er(e2)}fin()}}

/* ---------- دفتر الملاحظات ---------- */
const NB_ST=[['lined','📏 مسطّر'],['grid','▦ مربعات'],['dot','⠿ منقّط'],['plain','📄 سادة'],['school','🎓 مدرسي'],['en','ABC']];
const NB_FF=[['system-ui,Tahoma,sans-serif','عادي'],['Georgia,serif','كلاسيكي'],['Courier New,monospace','آلة كاتبة'],['Comic Sans MS,cursive','بخط اليد'],...[['Amiri','نسخ — أميري'],['Amiri Quran','نسخ — أميري قرآن'],['Noto Naskh Arabic','نسخ — نوتو'],['Scheherazade New','نسخ — شهرزاد'],['Lateef','نسخ — لطيف'],['Noto Kufi Arabic','كوفي — نوتو'],['Reem Kufi','كوفي — ريم'],['Kufam','كوفي — كوفام'],['Aref Ruqaa','رقعة — عارف'],['Noto Nastaliq Urdu','نستعليق'],['Cairo','القاهرة'],['Tajawal','تجوّل'],['Almarai','المرعي'],['Changa','تشانغا'],['El Messiri','المسيري'],['Markazi Text','مركزي'],['IBM Plex Sans Arabic','IBM بلكس'],['Harmattan','هرمتان'],['Mada','مدى'],['Lalezar','لالزار (عناوين)'],['Rakkas','رقاص (زخرفي)'],['Jomhuria','جمهورية (زخرفي)'],['Katibeh','كاتبة (خط يد)'],['Mirza','ميرزا'],['Lemonada','ليمونادا']].map(([f,l])=>["'"+f+"',system-ui,serif",l])];
const NB_CV=[['classic','📘 مجلّد'],['leather','🟫 جلد'],['modern','🎯 عصري'],['gradient','🌈 متدرج'],['islamic','🕌 زخرفة'],['geo','🔷 هندسي'],['stripe','〰️ خطوط'],['band','▬ شريط'],['minimal','▫️ بسيط'],['simple','▭ سادة']],NB_CL=['#1b5e20','#1565c0','#6a1b9a','#c62828','#ef6c00','#00695c','#4e342e','#37474f'];
const wc=x=>((x||'').trim().match(/\S+/g)||[]).length;let nbCur=0,nbDr=null,nbT=null,nbEd=0;const nbOpen=new Set();
function nbInit(){if(S.nbs)return;S.nbs=[];const o=S.nb;if(o&&o.notes&&o.notes.some(n=>n.t||n.x))S.nbs.push({id:S.id++,name:'دفتري',desc:'',c:NB_CL[0],cv:'classic',paper:o.style||'lined',fs:o.fs||18,ff:o.ff||0,notes:o.notes,cur:o.cur,lock:null})}
const nbK=()=>S.nbs.find(b=>b.id==(nbCur||nbEd));
async function hp(p){try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('qmrm'+p));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}catch(e){let h=5381;for(const c of 'qmrm'+p)h=((h<<5)+h+c.charCodeAt(0))|0;return'x'+h}}
const nbImgSz=b=>{const z=b.iz||1;return (b.ia||.75)>=.8?`auto ${100*z}%`:`${100*z}% auto`};
const nbImgSt=b=>`;background-image:linear-gradient(#0002,#0006),url(${b.img});background-size:100% 100%,${nbImgSz(b)};background-position:center,${b.ix==null?50:b.ix}% ${b.iy==null?50:b.iy}%;background-repeat:no-repeat`;
let cvD=null;
function cvDown(e){const b=nbK();if(!b||!b.img)return;const cov=e.currentTarget.querySelector('.cov');cvD={x:e.clientX,y:e.clientY,cov,b};try{e.currentTarget.setPointerCapture(e.pointerId)}catch(x){dbg(x)}}
function cvMove(e){if(!cvD)return;const{cov,b}=cvD,r=cov.getBoundingClientRect(),w=r.width,h=r.height,z=b.iz||1,ia=b.ia||.75;let iw,ih;if(ia>=.8){ih=h*z;iw=ih*ia}else{iw=w*z;ih=iw/ia}
 const dx=e.clientX-cvD.x,dy=e.clientY-cvD.y;cvD.x=e.clientX;cvD.y=e.clientY;let px=b.ix==null?50:b.ix,py=b.iy==null?50:b.iy;
 if(iw-w>1)px=Math.max(0,Math.min(100,px-dx/(iw-w)*100));if(ih-h>1)py=Math.max(0,Math.min(100,py-dy/(ih-h)*100));b.ix=px;b.iy=py;cov.style.backgroundPosition='center,'+px+'% '+py+'%'}
function cvUp(){if(cvD){cvD=null;save();draw()}}
function cvZoom(v){const b=nbK();b.iz=+v;const c=document.querySelector('#cvdrag .cov');if(c)c.style.backgroundSize='100% 100%,'+nbImgSz(b)}
function cover(b,click){const img=b.img?nbImgSt(b):'',cls=NB_CV.some(x=>x[0]==b.cv)?b.cv:'classic';return `<div class="cov ${cls}" style="--cc:${b.c}${img}" onclick="${click}"><i class="gl"></i><i class="stt"></i><i class="orn"></i>${b.lock?'<span class="lk">🔒</span>':''}<div class="cn">${(b.notes||[]).length} صفحات</div></div>`}
function notebook(){nbInit();return nbCur&&nbK()?editor():shelf()}
function shelf(){const ff=b=>(NB_FF[b.cf||0]||NB_FF[0])[0];return `<div class="row sp" style="padding:4px 14px"><b style="font-size:18px">📓 دفاتري</b><button type="button" class="g" onclick="go('home')">رجوع</button></div><div class="nbg">${S.nbs.map(b=>`<div>${cover(b,`nbOpenB(${b.id})`)}<div class="nbc"><div class="nbt" onclick="nbOpenB(${b.id})"><b style="font-family:${ff(b)}">${esc(b.name||'بلا اسم')}</b>${b.desc?`<small>${esc(b.desc)}</small>`:''}</div><button type="button" class="nbe" aria-label="تعديل" onclick="nbEditCover(${b.id})">${svg('edit')}</button></div></div>`).join('')}<div><div class="cov newb" onclick="nbNewSheet()">${svg('plus')}</div><div class="nbc"><div class="nbt"><b>دفتر جديد</b></div></div></div></div><div class="m" style="text-align:center;padding:12px 14px 0">اضغط القلم بجانب اسم الدفتر لتعديل شكله (الغلاف والألوان والصفحة والقفل).</div>`}
function nbEdSet(k,v){nbK()[k]=v;save();draw();nbEditCover(nbEd)}
function nbEditCover(id){nbEd=id;const b=S.nbs.find(x=>x.id==id);
 $('#sh').innerHTML=shW(`<b>تعديل شكل الدفتر</b><div id="cvdrag" style="margin:8px 0;max-width:170px;touch-action:none" onpointerdown="cvDown(event)" onpointermove="cvMove(event)" onpointerup="cvUp()" onpointercancel="cvUp()">${cover(b,'')}</div>${b.img?`<div class="m">اسحب الصورة داخل الغلاف لتحريكها (يمين/يسار/فوق/تحت)، وكبّر أو صغّر:</div><input type="range" min="1" max="3" step="0.05" value="${b.iz||1}" oninput="cvZoom(this.value)" onchange="save();draw()">`:''}
 <input value="${esc(b.name)}" placeholder="اسم الدفتر" oninput="nbK().name=this.value;nbSv()" style="font-weight:700"><input value="${esc(b.desc)}" placeholder="وصف الدفتر" oninput="nbK().desc=this.value;nbSv()">
 <div class="m">خط عنوان الدفتر</div><select onchange="nbEdSet('cf',+this.value)" style="font-family:${(NB_FF[b.cf||0]||NB_FF[0])[0]}">${fOpts(b.cf||0)}</select>
 <div class="m" style="margin-top:6px">لون الغلاف</div><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:4px 0">${NB_CL.map(c=>`<span onclick="nbEdSet('c','${c}')" style="width:30px;height:30px;border-radius:50%;background:${c};border:3px solid ${b.c==c?'var(--tx)':'var(--bd)'}"></span>`).join('')}<span class="rainbow" onclick="colSheet('cov')"></span></div>
 <div class="m">شكل الغلاف</div><div>${NB_CV.map(([k,t])=>`<span class="chip ${b.cv==k?'on':''}" onclick="nbEdSet('cv','${k}')">${t}</span>`).join('')}</div>
 <div class="m" style="margin-top:6px">صورة الغلاف</div><div class="row"><label style="padding:9px 14px;border-radius:10px;border:1px solid var(--pri);color:var(--pri);cursor:pointer">${svg('camera')} من الاستديو<input type="file" accept="image/*" style="display:none" onchange="nbImg(this)"></label>${b.img?`<button type="button" class="g" onclick="nbEdSet('img','')">إزالة الصورة</button>`:''}</div>
 <div class="row" style="margin-top:6px;flex-wrap:nowrap"><span class="m">الخط الافتراضي:</span><select onchange="nbEdSet('ff',+this.value)" style="flex:1;margin:0;font-family:${(NB_FF[b.ff||0]||NB_FF[0])[0]}">${fOpts(b.ff||0)}</select></div>
 <div class="row sp" style="margin-top:8px"><span class="m">حجم الحرف: <b>${b.fs}</b></span><span><button type="button" class="g" style="padding:6px 14px" onclick="nbEdSet('fs',Math.max(12,nbK().fs-2))">A−</button> <button type="button" class="g" style="padding:6px 14px" onclick="nbEdSet('fs',Math.min(40,nbK().fs+2))">A+</button></span></div>
 <div class="row" style="margin-top:10px"><button type="button" class="g" style="flex:1" onclick="${b.lock?'nbRmLock()':'nbLockSheet()'}">${b.lock?'🔓 إزالة القفل':'🔒 قفل الدفتر بكلمة سر'}</button><button type="button" class="r" style="flex:1" onclick="typedAsk('حذف الدفتر','سيُحذف الدفتر وكل صفحاته نهائياً ولا يمكن التراجع.','nbDelB')">🗑 حذف الدفتر</button></div>
 <button type="button" onclick="$('#sh').innerHTML='';draw()" style="width:100%;margin-top:8px">تم</button>`)}
function nbOpenB(id){const b=S.nbs.find(x=>x.id==id);if(b.lock&&!nbOpen.has(id))nbUnlock(id);else{nbCur=id;nbPi=0;draw()}}
const shW=h=>`<div class="sh" onclick="if(event.target==this)$('#sh').innerHTML=''"><div style="max-height:90%;overflow-y:auto">${h}</div></div>`;
function nbUnlock(id){$('#sh').innerHTML=shW(`<b>🔒 الدفتر مقفل</b><input id="nbp" type="password" placeholder="كلمة السر" dir="ltr"><div id="nbm" class="m" style="color:var(--bad)"></div><button type="button" onclick="nbCheck(${id})">فتح</button><button type="button" class="g" onclick="nbForgot(${id},'open')">نسيت كلمة السر</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
function nbForgot(id,mode){const b=S.nbs.find(x=>x.id==id);if(!b||!b.sq){$('#sh').innerHTML=noSq();return}$('#sh').innerHTML=shW(`<b>سؤال الأمان</b><div style="margin:8px 0">${esc(b.sq)}</div><input id="nba" placeholder="الجواب" autocomplete="off"><div id="nbm" class="m" style="color:var(--bad)"></div><button type="button" onclick="nbForgotCheck(${id},'${mode}')">تأكيد وإزالة القفل</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
async function nbForgotCheck(id,mode){const b=S.nbs.find(x=>x.id==id);if(await hp(nrm($('#nba').value))===b.sa){b.lock=null;b.sq=null;b.sa=null;save();$('#sh').innerHTML='';toast('أُزيل القفل');if(mode=='open'){nbCur=id;nbPi=0}draw();if(mode=='rm'&&!nbCur&&nbEd)nbEditCover(nbEd)}else $('#nbm').textContent='⚠️ الجواب غير صحيح'}
async function nbCheck(id){const b=S.nbs.find(x=>x.id==id);if(await hp($('#nbp').value)===b.lock){nbOpen.add(id);nbCur=id;nbPi=0;$('#sh').innerHTML='';draw()}else $('#nbm').textContent='⚠️ كلمة السر غير صحيحة'}
const QS=['ما اسم مدرستك الأولى؟','ما اسم أقرب أصدقاء طفولتك؟','في أي مدينة وُلدت؟','ما اسم كتابك المفضل؟'];
const qBox=p=>`<div class="m" style="margin-top:6px">سؤال الأمان (لاستعادة الوصول إن نسيت كلمة السر)</div><select id="${p}q">${QS.map(q=>`<option>${q}</option>`).join('')}</select><input id="${p}qc" placeholder="أو اكتب سؤالك الخاص" autocomplete="off"><input id="${p}a" placeholder="الجواب" autocomplete="off">`;
const qRead=p=>({q:($('#'+p+'qc').value.trim()||$('#'+p+'q').value),a:$('#'+p+'a').value});
const noSq=()=>shW('<b>نسيت كلمة السر</b><div class="m" style="margin:8px 0">لم يُضبط سؤال أمان لهذا القفل، لذلك لا يمكن استعادته.</div><button type="button" class="g" onclick="$(\'#sh\').innerHTML=\'\'">إغلاق</button>');
function nbNewSheet(){nbDr={name:'',desc:'',c:NB_CL[0],cv:'classic',paper:'lined',lock:false,pw:'',pw2:'',sq:'',sqc:'',sa:'',err:''};nbSheet()}
function nbSheet(){const d=nbDr;$('#sh').innerHTML=shW(`<b>📓 دفتر جديد</b><div style="margin:8px auto;max-width:150px">${cover({...d,notes:[],lock:d.lock},'')}</div>
 <input placeholder="اسم الدفتر" value="${esc(d.name)}" oninput="nbDr.name=this.value"><input placeholder="وصف الدفتر (اختياري)" value="${esc(d.desc)}" oninput="nbDr.desc=this.value">
 <div class="m">شكل الغلاف</div><div>${NB_CV.map(([k,t])=>`<span class="chip ${d.cv==k?'on':''}" onclick="nbDr.cv='${k}';nbSheet()">${t}</span>`).join('')}</div>
 <div class="m">لون الغلاف</div><div style="display:flex;gap:8px;flex-wrap:wrap;margin:4px 0">${NB_CL.map(c=>`<span onclick="nbDr.c='${c}';nbSheet()" style="width:30px;height:30px;border-radius:50%;background:${c};border:3px solid ${d.c==c?'var(--tx)':'transparent'}"></span>`).join('')}</div>
 <div class="m">شكل الصفحة</div><div>${NB_ST.map(([k,t])=>`<span class="chip ${d.paper==k?'on':''}" onclick="nbDr.paper='${k}';nbSheet()">${t}</span>`).join('')}</div>
 <label style="display:block;margin:8px 0"><input type="checkbox" style="width:auto" ${d.lock?'checked':''} onchange="nbDr.lock=this.checked;nbSheet()"> 🔒 قفل الدفتر بكلمة سر</label>
 ${d.lock?`<input type="password" dir="ltr" placeholder="كلمة السر" value="${esc(d.pw)}" oninput="nbDr.pw=this.value"><input type="password" dir="ltr" placeholder="تأكيد كلمة السر" value="${esc(d.pw2)}" oninput="nbDr.pw2=this.value"><div class="m" style="margin-top:6px">سؤال الأمان (لاستعادة الوصول إن نسيت كلمة السر)</div><select onchange="nbDr.sq=this.value">${QS.map(q=>`<option ${d.sq==q?'selected':''}>${q}</option>`).join('')}</select><input placeholder="أو اكتب سؤالك الخاص" value="${esc(d.sqc)}" oninput="nbDr.sqc=this.value" autocomplete="off"><input placeholder="الجواب" value="${esc(d.sa)}" oninput="nbDr.sa=this.value" autocomplete="off">`:''}
 <div class="m" style="color:var(--bad)">${esc(d.err)}</div><button type="button" onclick="nbCreate()">حفظ الدفتر</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
async function nbCreate(){const d=nbDr;if(d.lock&&(d.pw.length<4||d.pw!==d.pw2||!nrm(d.sa))){d.err=d.pw.length<4?'⚠️ كلمة السر 4 أحرف على الأقل':d.pw!==d.pw2?'⚠️ كلمتا السر غير متطابقتين':'⚠️ اكتب جواب سؤال الأمان';nbSheet();return}
 S.nbs.push({id:S.id++,name:d.name.trim()||'دفتري',desc:d.desc.trim(),c:d.c,cv:d.cv,paper:d.paper,fs:18,ff:0,notes:[{id:S.id++,t:'',x:'',u:Date.now()}],cur:0,lock:d.lock?await hp(d.pw):null,sq:d.lock?(d.sqc.trim()||d.sq||QS[0]):null,sa:d.lock?await hp(nrm(d.sa)):null});save();$('#sh').innerHTML='';draw()}
function nbBg(st,lh,l){l=l||'var(--bd)';
 if(st=='lined'||st=='school')return `background-image:repeating-linear-gradient(transparent 0,transparent ${lh-1}px,${l} ${lh-1}px,${l} ${lh}px)`;
 if(st=='grid')return `background-image:linear-gradient(${l} 1px,transparent 1px),linear-gradient(90deg,${l} 1px,transparent 1px);background-size:${lh}px ${lh}px`;
 if(st=='dot')return `background-image:radial-gradient(${l} 1.6px,transparent 1.8px);background-size:${lh}px ${lh}px`;
 if(st=='en'){const c=/^(#|rgb)/.test(l)?l:'#9e9e9e',sv=`<svg xmlns='http://www.w3.org/2000/svg' width='60' height='${lh}'><line x1='0' y1='${Math.round(lh*.18)}' x2='60' y2='${Math.round(lh*.18)}' stroke='${c}'/><line x1='0' y1='${Math.round(lh*.55)}' x2='60' y2='${Math.round(lh*.55)}' stroke='${c}' stroke-dasharray='5 4'/><line x1='0' y1='${lh-1}' x2='60' y2='${lh-1}' stroke='${c}'/></svg>`;return `background-image:url('data:image/svg+xml,${encodeURIComponent(sv).replace(/'/g,'%27')}');background-size:60px ${lh}px;background-repeat:repeat`}
 return ''}
let nbPi=0,nbFrom=null,nbTb=false,nbDraw='',nbRuler=false,nbCol='#1565c0',nbAsk=null,nbSel={s:0,e:0};const nbDet={cv:1};let tbSec='',nbMode='',nbEW=false,tbLn=false,tbLs=false,tbSt=false,tbSu=false;const nbSz={p:3,h:18,e:14},SZR={p:[1,14],h:[6,48],e:[6,60]};
const mixW=(h,k)=>{const n=parseInt(h.slice(1),16),f=c=>Math.round(c+(255-c)*k);return'#'+[f(n>>16),f((n>>8)&255),f(n&255)].map(x=>x.toString(16).padStart(2,'0')).join('')};
const lum=h=>{const n=parseInt(h.slice(1),16);return(.299*(n>>16)+.587*((n>>8)&255)+.114*(n&255))/255};
const NB_PC=['#ffffff','#fffbe6','#fff3e0','#fce4ec','#e3f2fd','#e8f5e9','#f3e5f5','#eceff1','#263238','#1b1b1b'];
const NB_COL=['#222222','#1565c0','#c62828','#2e7d32','#ef6c00','#6a1b9a','#ffeb3b','#76ff03','#ff80ab','#40c4ff'];
const NB_FR=[[0,'بلا إطار'],[1,'خط'],[2,'مزدوج'],[3,'مستدير'],[4,'متقطع'],[5,'مزخرف'],[6,'أوراق متراكبة']];
const nbCP=()=>nbK().notes[nbPi];
const nbF=(b,n)=>{const i=n.ff!=null?n.ff:(b.ff||0);return{fs:n.fs||b.fs,ffi:i,ff:(NB_FF[i]||NB_FF[0])[0],al:n.al||'start'}};
const fOpts=sel=>NB_FF.map((f,i)=>`<option value="${i}" style="font-family:${f[0]}" ${i==sel?'selected':''}>${f[1]}</option>`).join('');
const nbPcC=pc=>{if(!pc)return{bg:'var(--bg)',fg:'var(--tx)',ln:'var(--bd)'};const dk=lum(pc)<.4;return{bg:pc,fg:dk?'#eceff1':'#222',ln:dk?'rgba(255,255,255,.18)':'rgba(0,0,0,.14)'}};
const nbPP=(b,n)=>({paper:n.paper||b.paper||'lined',pc:n.pc!=null?n.pc:(b.pc||'')});
function nbSec(k){tbSec=tbSec==k?'':k;draw()}
function nbPgPaper(k){nbCP().paper=k;nbMark('paper');save();draw()}
function nbPgColor(c){nbCP().pc=c;nbMark('pc');save();draw()}
function nbSzSet(v){nbSz[nbDraw]=+v;const e=$('#szv');if(e)e.textContent=v}
function editor(){const b=nbK();if(!b.notes.length)b.notes.push({id:S.id++,x:'',u:Date.now()});b.notes.forEach(n=>{if(n.t){n.x=n.t+'\n'+n.x;n.t=''}});if(nbPi>=b.notes.length)nbPi=b.notes.length-1;
 const words=b.notes.reduce((a,n)=>a+wc(n.x),0),cn=b.notes[nbPi],f0=nbF(b,cn),p0=nbPP(b,cn),pg=b.notes.map((x,i)=>nbPageHtml(b,x,i)).join(''),o0=nbObjCur();
 const sw=(c,fn,cur)=>`<span onclick="${fn}('${c}')" style="width:28px;height:28px;border-radius:50%;background:${c};border:3px solid ${cur==c?'var(--tx)':'var(--bd)'}"></span>`,lab='padding:8px 12px;border-radius:10px;border:1px solid var(--pri);color:var(--pri);cursor:pointer;font-size:13px';
 const stk=S.stk||[],usedO=(cn.im||[]),isSaved=o=>stk.some(k=>k.key===stkKey(o));
 const stkPanel=`<div style="display:flex;flex-wrap:wrap;gap:8px;margin:6px 0">${stk.map(k=>`<div style="position:relative"><img alt="" src="${k.src}" onclick="nbUseStk(${k.id})" style="width:58px;height:58px;object-fit:contain;border:1px solid var(--bd);border-radius:8px;background:#fff"><span onclick="ask('هل تريد حذف الملصق من الملصقات المحفوظة؟',()=>stkDel(${k.id}),'نعم، احذف','لا')" style="position:absolute;top:-7px;inset-inline-end:-7px;width:20px;height:20px;border-radius:50%;background:var(--bad);color:#fff;text-align:center;line-height:20px;font-size:13px">×</span></div>`).join('')||'<div class="m">لا ملصقات محفوظة بعد</div>'}</div><div class="row sp" style="cursor:pointer" onclick="tbSu=!tbSu;draw()"><span>الملصقات المستخدمة في هذه الصفحة (${usedO.length})</span><span class="m">${tbSu?'▴':'▾'}</span></div>${tbSu?`<div style="margin:6px 0">${usedO.map(o=>`<div class="row" style="flex-wrap:nowrap;padding:4px 0"><img alt="" src="${o.src}" onclick="nbSelO=${o.id};draw()" style="width:48px;height:48px;object-fit:contain;border:${nbSelO==o.id?'2px solid var(--pri)':'1px solid var(--bd)'};border-radius:8px;background:#fff;cursor:pointer"><span style="flex:1"></span>${isSaved(o)?'<span class="m">✓ محفوظ</span>':`<button type="button" class="g" style="padding:5px 12px" onclick="stkSave(${o.id})">حفظ</button>`}</div>`).join('')||'<div class="m">لا ملصقات في هذه الصفحة</div>'}</div>`:''}`;
 const tools=`<div class="tr"><button type="button" class="g ${nbDraw=='p'?'on':''}" onclick="nbTool('p')">${svg('edit')}</button><button type="button" class="g ${nbDraw=='h'?'on':''}" onclick="nbTool('h')">${svg('hl')}</button><button type="button" class="g ${nbDraw=='e'?'on':''}" onclick="nbTool('e')">${svg('er')}</button><button type="button" class="g ${nbRuler?'on':''}" onclick="nbRuler=!nbRuler;draw()">${svg('rl')}</button><button type="button" class="g" onclick="nbUndo()">${svg('reset')}</button><button type="button" class="g" onclick="ask('مسح كل الرسم في هذه الصفحة؟',nbClr,'نعم، امسح')">${svg('trash')}</button></div>
 ${nbDraw?`<div class="tr"><span class="m">الحجم: <b id="szv">${nbSz[nbDraw]}</b></span><input type="range" class="sz" min="${SZR[nbDraw][0]}" max="${SZR[nbDraw][1]}" value="${nbSz[nbDraw]}" oninput="nbSzSet(this.value)" style="flex:1"></div>`:'<div class="m">اختر أداة (قلم / قلم تحديد / ممحاة) ثم ارسم على الصفحة.</div>'}
 ${nbDraw=='e'?`<label class="m" style="display:block"><input type="checkbox" style="width:auto" ${nbEW?'checked':''} onchange="nbEW=this.checked"> مسح الخط كاملاً (بدل المسح تدريجياً)</label>`:''}
 ${nbDraw=='p'?`<div class="m">شكل القلم</div><div class="tr">${NBSH.map(([k,t])=>`<span class="chip ${nbShape==k?'on':''}" onclick="nbShape='${k}';draw()">${t}</span>`).join('')}</div>`:''}
 ${nbDraw&&nbDraw!='e'?`<div class="tr">${NB_COL.map(c=>`<span onclick="nbCol='${c}';draw()" style="width:26px;height:26px;border-radius:50%;background:${c};border:3px solid ${nbCol==c?'var(--tx)':'var(--bd)'}"></span>`).join('')}<span class="rainbow" onclick="colSheet('pen')"></span></div>`:''}
 <label class="m" style="display:block;margin-top:6px"><input type="checkbox" style="width:auto" ${S.nbTwo?'checked':''} onchange="S.nbTwo=this.checked;save();nbZ={s:1,x:0,y:0};nbZApply();draw()"> التحكم بإصبعين: تكبير وتحريك الشاشة دون رسم أو مسح (الرسم بإصبع واحد)</label>${S.nbTwo&&nbZ.s>1?'<button type="button" class="g" style="padding:6px 12px" onclick="nbZ={s:1,x:0,y:0};nbZApply();draw()">إعادة حجم الشاشة</button>':''}
 <div class="row sp" style="margin-top:8px;cursor:pointer" onclick="tbLn=!tbLn;draw()"><span>شكل السطر في هذه الصفحة</span><span class="m">${tbLn?'▴':'▾'}</span></div>${tbLn?`<div>${NB_ST.map(([k,t])=>`<span class="chip ${p0.paper==k?'on':''}" onclick="nbPgPaper('${k}')">${t}</span>`).join('')}</div>`:''}
 <div class="m" style="margin-top:8px">الملصقات</div><div class="tr"><label style="${lab}">${svg('plus')} إضافة ملصق<input type="file" accept="image/*" style="display:none" onchange="nbAddObj('st',this)"></label></div>
 <div class="row sp" style="margin-top:6px;cursor:pointer" onclick="tbSt=!tbSt;draw()"><span>الملصقات المحفوظة (${(S.stk||[]).length})</span><span class="m">${tbSt?'▴':'▾'}</span></div>${tbSt?stkPanel:''}
 ${o0?`<div class="m" style="margin-top:6px">الصورة المحددة: اسحبها للتحريك، واستعمل إصبعين أو المقبض السفلي للتكبير والتصغير</div><div class="tr"><button type="button" class="g" onclick="nbObjSz(-.1)">−</button><button type="button" class="g" onclick="nbObjSz(.1)">+</button><button type="button" class="g" onclick="stkSave(nbSelO)">حفظ ملصق</button><button type="button" class="g" onclick="ask('هل تريد حذف الملصق؟',nbObjDel,'نعم، احذف','لا')">${svg('trash')} حذف</button><button type="button" class="g" onclick="nbSelO=0;draw()">تم</button></div><div class="m">القص (٪)</div>${[['l','يسار'],['r','يمين'],['t','أعلى'],['b','أسفل']].map(([k,t])=>`<div class="tr"><span class="m" style="width:46px">${t}</span><input type="range" class="sz" min="0" max="60" value="${Math.round(((o0.c||{})[k]||0)*100)}" oninput="nbCrop('${k}',this.value)" style="flex:1"></div>`).join('')}`:''}
 <button type="button" class="g" style="width:100%;margin-top:8px" onclick="nbApplyOpen()">تطبيق إعدادات هذه الصفحة على صفحات أختارها</button>
 <div class="m" style="margin-top:8px">تصدير الدفتر</div><div class="tr"><button type="button" onclick="nbExport('pdf')">PDF</button><button type="button" class="g" onclick="nbExport('word')">Word</button></div>`;
 const org=`<div class="tr"><button type="button" class="g" onclick="nbFs(-2)">A−</button><button type="button" class="g" onclick="nbFs(2)">A+</button><select onchange="nbFontText(+this.value)" style="margin:0;flex:1;min-width:90px">${fOpts(nbFnt!=null?nbFnt:f0.ffi)}</select></div>
 <div class="m" style="margin-top:6px">لون الصفحة</div><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><span onclick="nbPgColor('')" style="width:28px;height:28px;border-radius:50%;border:3px solid ${!p0.pc?'var(--tx)':'var(--bd)'};background:linear-gradient(135deg,var(--bg) 46%,var(--mut) 50%,var(--bg) 54%)"></span>${NB_PC.map(c=>sw(c,'nbPgColor',p0.pc)).join('')}<span class="rainbow" onclick="colSheet('pg')"></span></div>
 <div class="row sp" style="margin-top:8px;cursor:pointer" onclick="tbLs=!tbLs;draw()"><span>جهة الكتابة والقوائم</span><span class="m">${tbLs?'▴':'▾'}</span></div>${tbLs?`<div class="tr"><button type="button" class="g" data-al="start" onclick="nbAlign('start')">${svg('alS')}</button><button type="button" class="g" data-al="center" onclick="nbAlign('center')">${svg('alC')}</button><button type="button" class="g" data-al="end" onclick="nbAlign('end')">${svg('alE')}</button></div><div class="tr"><button type="button" class="g ${nbMode=='ol'?'on':''}" data-md="ol" onclick="nbModeTg('ol')">${svg('ol')}</button><button type="button" class="g ${nbMode=='bl'?'on':''}" data-md="bl" onclick="nbModeTg('bl')">${svg('bl')}</button><button type="button" class="g ${nbMode=='ck'?'on':''}" data-md="ck" onclick="nbModeTg('ck')">${svg('cs')}</button><button type="button" class="g" onclick="nbBoxTg()">☐/☑</button></div>`:''}
 <div class="m" style="margin-top:8px">لون الكتابة</div><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><span onclick="nbTxtColor('')" style="width:28px;height:28px;border-radius:50%;border:3px solid var(--bd);background:linear-gradient(135deg,var(--bg) 46%,var(--mut) 50%,var(--bg) 54%)"></span>${NB_COL.map(c=>sw(c,'nbTxtColor','')).join('')}<span class="rainbow" onclick="nbRange0();colSheet('txt')"></span></div>
 <label class="m" style="display:block;margin-top:8px"><input type="checkbox" style="width:auto" ${S.nbFree===false?'':'checked'} onchange="S.nbFree=this.checked;save()"> ينتقل المؤشر إلى المكان الذي أضغط عليه</label>`;
 const tb=`<div id="nbtb" class="tb" onpointerdown="nbTbDown(event)"><div class="row" style="flex-wrap:nowrap"><button type="button" class="g ${tbSec=='t'?'on':''}" style="flex:1" onclick="nbSec('t')">${svg('edit')} الأدوات ${tbSec=='t'?'▴':'▾'}</button><button type="button" class="g ${tbSec=='o'?'on':''}" style="flex:1" onclick="nbSec('o')">${svg('sliders')} التنظيم ${tbSec=='o'?'▴':'▾'}</button></div>${tbSec=='t'?tools:tbSec=='o'?org:''}</div>`;
 setTimeout(nbRestore,0);
 return `<div class="row sp" style="padding:4px 14px"><button type="button" class="g" onclick="nbOpen.delete(nbCur);nbCur=0;draw()">📚 الدفاتر</button><span class="m">${esc(b.name)} • ${b.lock?'🔒':'🔓'} • ${b.notes.length} صفحة • ${words} كلمة</span></div>
 ${tb}
 <div id="nbvp" style="overflow:hidden"><div id="nbpg" class="pager" onscroll="nbScr(this)">${pg}</div></div>
 <div class="row sp" style="padding:4px 14px;flex-wrap:nowrap"><button type="button" class="g fl" onclick="nbGo(-1)">${svg('chev')} السابقة</button><span id="nbpi" class="m">صفحة ${nbPi+1} / ${b.notes.length}</span><button type="button" class="g nx" onclick="nbGo(1)">التالية ${svg('chev')}</button></div>
 <div class="row" style="padding:4px 14px"><button type="button" style="flex:1" onclick="nbAddPg()">➕ إضافة صفحة</button><button type="button" class="g" onclick="ask('حذف الصفحة '+(nbPi+1)+'؟',nbDelCur,'نعم، احذف')">🗑 حذف الصفحة</button></div>
 <div class="m" style="text-align:center;padding:0 14px">اضغط في أي مكان في الصفحة وابدأ الكتابة. تعديل شكل الدفتر (الغلاف والألوان والقفل) من قائمة الدفاتر بزر القلم.</div>`}
const isRtl=el=>{try{return getComputedStyle(el).direction=='rtl'}catch(e){return true}};
function nbRestore(){try{nbZApply()}catch(e){dbg(e)}const el=$('#nbpg');if(!el)return;const x=k=>(isRtl(el)?-1:1)*k*el.clientWidth;try{if(nbFrom!==null&&nbFrom!==nbPi){el.scrollLeft=x(nbFrom);const to=x(nbPi);setTimeout(()=>{try{el.scrollTo({left:to,behavior:'smooth'})}catch(e){el.scrollLeft=to}},60)}else el.scrollLeft=x(nbPi)}catch(e){dbg(e)}nbFrom=null;nbCanv()}
function nbScr(el){const i=Math.round(Math.abs(el.scrollLeft)/Math.max(1,el.clientWidth));if(i!==nbPi){nbPi=i;const e=$('#nbpi');if(e)e.textContent='صفحة '+(i+1)+' / '+el.children.length}}
function nbGo(d){const el=$('#nbpg'),n=el.children.length,i=Math.max(0,Math.min(n-1,nbPi+d)),x=(isRtl(el)?-1:1)*i*el.clientWidth;nbPi=i;try{el.scrollTo({left:x,behavior:'smooth'})}catch(e){el.scrollLeft=x}const e=$('#nbpi');if(e)e.textContent='صفحة '+(i+1)+' / '+n}
function nbDelCur(){const b=nbK();b.notes.splice(nbPi,1);if(nbPi>=b.notes.length)nbPi=Math.max(0,b.notes.length-1);save();draw()}
function nbTbShow(){}
function nbMark(){}
function nbFs(d){const b=nbK(),n=nbCP();n.fs=Math.max(12,Math.min(40,(n.fs||b.fs)+d));nbMark('fs');save();draw()}
function nbPgFont(i){nbCP().ff=i;nbMark('ff');save();draw()}
function nbFontText(i){nbFnt=i;const ed=nbEd1();if(!ed)return;try{ed.focus();const sl=getSelection();if(nbRange&&ed.contains(nbRange.startContainer)){sl.removeAllRanges();sl.addRange(nbRange)}document.execCommand('styleWithCSS',false,true);document.execCommand('fontName',false,((NB_FF[i]||NB_FF[0])[0]).split(',')[0].replace(/'/g,''))}catch(e){dbg(e)}nbSync(ed)}
function nbApplyOpen(){const b=nbK();$('#sh').innerHTML=shW(`<b>تطبيق إعدادات هذه الصفحة على صفحات أختارها</b><div class="m" style="margin:6px 0">ما الذي تريد نسخه؟</div>${[['fs','حجم الخط'],['paper','شكل السطر'],['pc','لون الصفحة']].map(([k,t])=>`<label style="display:block;padding:4px 0"><input type="checkbox" class="nbk" value="${k}" checked style="width:auto"> ${t}</label>`).join('')}<div class="m" style="margin:8px 0 4px">الصفحات:</div><label style="display:block;margin:4px 0"><input type="checkbox" style="width:auto" onchange="document.querySelectorAll('.nbsel').forEach(c=>c.checked=this.checked)"> تحديد الكل</label>${b.notes.map((x,i)=>i==nbPi?'':`<label style="display:block;padding:5px 0"><input type="checkbox" class="nbsel" value="${i}" style="width:auto"> صفحة ${i+1}</label>`).join('')}<button type="button" onclick="nbApply()" style="width:100%;margin-top:8px">تطبيق</button><button type="button" class="g" onclick="$('#sh').innerHTML=''" style="width:100%">إلغاء</button>`)}
function nbApply(){const b=nbK(),c=nbCP(),ks=[...document.querySelectorAll('.nbk:checked')].map(x=>x.value),sel=[...document.querySelectorAll('.nbsel:checked')].map(x=>+x.value);sel.forEach(i=>{const n=b.notes[i];ks.forEach(k=>{n[k]=c[k]!=null?c[k]:(k=='fs'?b.fs:k=='paper'?(b.paper||'lined'):(b.pc||''))})});nbAsk=null;save();$('#sh').innerHTML='';toast('تم التطبيق على '+sel.length+' صفحة');draw()}

/* ---------- نص منسّق (contenteditable): المحاذاة واللون لكل نص على حدة ---------- */
const NB_OK={div:1,span:1,br:1,a:1};
function nbClean(h){return String(h||'').replace(/<(\/?)([a-z0-9]+)([^>]*)>/gi,(m,sl,tag,at)=>{tag=tag.toLowerCase();if(!NB_OK[tag])return '';if(sl)return '</'+tag+'>';if(tag=='br')return '<br>';
 if(tag=='a'){const hr=/href\s*=\s*"([^"]*)"/i.exec(at)||/href\s*=\s*'([^']*)'/i.exec(at),u=hr?hr[1].replace(/&amp;/g,'&'):'';return /^https?:\/\/[^\s"'<>]+$/i.test(u)?'<a href="'+u.replace(/&/g,'&amp;')+'">':'<a>'}
 const st=/style\s*=\s*"([^"]*)"/i.exec(at)||/style\s*=\s*'([^']*)'/i.exec(at);let o='';if(st){const sy=st[1].replace(/&quot;/g,"'"),a=/text-align\s*:\s*(center|end|start|left|right)/i.exec(sy),c=/(?:^|;|\s)color\s*:\s*(#[0-9a-f]{3,8}|rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)|hsl\([^)]*\))/i.exec(sy);if(a)o+='text-align:'+a[1].toLowerCase()+';';if(c)o+='color:'+c[1]+';';const ff=/font-family\s*:\s*([^;]+)/i.exec(sy);if(ff){const nm=ff[1].replace(/&quot;|["']/g,'').split(',')[0].trim();if(NB_FF.some(f=>f[0].split(',')[0].replace(/'/g,'').trim().toLowerCase()==nm.toLowerCase()))o+="font-family:'"+nm+"',serif;"}}
 return '<'+tag+(o?' style="'+o+'"':'')+'>'}).replace(/&(?!(amp|lt|gt|nbsp|quot|#\d+);)/g,'&amp;')}
const nbText=h=>String(h||'').replace(/<div([^>]*)><br\s*\/?><\/div>/gi,'<div$1></div>').replace(/<br\s*\/?>/gi,'\n').replace(/<\/div>\s*<div[^>]*>/gi,'\n').replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&amp;/g,'&');
const fromText=x=>String(x||'').split('\n').map(l=>'<div>'+(esc(l)||'<br>')+'</div>').join('');
let nbRange=null;
const nbEd1=()=>document.querySelectorAll('#nbpg .rt')[nbPi];
const nbBlock=(ed,n)=>{while(n&&n.parentNode!==ed)n=n.parentNode;return n&&n.parentNode===ed?n:null};
const nbFirstText=el=>{for(const c of el.childNodes){if(c.nodeType===3&&c.nodeValue!=='')return c;if(c.nodeType===1&&c.tagName!=='BR'){const t=nbFirstText(c);if(t)return t}}return null};
const nbLastText=el=>{const L=[...el.childNodes];for(let k=L.length-1;k>=0;k--){const c=L[k];if(c.nodeType===3&&c.nodeValue!=='')return c;if(c.nodeType===1&&c.tagName!=='BR'){const t=nbLastText(c);if(t)return t}}return null};
function nbRange0(){try{const s=getSelection();if(s&&s.rangeCount){const r=s.getRangeAt(0),pg=$('#nbpg');if(pg&&pg.contains&&pg.contains(r.startContainer))nbRange=r.cloneRange()}}catch(e){dbg(e)}}
function nbNorm(ed){const s=window.getSelection?getSelection():null,an=s&&s.anchorNode,ao=s&&s.anchorOffset;let cur=null,ch=false;
 [...ed.childNodes].forEach(n=>{if(n.nodeType===1&&n.tagName==='DIV'){cur=null;return}if(!cur){cur=document.createElement('div');ed.insertBefore(cur,n)}cur.appendChild(n);ch=true});
 if(!ed.firstChild){ed.innerHTML='<div><br></div>'}
 if(ch&&an&&ed.contains(an)){try{const r=document.createRange();r.setStart(an,ao);r.collapse(true);s.removeAllRanges();s.addRange(r)}catch(e){dbg(e)}}}
function nbSync(ed){const b=nbK(),n=b&&b.notes.find(x=>x.id==+ed.dataset.id);if(!n)return;n.h=nbClean(ed.innerHTML);n.x=nbText(n.h);ed.setAttribute&&ed.setAttribute('data-empty',n.x.replace(/\s+/g,'')?'':'1');nbSv()}
function nbUi(){const e=$('#nbpi');if(e)e.textContent='صفحة '+(nbPi+1)+' / '+nbK().notes.length}
function nbShow(i){nbPi=i;const el=$('#nbpg');if(!el)return;const x=(isRtl(el)?-1:1)*i*el.clientWidth;try{el.scrollTo({left:x,behavior:'smooth'})}catch(e){el.scrollLeft=x}nbUi()}
function nbCaretEnd(el){try{const s=getSelection(),r=document.createRange();r.selectNodeContents(el);r.collapse(false);s.removeAllRanges();s.addRange(r)}catch(e){dbg(e)}}
const hexRgb=h=>{const n=parseInt(h.slice(1),16);return 'rgb('+(n>>16)+', '+((n>>8)&255)+', '+(n&255)+')'};
function nbTypeFmt(len){if(!len||(nbFnt==null&&nbTypC===null))return;try{const sl=getSelection();if(!sl||!sl.rangeCount||!sl.isCollapsed)return;const nd=sl.anchorNode,off=sl.anchorOffset;if(!nd||nd.nodeType!==3||off<len)return;const el=nd.parentElement,cs=getComputedStyle(el),ed=nbEd1(),
  want=nbFnt!=null?((NB_FF[nbFnt]||NB_FF[0])[0].split(',')[0].replace(/'/g,'')):'',cur=cs.fontFamily.split(',')[0].replace(/["']/g,'').trim(),base=ed?getComputedStyle(ed).color:'',tc=nbTypC===null?null:(nbTypC===''?base:hexRgb(nbTypC)),needF=want&&cur.toLowerCase()!==want.toLowerCase(),needC=tc!==null&&cs.color!==tc;
  if(!needF&&!needC)return;const r=document.createRange();r.setStart(nd,off-len);r.setEnd(nd,off);sl.removeAllRanges();sl.addRange(r);document.execCommand('styleWithCSS',false,true);
  if(needC){if(nbTypC==='')document.execCommand('removeFormat');else document.execCommand('foreColor',false,nbTypC)}if(needF)document.execCommand('fontName',false,want);sl.collapseToEnd()}catch(e){dbg(e)}}
function nbCompEnd(e,ed){if(e.data)nbTypeFmt(e.data.length);nbSync(ed)}
function nbRtIn(e,ed){nbNorm(ed);if(e.inputType=='insertText'&&!e.isComposing&&e.data)nbTypeFmt(e.data.length);if(e.inputType=='insertText'&&e.data===' ')nbLkDetect(ed);
 if(nbMode&&(e.inputType=='insertParagraph'||e.inputType=='insertLineBreak')){const s=getSelection(),b=nbBlock(ed,s&&s.anchorNode);if(b){const pr=b.previousElementSibling,pt=pr?pr.textContent:'';let mk;if(nbMode=='ol'){const m=/^\s*(\d+)\.\s/.exec(pt);mk=(m?+m[1]+1:1)+'. '}else mk=nbMode=='bl'?'• ':'☐ ';try{document.execCommand('insertText',false,mk)}catch(x){dbg(x)}}}
 nbSync(ed);nbFlow(ed)}
/* انتقال تلقائي للصفحة التالية بدون إعادة رسم (حتى لا تُغلق لوحة المفاتيح) */
function nbFlow(ed){if(ed.scrollHeight<=ed.clientHeight+1)return;const b=nbK(),i=+ed.dataset.i,pager=$('#nbpg');if(!pager)return;
 const sel=window.getSelection?getSelection():null,anc=nbBlock(ed,sel&&sel.anchorNode),moved=[];let split=null;
 while(ed.scrollHeight>ed.clientHeight+1&&ed.children.length>1){moved.unshift(ed.lastElementChild);ed.removeChild(ed.lastElementChild)}
 if(ed.scrollHeight>ed.clientHeight+1){const blk=ed.lastElementChild,tn=blk&&nbLastText(blk);
  if(tn){const T=tn.nodeValue;let lo=0,hi=T.length;while(lo<hi){const m=(lo+hi+1)>>1;tn.nodeValue=T.slice(0,m);if(ed.scrollHeight<=ed.clientHeight+1)lo=m;else hi=m-1}
   let cut=Math.max(1,lo);const br=Math.max(T.lastIndexOf(' ',cut),T.lastIndexOf('\u00a0',cut));if(br>cut-40&&br>0)cut=br+1;tn.nodeValue=T.slice(0,cut);
   const cl=blk.cloneNode(false);let leaf=document.createTextNode(T.slice(cut)),cur=tn.parentNode;while(cur&&cur!==blk){const w=cur.cloneNode(false);w.appendChild(leaf);leaf=w;cur=cur.parentNode}cl.appendChild(leaf);moved.unshift(cl);split=blk}}
 if(!moved.length)return;
 let nx=pager.children[i+1];if(!nx){const n={id:S.id++,x:'',h:'',u:Date.now()};b.notes.push(n);pager.insertAdjacentHTML('beforeend',nbPageHtml(b,n,i+1));nx=pager.children[i+1]}
 const ned=nx.querySelector('.rt');if(ned.children.length==1&&ned.firstElementChild.textContent==='')ned.removeChild(ned.firstElementChild);
 for(let k=moved.length-1;k>=0;k--)ned.insertBefore(moved[k],ned.firstChild);
 const caretIn=anc&&(moved.includes(anc)||anc===split),tgt=anc===split?moved[0]:anc;
 nbSync(ed);nbSync(ned);try{nbCanv()}catch(e){dbg(e)}
 if(caretIn){ned.focus();nbCaretEnd(tgt);nbShow(i+1)}else nbUi();
 nbFlow(ned)}
/* مؤشر الكتابة ينتقل إلى مكان الضغط (يمكن إيقافه) */
const nbUrl=u=>/^https?:\/\//i.test(u)?u:'https://'+u;
function nbLkHide(){const b=document.getElementById('lkbar');if(b)b.remove();clearTimeout(nbLk&&nbLk.tm)}
function nbLkBar(){nbLkHide();const b=document.createElement('div');b.id='lkbar';b.className='lkb';let h='';try{h=new URL(nbLk.url).hostname}catch(e){h=nbLk.url}
 b.innerHTML=`<div style="font-size:13px">رابط <b dir="ltr">${esc(h)}</b> — تريد اختصاره باسم تختاره؟</div><div class="row" style="margin-top:6px"><button type="button" style="flex:1;padding:8px" onclick="nbLkYes()">اختصاره</button><button type="button" class="g" style="flex:1;padding:8px" onclick="nbLkNo()">كما هو</button></div>`;document.body.appendChild(b);nbLk.tm=setTimeout(()=>{nbLkHide();nbLk=null},12000)}
function nbLkYes(){const b=document.getElementById('lkbar');if(!b||!nbLk)return;clearTimeout(nbLk.tm);b.innerHTML='<input id="lkn" placeholder="الاسم الذي سيظهر بدل الرابط" autocomplete="off" onkeydown="if(event.key===\'Enter\')nbLkDo()"><div class="row" style="margin-top:6px"><button type="button" style="flex:1;padding:8px" onclick="nbLkDo()">حفظ</button><button type="button" class="g" style="flex:1;padding:8px" onclick="nbLkNo()">إلغاء</button></div>';const i=document.getElementById('lkn');if(i&&i.focus)i.focus()}
function nbLkNo(){const k=nbLk;nbLkHide();nbLk=null;if(k&&k.paste){const ed=nbEd1();try{if(ed){ed.focus();const sl=getSelection();if(nbRange&&ed.contains(nbRange.startContainer)){sl.removeAllRanges();sl.addRange(nbRange)}document.execCommand('insertText',false,k.raw);nbSync(ed)}}catch(e){dbg(e)}}}
function nbLkDo(){const k=nbLk,i=document.getElementById('lkn'),ed=nbEd1();if(!k||!ed){nbLkHide();nbLk=null;return}let nm=(i&&i.value||'').trim();if(!nm){try{nm=new URL(k.url).hostname}catch(e){nm=k.url}}
 const html='<a href="'+esc(k.url)+'">'+esc(nm)+'</a>';nbLkHide();nbLk=null;
 try{ed.focus();const sl=getSelection();if(!k.paste&&k.node&&k.node.nodeValue&&k.node.nodeValue.slice(k.start,k.end)===k.raw){const r=document.createRange();r.setStart(k.node,k.start);r.setEnd(k.node,k.end);sl.removeAllRanges();sl.addRange(r)}else if(nbRange&&ed.contains(nbRange.startContainer)){sl.removeAllRanges();sl.addRange(nbRange)}document.execCommand('insertHTML',false,html)}catch(e){dbg(e)}nbSync(ed)}
function nbLkDetect(ed){try{const sl=getSelection(),nd=sl.anchorNode,off=sl.anchorOffset;if(!nd||nd.nodeType!==3||off<2)return;const bf=nd.nodeValue.slice(0,off-1).replace(/\u00a0/g,' '),m=/(https?:\/\/[^\s]+|www\.[^\s]+)$/i.exec(bf);if(!m||(nd.parentElement&&nd.parentElement.closest&&nd.parentElement.closest('a')))return;nbLk={url:nbUrl(m[0]),raw:m[0],node:nd,start:bf.length-m[0].length,end:bf.length};nbLkBar()}catch(e){dbg(e)}}
function nbPaste(e,ed){const t=((e.clipboardData||window.clipboardData).getData('text')||'').trim();e.preventDefault();nbRange0();
 if(/^(https?:\/\/|www\.)\S+$/i.test(t)){nbLk={url:nbUrl(t),raw:t,paste:true};nbLkBar();return}
 try{document.execCommand('insertText',false,t)}catch(x){dbg(x)}nbSync(ed)}
function nbRtTap(e,ed){const a=e.target&&e.target.closest&&e.target.closest('a[href]');if(a){e.preventDefault();window.open(a.getAttribute('href'),'_blank','noopener');return}nbRange0();if(S.nbFree===false)return;try{const sel=getSelection();if(sel&&!sel.isCollapsed)return;
 const cs=getComputedStyle(ed),lh=parseFloat(cs.lineHeight),rc=ed.getBoundingClientRect(),y=e.clientY-rc.top,last=ed.lastElementChild,bottom=last?last.offsetTop+last.offsetHeight:0,pad=parseFloat(cs.paddingLeft)||0,rtl=cs.direction=='rtl',cv=document.createElement('canvas').getContext('2d');
 cv.font=cs.fontStyle+' '+cs.fontWeight+' '+cs.fontSize+' '+cs.fontFamily;const sw=cv.measureText(' ').width,dx=Math.max(0,rtl?(rc.right-pad-e.clientX):(e.clientX-rc.left-pad)),nsp=n=>'\u00a0'.repeat(Math.max(0,Math.round(n)));
 if(y>bottom+2){const k=Math.floor((y-bottom)/lh)+1;let b;for(let q=0;q<k;q++){b=document.createElement('div');b.innerHTML='<br>';ed.appendChild(b)}if(dx>sw){b.innerHTML='';b.appendChild(document.createTextNode(nsp(dx/sw)))}nbCaretEnd(b);nbSync(ed);nbFlow(ed);return}
 const blk=nbBlock(ed,e.target);if(blk&&!blk.style.textAlign&&blk.offsetHeight<=lh*1.4){const w=cv.measureText(blk.textContent).width;if(dx>w+sw*1.5){const tn=nbLastText(blk)||blk.appendChild(document.createTextNode(''));if(tn.parentNode===blk&&blk.querySelector&&blk.querySelector('br'))blk.innerHTML='';const t2=nbLastText(blk)||blk.appendChild(document.createTextNode(''));t2.nodeValue+=nsp((dx-w)/sw);nbCaretEnd(blk);nbSync(ed)}}}catch(x){dbg(x)}}
/* المحاذاة واللون والقوائم: تؤثر فقط على النص المحدد أو الذي ستكتبه بعد الضغط */
function nbSelBlocks(ed){const sel=window.getSelection?getSelection():null;let r=sel&&sel.rangeCount?sel.getRangeAt(0):null;if(!r||!ed.contains(r.startContainer))r=nbRange&&ed.contains(nbRange.startContainer)?nbRange:null;if(!r){const l=ed.lastElementChild;return l?[l]:[]}
 const a=nbBlock(ed,r.startContainer),z=nbBlock(ed,r.endContainer),ch=[...ed.children],i=Math.max(0,ch.indexOf(a)),j=z?ch.indexOf(z):i;return ch.slice(i,Math.max(i,j)+1)}
function nbAlign(al){const ed=nbEd1();if(!ed)return;nbNorm(ed);const bl=nbSelBlocks(ed);if(!bl.length)return;const to=bl[0].style.textAlign==al?'':al;bl.forEach(b=>{b.style.textAlign=to});nbSync(ed);nbTbState()}
function nbTbState(){const ed=nbEd1();if(!ed)return;const bl=nbSelBlocks(ed),al=(bl[0]&&bl[0].style.textAlign)||'start';document.querySelectorAll('#nbtb [data-al]').forEach(b=>b.classList.toggle('on',b.getAttribute('data-al')==al))}
function nbTxtColor(hx){nbTypC=hx||'';const ed=nbEd1();if(!ed)return;try{ed.focus();const s=getSelection();if(nbRange&&ed.contains(nbRange.startContainer)){s.removeAllRanges();s.addRange(nbRange)}document.execCommand('styleWithCSS',false,true);if(hx)document.execCommand('foreColor',false,hx);else document.execCommand('removeFormat')}catch(e){dbg(e)}nbSync(ed)}
const MKR=/^\s*(\d+\.\s|[•☐☑]\s)/;
function nbSetMark(b,mk){let tn=nbFirstText(b);if(!tn){b.innerHTML='';tn=document.createTextNode('');b.appendChild(tn)}tn.nodeValue=mk+tn.nodeValue.replace(MKR,'')}
function nbModeUi(){document.querySelectorAll('#nbtb [data-md]').forEach(b=>b.classList.toggle('on',b.getAttribute('data-md')==nbMode))}
function nbModeTg(k){if(nbMode==k){nbMode='';nbModeUi();return}nbMode=k;const ed=nbEd1();if(ed){nbNorm(ed);nbSelBlocks(ed).forEach(b=>{if(!MKR.test(b.textContent)){const pv=b.previousElementSibling,m=pv&&/^\s*(\d+)\.\s/.exec(pv.textContent);nbSetMark(b,k=='ol'?((m?+m[1]+1:1)+'. '):k=='bl'?'• ':'☐ ')}});nbSync(ed)}nbModeUi()}
function nbBoxTg(){const ed=nbEd1();if(!ed)return;nbSelBlocks(ed).forEach(b=>{const tn=nbFirstText(b);if(!tn)return;if(/^\s*☐/.test(tn.nodeValue))tn.nodeValue=tn.nodeValue.replace('☐','☑');else if(/^\s*☑/.test(tn.nodeValue))tn.nodeValue=tn.nodeValue.replace('☑','☐')});nbSync(ed)}
function nbTbDown(e){const t=e.target;if(t&&t.closest&&t.closest('button,.rainbow,span[onclick]')&&!t.closest('select,input,label'))e.preventDefault()}
if(document.addEventListener)document.addEventListener('selectionchange',()=>{nbRange0();nbTbState()});
function nbPageHtml(b,x,i){const f=nbF(b,x),lh=Math.round(f.fs*1.9),h=lh*17,pp=nbPP(b,x),C=nbPcC(pp.pc),body=(x.h!=null&&x.h!=='')?nbClean(x.h):fromText(x.x);
 return `<div class="pgx"><div class="sheet"><div class="pgw" data-i="${i}" style="position:relative;overflow:hidden;height:${h}px;background-color:${C.bg};${nbBg(pp.paper,lh,C.ln)};${pp.paper=='school'?'border-right:3px solid #e57373;':''}"><canvas class="cvh" data-i="${i}" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none;opacity:.42"></canvas>${nbFloatHtml(x)}<div class="rt" contenteditable="true" spellcheck="false" data-id="${x.id}" data-i="${i}" data-ph="اكتب هنا..." data-empty="${nbText(body).replace(/\s+/g,'')?'':'1'}" oninput="nbRtIn(event,this)" onfocus="nbPi=${i}" onpaste="nbPaste(event,this)" oncompositionend="nbCompEnd(event,this)" onclick="nbRtTap(event,this)" style="height:${h}px;overflow:visible;font-size:${f.fs}px;line-height:${lh}px;font-family:${f.ff};background:transparent;color:${C.fg};${nbDraw?'pointer-events:none':''}">${body}</div><div class="objs${nbDraw?' dr':''}" data-i="${i}" style="position:absolute;inset:0;pointer-events:none">${nbObjHtml(x)}</div><canvas class="cvs" data-i="${i}" style="${nbDraw?'touch-action:none':'pointer-events:none'}"></canvas></div></div></div>`}
function nbImg(inp){const f=inp.files[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas'),k=Math.min(1,800/Math.max(im.width,im.height)),W=Math.round(im.width*k),H=Math.round(im.height*k);c.width=W;c.height=H;c.getContext('2d').drawImage(im,0,0,W,H);const b0=nbK();b0.img=c.toDataURL('image/jpeg',.8);b0.ia=W/H;b0.ix=50;b0.iy=50;b0.iz=1;save();draw();if(!nbCur&&nbEd)nbEditCover(nbEd)};im.src=rd.result};rd.readAsDataURL(f)}
/* الرسم: قلم / قلم تحديد / ممحاة / مسطرة */
function nbTool(k){nbDraw=nbDraw==k?'':k;nbTb=true;draw()}
let nbTypC=null,nbLk=null,nbCS=null,nbTm=0,nbG=null,nbSelO=0,nbFnt=null,nbZ={s:1,x:0,y:0};const nbP={};
function nbCanv(){document.querySelectorAll('#nbpg .pgw').forEach(w=>{w.style.setProperty('--pw',w.clientWidth+'px');if(w.clientWidth&&nbK())nbK().pw=w.clientWidth});
 document.querySelectorAll('#nbpg .cvs').forEach(cv=>{const i=+cv.dataset.i,dp=window.devicePixelRatio||1,W=cv.clientWidth||cv.getBoundingClientRect().width,Hh=cv.clientHeight||cv.getBoundingClientRect().height;cv.width=Math.round(W*dp);cv.height=Math.round(Hh*dp);cv.W=W;cv.getContext('2d').setTransform(dp,0,0,dp,0,0);
  const hv=cv.parentNode.querySelector('.cvh');if(hv){hv.width=cv.width;hv.height=cv.height;hv.getContext('2d').setTransform(dp,0,0,dp,0,0)}
  nbPaint(cv,i);if(nbDraw)cv.onpointerdown=e=>nbPd(e,cv,i)});
 document.querySelectorAll('#nbpg .ob').forEach(el=>{el.onpointerdown=e=>nbObjDown(e,el)})}
function nbPaint(cv,i,live){const W=cv.W,dp=window.devicePixelRatio||1,H=cv.height/dp,c=cv.getContext('2d'),hv=cv.parentNode&&cv.parentNode.querySelector&&cv.parentNode.querySelector('.cvh'),hc=hv&&hv.getContext('2d');
 c.clearRect(0,0,W,H);if(hc)hc.clearRect(0,0,W,H);
 (nbK().notes[i].sk||[]).concat(live?[live]:[]).forEach(s=>{const g=s.k=='h'?hc:c;if(!g)return;if(s.sh&&NBSHF[s.sh]){nbStamp(g,s,W);return}g.beginPath();g.lineCap='round';g.lineJoin='round';g.strokeStyle=s.c;g.lineWidth=s.w;g.globalAlpha=1;s.p.forEach(([x,y],j)=>j?g.lineTo(x*W,y*W):g.moveTo(x*W,y*W));if(s.p.length==1)g.lineTo(s.p[0][0]*W+.1,s.p[0][1]*W);g.stroke()});
 if(live&&live.rl&&live.p.length>1){const a=live.p[0],b=live.p[live.p.length-1];c.fillStyle='#000';c.font='12px sans-serif';c.fillText((Math.hypot((b[0]-a[0])*W,(b[1]-a[1])*W)/37.8).toFixed(1)+' cm',b[0]*W+6,b[1]*W-6)}
 if(cv._er&&nbDraw=='e'){c.beginPath();c.arc(cv._er[0]*W,cv._er[1]*W,nbSz.e/2,0,6.2832);c.strokeStyle='#888';c.lineWidth=1.5;c.stroke()}}
const nbSegNear=(q,a,b,R)=>{const dx=b[0]-a[0],dy=b[1]-a[1],L2=dx*dx+dy*dy;let t=L2?((q[0]-a[0])*dx+(q[1]-a[1])*dy)/L2:0;t=Math.max(0,Math.min(1,t));return Math.hypot(q[0]-(a[0]+t*dx),q[1]-(a[1]+t*dy))<R};
const nbBBm=new WeakMap();
function nbBox(s){let b=nbBBm.get(s);if(!b){let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const q of s.p){if(q[0]<x0)x0=q[0];if(q[0]>x1)x1=q[0];if(q[1]<y0)y0=q[1];if(q[1]>y1)y1=q[1]}b=[x0,y0,x1,y1];nbBBm.set(s,b)}return b}
const nbPad=(s,W)=>(s.sh?Math.max(12,s.w*5):s.w)/2/W;
const nbPS=(q,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],L2=dx*dx+dy*dy;let t=L2?((q[0]-a[0])*dx+(q[1]-a[1])*dy)/L2:0;t=Math.max(0,Math.min(1,t));return Math.hypot(q[0]-(a[0]+t*dx),q[1]-(a[1]+t*dy))};
const nbSS=(p1,p2,q1,q2)=>{const o=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]),d1=o(q1,q2,p1),d2=o(q1,q2,p2),d3=o(p1,p2,q1),d4=o(p1,p2,q2);if(((d1>0&&d2<0)||(d1<0&&d2>0))&&((d3>0&&d4<0)||(d3<0&&d4>0)))return 0;return Math.min(nbPS(p1,q1,q2),nbPS(p2,q1,q2),nbPS(q1,p1,p2),nbPS(q2,p1,p2))};
const nbMiss=(s,a,b,R,W)=>{const pad=nbPad(s,W),bb=nbBox(s);return bb[2]+pad<Math.min(a[0],b[0])-R||bb[0]-pad>Math.max(a[0],b[0])+R||bb[3]+pad<Math.min(a[1],b[1])-R||bb[1]-pad>Math.max(a[1],b[1])+R};
/* مسح الخط كاملاً: يلمس أي جزء من الخط (بما فيه سُمكه) فيُحذف */
function nbHit(s,a,b,R,W){if(nbMiss(s,a,b,R,W))return false;const RR=R+nbPad(s,W);if(s.p.length==1)return nbPS(s.p[0],a,b)<RR;for(let i=1;i<s.p.length;i++)if(nbSS(s.p[i-1],s.p[i],a,b)<RR)return true;return false}
/* مسح تدريجي دقيق: يمسح بالضبط ما تحت دائرة الممحاة (مع حساب سُمك القلم) وبخطوات 1 بكسل */
function nbErase(sk,x,y,rad,W,x1,y1){const a=[x,y],b=[x1===undefined?x:x1,y1===undefined?y:y1],R=rad/W,out=[];
 sk.forEach(s=>{if(nbMiss(s,a,b,R,W)){out.push(s);return}
  const RR=R+nbPad(s,W);if(!nbHit(s,a,b,R,W)){out.push(s);return}
  const P=[];s.p.forEach((q,i)=>{if(i){const u=s.p[i-1],n=Math.ceil(Math.hypot(q[0]-u[0],q[1]-u[1])*W);for(let k=1;k<n;k++)P.push([u[0]+(q[0]-u[0])*k/n,u[1]+(q[1]-u[1])*k/n])}P.push(q)});
  if(!P.some(q=>nbSegNear(q,a,b,RR))){out.push(s);return}
  let run=[];const fl=()=>{if(run.length){let r=[run[0]],len=0;for(let i=1;i<run.length;i++){const l=r[r.length-1];if(Math.hypot((run[i][0]-l[0])*W,(run[i][1]-l[1])*W)>=2||i==run.length-1){len+=Math.hypot((run[i][0]-l[0])*W,(run[i][1]-l[1])*W);r.push(run[i])}}
   if(!(s.p.length>1&&len<1.5))out.push({...s,p:r.map(q=>[+q[0].toFixed(4),+q[1].toFixed(4)])})}run=[]};
  P.forEach(q=>{if(nbSegNear(q,a,b,RR))fl();else run.push(q)});fl()});return out}
let _raf=0;
function nbPaintLater(cv,i){if(typeof requestAnimationFrame!='function'){nbPaint(cv,i);return}if(_raf)return;_raf=requestAnimationFrame(()=>{_raf=0;nbPaint(cv,i)})}
const nbNP=()=>Object.keys(nbP).length;
function nbErAt(s,a,b){const W=s.cv.W;s.n.sk=nbEW?s.n.sk.filter(k=>!nbHit(k,a,b,nbSz.e/2/W,W)):nbErase(s.n.sk,a[0],a[1],nbSz.e/2,W,b[0],b[1])}
function nbPd(e,cv,i){e.preventDefault();try{cv.setPointerCapture(e.pointerId)}catch(x){dbg(x)}nbP[e.pointerId]={x:e.clientX,y:e.clientY};const two=!!S.nbTwo;
 cv.onpointermove=ev=>nbMv(ev,cv);cv.onpointerup=cv.onpointercancel=ev=>nbUp(ev,cv);
 if(two&&nbNP()>=2){clearTimeout(nbTm);nbTm=0;nbCS=null;nbGestStart();return}
 const r=cv.getBoundingClientRect(),pt=ev=>[(ev.clientX-r.left)/r.width,(ev.clientY-r.top)/r.width],n=nbK().notes[i];n.sk=n.sk||[];
 const begin=()=>{if(nbDraw=='e'){nbCS={cv,i,n,pid:e.pointerId,mode:'e',pt,lp:pt(e)};nbErAt(nbCS,nbCS.lp,nbCS.lp);cv._er=nbCS.lp;nbPaintLater(cv,i)}else{nbCS={cv,i,n,pid:e.pointerId,mode:'d',pt,st:{k:nbDraw,c:nbCol,w:nbSz[nbDraw],p:[pt(e)],rl:nbRuler,sh:nbDraw=='p'?nbShape:''}}}};
 if(two){clearTimeout(nbTm);nbTm=setTimeout(()=>{nbTm=0;if(nbNP()<2)begin()},70)}else begin()}
function nbMv(ev,cv){if(nbP[ev.pointerId])nbP[ev.pointerId]={x:ev.clientX,y:ev.clientY};if(nbG){nbGestMove();return}const s=nbCS;if(!s||ev.pointerId!==s.pid)return;
 const evs=ev.getCoalescedEvents?ev.getCoalescedEvents():[ev];(evs.length?evs:[ev]).forEach(c=>{const q=s.pt(c);
  if(s.mode=='e'){nbErAt(s,s.lp,q);s.lp=q}
  else{const st=s.st;if(nbRuler){const a=st.p[0],dx=q[0]-a[0],dy=q[1]-a[1],ang=Math.atan2(dy,dx)*180/Math.PI,sn=Math.round(ang/45)*45;let b=q;if(Math.abs(ang-sn)<6){const L=Math.hypot(dx,dy),rd=sn*Math.PI/180;b=[a[0]+L*Math.cos(rd),a[1]+L*Math.sin(rd)]}st.p=[a,b]}else{const l=st.p[st.p.length-1];if(Math.hypot((q[0]-l[0])*s.cv.W,(q[1]-l[1])*s.cv.W)>2)st.p.push(q)}}});
 if(s.mode=='e'){s.cv._er=s.lp;nbPaintLater(s.cv,s.i)}else nbPaint(s.cv,s.i,s.st)}
function nbUp(ev,cv){delete nbP[ev.pointerId];clearTimeout(nbTm);nbTm=0;if(nbG){if(nbNP()<2)nbG=null;return}const s=nbCS;if(!s||ev.pointerId!==s.pid)return;nbCS=null;cv.onpointermove=null;
 if(s.mode=='e'){cv._er=null;nbPaint(cv,s.i);save()}else{const st=s.st;st.p=st.p.map(([x,y])=>[+x.toFixed(4),+y.toFixed(4)]);delete st.rl;s.n.sk.push(st);nbPaint(cv,s.i);save()}}
/* التحكم بإصبعين: تكبير/تصغير وتحريك الشاشة دون رسم أو مسح */
function nbZApply(){const el=$('#nbpg');if(!el)return;el.style.transformOrigin='0 0';el.style.transform=(nbZ.s==1&&!nbZ.x&&!nbZ.y)?'':'translate('+nbZ.x+'px,'+nbZ.y+'px) scale('+nbZ.s+')'}
function nbGestStart(){const k=Object.keys(nbP);if(k.length<2){nbG=null;return}const a=nbP[k[0]],b=nbP[k[1]];nbG={d:Math.hypot(a.x-b.x,a.y-b.y)||1,mx:(a.x+b.x)/2,my:(a.y+b.y)/2,lx:(a.x+b.x)/2,ly:(a.y+b.y)/2,z:{...nbZ}}}
function nbGestMove(){const k=Object.keys(nbP);if(k.length<2||!nbG)return;const a=nbP[k[0]],b=nbP[k[1]],mx=(a.x+b.x)/2,my=(a.y+b.y)/2,d=Math.hypot(a.x-b.x,a.y-b.y),g=nbG,pg=$('#nbpg'),vp=pg&&pg.parentNode;if(!vp)return;const vr=vp.getBoundingClientRect(),s=Math.max(1,Math.min(4,g.z.s*d/g.d));
 let x=(mx-vr.left)-((g.mx-vr.left)-g.z.x)*(s/g.z.s),y=(my-vr.top)-((g.my-vr.top)-g.z.y)*(s/g.z.s);x=Math.min(0,Math.max(vr.width*(1-s),x));y=Math.min(0,Math.max(vr.height*(1-s),y));
 if(s===1){try{window.scrollBy(0,-(my-g.ly));pg.scrollLeft-=(mx-g.lx)}catch(e){dbg(e)}nbZ={s:1,x:0,y:0}}else nbZ={s,x,y};nbZApply();g.lx=mx;g.ly=my}
/* الصور والملصقات */
const nbObjCss=(o)=>{const c=o.c||{l:0,t:0,r:0,b:0},cw=1-c.l-c.r,ch=1-c.t-c.b,vis=o.ar*cw/ch;return{st:`left:calc(var(--pw,320px)*${o.x});top:calc(var(--pw,320px)*${o.y});width:calc(var(--pw,320px)*${o.w});height:calc(var(--pw,320px)*${o.w/vis})`,im:`position:absolute;width:${100/cw}%;height:${100/ch}%;left:${-c.l/cw*100}%;top:${-c.t/ch*100}%`}};
function nbFloatList(n){const L=(n.im||[]).slice().sort((a,b)=>a.y-b.y),cur={left:0,right:0},out=[];let lastTop=0;
 L.forEach(o=>{const c=o.c||{l:0,t:0,r:0,b:0},cw=1-c.l-c.r,ch=1-c.t-c.b,vis=o.ar*cw/ch,h=o.w/vis,side=(o.x+o.w/2)<.5?'left':'right',top=Math.max(cur[side],lastTop),Y=Math.max(0,o.y-top),wd=side=='left'?(o.x+o.w):(1-o.x);
  out.push({o,side,top,Y,h,wd});cur[side]=top+Y+h;lastTop=top});return out}
const nbFloatCss=f=>{const P='var(--pw,320px)';return `float:${f.side};clear:${f.side};width:calc(${P}*${+f.wd.toFixed(4)} + 4px);height:calc(${P}*${+(f.Y+f.h).toFixed(4)} + 6px);shape-outside:inset(calc(${P}*${+f.Y.toFixed(4)}) 0 0 0);pointer-events:none`};
const nbFloatHtml=n=>nbFloatList(n).map(f=>`<div class="fsp" data-oid="${f.o.id}" style="${nbFloatCss(f)}"></div>`).join('');
const nbObjHtml=n=>(n.im||[]).map(o=>{const k=nbObjCss(o);return `<div class="ob${nbSelO==o.id?' sel':''}" data-oid="${o.id}" style="${k.st}"><div class="cl"><img alt="" src="${o.src}" draggable="false" style="${k.im}"></div><i class="hd"></i></div>`}).join('');
function nbObjStyle(el,o){const k=nbObjCss(o);el.style.cssText=k.st;try{const w=el.parentNode.parentNode,n=nbK().notes[+el.parentNode.dataset.i];if(w&&w.querySelector&&n)nbFloatList(n).forEach(f=>{const sp=w.querySelector('.fsp[data-oid="'+f.o.id+'"]');if(sp)sp.style.cssText=nbFloatCss(f)})}catch(e){dbg(e)}const im=el.querySelector&&el.querySelector('img');if(im)im.style.cssText=k.im}
function nbObjCur(){const n=nbCP();return n&&(n.im||[]).find(o=>o.id==nbSelO)}
function nbObjDown(e,el){e.preventDefault();e.stopPropagation();const n=nbK().notes[+el.parentNode.dataset.i],o=(n.im||[]).find(q=>q.id==el.dataset.oid);if(!o)return;nbSelO=o.id;nbPi=+el.parentNode.dataset.i;document.querySelectorAll('#nbpg .ob').forEach(x=>x.classList.toggle('sel',x===el));
 const pw=el.parentNode.clientWidth||320,pts={},isH=e.target.classList&&e.target.classList.contains('hd'),st={x:o.x,y:o.y,w:o.w,px:e.clientX,py:e.clientY,d:0,w2:o.w};try{el.setPointerCapture(e.pointerId)}catch(x){dbg(x)}pts[e.pointerId]=[e.clientX,e.clientY];
 el.onpointermove=ev=>{if(!pts[ev.pointerId])return;pts[ev.pointerId]=[ev.clientX,ev.clientY];const ks=Object.keys(pts);
  if(ks.length>=2){const a=pts[ks[0]],b=pts[ks[1]],d=Math.hypot(a[0]-b[0],a[1]-b[1]);if(!st.d){st.d=d||1;st.w2=o.w}else o.w=Math.max(.05,Math.min(1.2,st.w2*d/st.d))}
  else if(isH)o.w=Math.max(.05,Math.min(1.2,st.w+(ev.clientX-st.px)/pw));else{o.x=st.x+(ev.clientX-st.px)/pw;o.y=st.y+(ev.clientY-st.py)/pw}nbObjStyle(el,o)};
 el.onpointerup=el.onpointercancel=ev=>{delete pts[ev.pointerId];if(!Object.keys(pts).length){el.onpointermove=null;save();draw()}}}
const stkKey=o=>o.src.length+o.src.slice(-50)+JSON.stringify(o.c||{});
function stkSave(oid){const o=(nbCP().im||[]).find(x=>x.id==oid);if(!o)return;S.stk=S.stk||[];const key=stkKey(o);if(S.stk.some(k=>k.key===key)){toast('محفوظ مسبقاً');return}
 const im=new Image();im.onload=()=>{const c=o.c||{l:0,t:0,r:0,b:0},cw=1-c.l-c.r,ch=1-c.t-c.b,sw=Math.max(1,Math.round(cw*im.width)),sh=Math.max(1,Math.round(ch*im.height)),cv=document.createElement('canvas');cv.width=sw;cv.height=sh;cv.getContext('2d').drawImage(im,Math.round(c.l*im.width),Math.round(c.t*im.height),sw,sh,0,0,sw,sh);
  S.stk.push({id:S.id++,src:cv.toDataURL('image/png'),ar:sw/sh,key});save();toast('أُضيف إلى الملصقات المحفوظة (مقصوصاً)');draw()};im.src=o.src}
function stkDel(id){S.stk=(S.stk||[]).filter(k=>k.id!=id);save();draw()}
function nbUseStk(id){const k=(S.stk||[]).find(x=>x.id==id);if(!k)return;const n=nbCP();(n.im=n.im||[]).push({id:S.id++,k:'st',src:k.src,ar:k.ar,x:.3,y:.2,w:.25,c:{l:0,t:0,r:0,b:0}});nbSelO=n.im[n.im.length-1].id;save();draw()}
function nbObjSz(d){const o=nbObjCur();if(!o)return;o.w=Math.max(.05,Math.min(1.2,o.w*(1+d)));save();draw()}
function nbCrop(k,v){const o=nbObjCur();if(!o)return;o.c=o.c||{l:0,t:0,r:0,b:0};const x=Math.max(0,Math.min(.6,v/100)),oth=k=='l'?o.c.r:k=='r'?o.c.l:k=='t'?o.c.b:o.c.t;o.c[k]=Math.min(x,.9-oth);const el=document.querySelector('#nbpg .ob[data-oid="'+o.id+'"]');if(el)nbObjStyle(el,o);nbSv()}
function nbObjDel(){const n=nbCP();n.im=(n.im||[]).filter(o=>o.id!=nbSelO);nbSelO=0;save();draw()}
function nbAddObj(k,inp){const f=inp.files[0];if(!f)return;const rd=new FileReader();rd.onload=()=>{const im=new Image();im.onload=()=>{const M=k=='st'?300:640,sc=Math.min(1,M/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(im.width*sc));c.height=Math.max(1,Math.round(im.height*sc));c.getContext('2d').drawImage(im,0,0,c.width,c.height);
  const src=k=='st'?c.toDataURL('image/png'):c.toDataURL('image/jpeg',.75),n=nbCP();(n.im=n.im||[]).push({id:S.id++,k,src,ar:c.width/c.height,x:.25,y:.15,w:k=='st'?.25:.5,c:{l:0,t:0,r:0,b:0}});nbSelO=n.im[n.im.length-1].id;save();draw()};im.src=rd.result};rd.readAsDataURL(f)}
function nbUndo(){const n=nbCP();if(n.sk&&n.sk.length){n.sk.pop();save();draw()}}
function nbClr(){nbCP().sk=[];save();draw()}
function nbWheel(e){const r=e.currentTarget.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),h=(Math.atan2(dx,-dy)*180/Math.PI+360)%360,d=Math.min(1,Math.hypot(dx,dy)/(r.width/2));nbCol='hsl('+Math.round(h)+',100%,'+Math.round(100-d*50)+'%)';draw()}
const chg=(old,fn)=>old?ask('هل تريد التغيير؟',fn,'نعم','لا'):fn();
const nbTdO={};
const MKC='<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',MKX='<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>';
const mk2=(s,a,b)=>`<div class="mk"><span class="ck ${s==1?'on':''}" onclick="${a}">${MKC}</span><span class="ck x ${s==2?'on':''}" onclick="${b}">${MKX}</span></div>`;
function nbTodo(b){const T=(b.todos||[]).map(x=>{if(x.s===undefined)x.s=x.d?1:0;return x}),ok=T.filter(x=>x.s==1).length,no=T.filter(x=>x.s==2).length,many=T.length>1,open=!many||nbTdO[b.id];
 return `<div class="c"><div class="row sp" ${many?'onclick="nbTdTg()" style="cursor:pointer"':''}><b>✅ قائمة المهمات</b><span class="m">✓ ${ok} • ✗ ${no} • ${T.length}${many?` <button type="button" class="g" style="padding:1px 9px;font-size:13px">${open?'▴':'▾'}</button>`:''}</span></div>
 ${T.length?`<div style="height:6px;background:var(--bd);border-radius:6px;margin:8px 0"><div style="height:6px;width:${ok/T.length*100}%;background:var(--pri);border-radius:6px"></div></div>`:''}
 ${open?T.map(x=>`<div class="row" style="flex-wrap:nowrap;padding:8px 0;border-top:1px solid var(--bd)">${mk2(x.s,`nbTdMk(${x.id},1)`,`nbTdMk(${x.id},2)`)}<span style="flex:1;${x.s==1?'text-decoration:line-through;color:var(--mut)':x.s==2?'color:var(--bad)':''}">${esc(x.t)}</span><button type="button" class="g" style="padding:2px 9px" onclick="nbTdDel(${x.id})">×</button></div>`).join('')+`<div class="row" style="margin-top:8px;flex-wrap:nowrap"><input id="tdi" placeholder="اكتب مهمة جديدة" autocomplete="off" onkeydown="if(event.key==='Enter')nbTdAdd()" style="flex:1;margin:0;min-width:0"><button type="button" onclick="nbTdAdd()">${svg('plus')}</button></div>`:''}</div>`}
function nbTdTg(){const b=nbK();nbTdO[b.id]=!nbTdO[b.id];draw()}
function nbTdAdd(){const v=$('#tdi').value.trim();if(!v)return;const b=nbK();(b.todos=b.todos||[]).push({id:S.id++,t:v,s:0,c:Date.now()});nbTdO[b.id]=true;save();draw()}
function nbTdMk(id,v){const x=nbK().todos.find(y=>y.id==id);chg(x.s,()=>{x.s=x.s==v?0:v;x.at=x.s?Date.now():0;save();draw()})}
function nbTdDel(id){const b=nbK();b.todos=b.todos.filter(y=>y.id!=id);save();draw()}
function nbAddPg(){const b=nbK();b.notes.push({id:S.id++,t:'',x:'',u:Date.now()});nbPi=b.notes.length-1;save();draw()}
const nbSv=()=>{clearTimeout(nbT);nbT=setTimeout(save,500)};
function nbSet(k,v){nbK()[k]=v;save();draw()}
function nbPick(id){nbK().cur=id;save();draw()}
function nbNew(){const b=nbK(),o={id:S.id++,t:'',x:'',u:Date.now()};b.notes.push(o);b.cur=o.id;save();draw()}
function nbDel(){const b=nbK();b.notes=b.notes.filter(x=>x.id!=b.cur);save();draw()}
function nbDelB(){const id=nbCur||nbEd;S.nbs=S.nbs.filter(x=>x.id!=id);nbCur=0;nbEd=0;save();draw()}
function nbRmLock(){const id=nbCur||nbEd;$('#sh').innerHTML=shW(`<b>إزالة قفل الدفتر</b><div class="m" style="margin:6px 0">اكتب كلمة السر الحالية لإزالة القفل.</div><input id="nbp" type="password" dir="ltr" placeholder="كلمة السر"><div id="nbm" class="m" style="color:var(--bad)"></div><button type="button" onclick="nbRmDo(${id})">إزالة القفل</button><button type="button" class="g" onclick="nbForgot(${id},'rm')">نسيت كلمة السر</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
async function nbRmDo(id){const b=S.nbs.find(x=>x.id==id);if(await hp($('#nbp').value)===b.lock){b.lock=null;b.sq=null;b.sa=null;save();$('#sh').innerHTML='';toast('أُزيل القفل');draw();if(!nbCur&&nbEd)nbEditCover(nbEd)}else $('#nbm').textContent='⚠️ كلمة السر غير صحيحة'}
function nbLockSheet(){$('#sh').innerHTML=shW(`<b>🔒 قفل الدفتر بكلمة سر</b><input id="nbp" type="password" dir="ltr" placeholder="كلمة السر"><input id="nbp2" type="password" dir="ltr" placeholder="تأكيد كلمة السر">${qBox('nb')}<div id="nbm" class="m" style="color:var(--bad)"></div><button type="button" onclick="nbLockSet()">حفظ</button><button type="button" class="g" onclick="$('#sh').innerHTML=''">إلغاء</button>`)}
async function nbLockSet(){const a=$('#nbp').value,b=$('#nbp2').value,q=qRead('nb');if(a.length<4||a!==b||!nrm(q.a)){$('#nbm').textContent=a.length<4?'⚠️ كلمة السر 4 أحرف على الأقل':a!==b?'⚠️ كلمتا السر غير متطابقتين':'⚠️ اكتب جواب سؤال الأمان';return}const k=nbK();k.lock=await hp(a);k.sq=q.q;k.sa=await hp(nrm(q.a));nbOpen.add(nbCur||nbEd);save();$('#sh').innerHTML='';draw()}

/* ---------- شريط التاريخ ---------- */
function tickDate(){const d=new Date(),en=S.lang=='en';$('#dd').textContent=d.toLocaleDateString(en?'en-US':'ar-SY-u-nu-latn',{weekday:'short',day:'numeric',month:'short'});$('#dtm').textContent=d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',second:'2-digit'});const an=$('#dan');if(an){let nm='';try{if(fu)nm=accName(accList().find(x=>x.uid==fu.uid)||{uid:fu.uid,name:fu.displayName,email:fu.email})}catch(e){dbg(e)}if(an.textContent!==nm)an.textContent=nm}}
tickDate();setInterval(()=>{if(!document.hidden)tickDate()},1000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)try{tickDate()}catch(e){dbg(e)}});
migrate();if((S.profile||{}).country=='IL')S.profile.country='PS';S.since=S.since||ymd(new Date());if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol))window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').then(reg=>{
 const upd=w=>{if($('#updb'))return;updW=w||null;const b=document.createElement('div');b.className='c';b.id='updb';b.innerHTML='<div class="row sp"><b>تتوفر نسخة جديدة من التطبيق</b><button type="button" onclick="updGo()" style="padding:6px 14px">تحديث الآن</button></div>';const bn=$('#ban');if(bn)bn.appendChild(b)};
 if(reg.waiting&&navigator.serviceWorker.controller)upd(reg.waiting);
 reg.addEventListener('updatefound',()=>{const w=reg.installing;if(w)w.addEventListener('statechange',()=>{if(w.state=='installed'&&navigator.serviceWorker.controller)upd(w)})});
 const verSig=()=>fetch('index.html',{method:'HEAD',cache:'no-store'}).then(r=>r.ok?(r.headers.get('etag')||r.headers.get('last-modified')||r.headers.get('content-length')):null).catch(()=>null);let verBase=null;
 const chk=()=>{try{reg.update()}catch(e){dbg(e)}verSig().then(v=>{if(!v)return;if(verBase===null)verBase=v;else if(v!==verBase)upd(null)})};
 chk();setInterval(chk,36e5);document.addEventListener('visibilitychange',()=>{if(!document.hidden)chk()});
}).catch(()=>{}));
let updW=null,updR=0;
function updGo(){updR=1;try{updW&&updW.postMessage({type:'SKIP_WAITING'})}catch(e){dbg(e)}setTimeout(()=>location.reload(),1200)}
if('serviceWorker' in navigator)navigator.serviceWorker.addEventListener('controllerchange',()=>{if(updR)location.reload()});window.addEventListener('online',()=>{try{if(fu){pushNow();syncDown()}}catch(e){dbg(e)}});document.addEventListener('visibilitychange',()=>{try{if(document.visibilityState==='hidden'){if(pt){clearTimeout(pt);pt=null;pushNow()}}else syncDown()}catch(e){dbg(e)}});window.addEventListener('focus',()=>{try{syncDown()}catch(e){dbg(e)}});const idbReady=(async()=>{try{const t=await idb.get('S');if(!t)return;const o=JSON.parse(t);
 if((o._u||0)>(S._u||0)&&(!S._uid||!o._uid||o._uid===S._uid)){S=Object.assign(EMPTY(),o);S.lang=BOOT_LANG;migrate();try{localStorage.setItem('qmrm',JSON.stringify(S))}catch(e){dbg(e)}applyTheme();draw()}}catch(e){dbg(e)}})();
/* ---------- زر الرجوع في الهاتف: يتراجع خطوة خطوة، ثم يعود لليوم، ثم يسأل عن الخروج ---------- */
let bbArmed=false,bbExit=false,bbTm=0;
function bbArm(){if(bbArmed||bbExit)return;try{history.pushState({qmrm:1},'');bbArmed=true}catch(e){dbg(e)}}
function bbQuit(){bbExit=true;try{history.back()}catch(e){dbg(e)}setTimeout(()=>{try{window.close()}catch(e){dbg(e)}},120);setTimeout(()=>{try{toast('اضغط زر الرجوع مرة أخرى للخروج')}catch(e){dbg(e)}},700);clearTimeout(bbTm);bbTm=setTimeout(()=>{bbExit=false;bbArmed=false;bbArm()},5000)}
function bbStep(){
 const dg=document.querySelector('.exdg');if(dg){const c=dg.querySelector('button[data-k="0"]');c?c.click():dg.remove();return true}
 if(document.getElementById('exPp')){exPaperX();return true}
 if(document.getElementById('exOv')){exClose();return true}
 const sh=document.getElementById('sh');
 if(sh&&sh.innerHTML.trim()){if(document.getElementById('crh')&&typeof colCancel=='function')colCancel();else{pf=null;sh.innerHTML=''}return true}
 if(document.getElementById('lkbar')){nbLkHide();nbLk=null;return true}
 const aw=document.getElementById('aw');
 if(aw&&aw.style.display==='block'&&aw.innerHTML.trim()){if(awMode==='up'){awSet('in');return true}if(!aw.querySelector('.awspin')&&confirm('هل تريد الخروج من التطبيق؟'))bbQuit();return true}
 if(tab=='nb'&&nbCur){if(tbSec){tbSec='';draw();return true}nbOpen.delete(nbCur);nbCur=0;draw();return true}
 if(tab=='ar'&&arPvOpen){arPvOpen=false;pvOk=false;draw();return true}
 if(tab=='ct'&&ctTab!=='list'){ctTab='list';draw();return true}
 if(tab=='pv'){go('td');return true}
 if(tab!=='home'){go('home');return true}
 ask('هل تريد الخروج من التطبيق؟',bbQuit,'نعم، اخرج','لا، ابقَ');return true}
function bbInit(){if(!(window.history&&history.pushState&&window.addEventListener))return;try{history.replaceState({qmrm:0},'')}catch(e){dbg(e)}
 const evs=['pointerup','click','touchend','keydown'];const arm=()=>{try{if(navigator.userActivation&&!navigator.userActivation.hasBeenActive)return}catch(e){dbg(e)}evs.forEach(t=>window.removeEventListener(t,arm,true));bbArm()};evs.forEach(t=>window.addEventListener(t,arm,true));
 window.addEventListener('popstate',()=>{if(bbExit||!bbArmed)return;bbArmed=false;try{bbStep()}catch(e){dbg(e)}bbArm()})}
applyTheme();initLang();draw();try{bbInit()}catch(e){dbg(e)}if(window.firebase)fbInit();else addEventListener('DOMContentLoaded',()=>{if(window.firebase)fbInit();else addEventListener('load',fbInit)});remTick();bkCheck();
